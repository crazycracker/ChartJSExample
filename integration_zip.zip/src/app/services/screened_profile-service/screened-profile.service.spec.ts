import { TestBed, inject } from '@angular/core/testing';
import { APIService } from '../../services/api-service/api.service';
import { Http2Service } from '../../services/http2/http2.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ScreenedProfileService } from './screened-profile.service';

describe('ScreenedProfileService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        ScreenedProfileService,
        APIService,
        Http2Service,
      ],
    });
  });

  it('should be created', inject([ScreenedProfileService], (service: ScreenedProfileService) => {
    expect(service).toBeTruthy();
  }));
});
