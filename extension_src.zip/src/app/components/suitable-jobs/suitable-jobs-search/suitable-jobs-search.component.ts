import { Component, OnInit } from '@angular/core';
import { SuitableJobsService } from '../../../services/suitable-jobs-service/suitable-jobs.service';

@Component({
  selector: 'app-irene-suitable-jobs-search',
  templateUrl: './suitable-jobs-search.component.html',
  styleUrls: ['./suitable-jobs-search.component.scss']
})
export class SuitableJobsSearchComponent implements OnInit {
  public data: any = [];
  public labels;
  public selectItems;
  /**
  * @constructor injects the dependent services
  * @description : The constructor initialises the class variables with the dependencies injected into the class
  * @param {service} SuitableJobsService
 */
  constructor(private service: SuitableJobsService) { }

  /**
   * @method ngOnInit
   * @description : Method used to initalize the component
   */
  ngOnInit() {
    this.service.getLabelDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.labels = this.data[0].Labels[0];
        this.selectItems = this.data[0].InputValues[0];
      }
    });
  }
}
