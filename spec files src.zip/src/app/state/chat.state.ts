import { Chat } from '../models/chat-messages/chat';

export interface ChatState {
    readonly chat: Chat[];
}
