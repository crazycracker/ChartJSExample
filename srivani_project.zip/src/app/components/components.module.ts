/**
 * Components Module
 */

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { ChatBotModule } from './chatbot/chatbot.module';
import { SidebarModule } from './sidebar/sidebar.module';
import { HeaderModule } from './header/header.module';
import { FindResumeModule } from './find-best-resume/find-resume/find-resume.module';
import { ViewProfileModule } from './view-profile/view-profile/view-profile.module';
import { SuitableJobsModule } from './suitable-jobs/suitable-jobs.module';
import { ProfileTileModule } from './screened-profiles/screened-profiles.module';

@NgModule({
  declarations: [],
  exports: [
    ChatBotModule,
    SidebarModule,
    HeaderModule,
    FindResumeModule,
    ViewProfileModule,
    SuitableJobsModule,
    ProfileTileModule
  ],
  imports: [
    CommonModule,
    ChatBotModule,
    SidebarModule,
    HeaderModule,
    FindResumeModule,
    ViewProfileModule,
    SuitableJobsModule,
    ProfileTileModule
  ],
})
export class ComponentsModule { }
