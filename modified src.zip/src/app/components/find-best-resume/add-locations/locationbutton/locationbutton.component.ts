import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-locationbutton',
  templateUrl: './locationbutton.component.html',
  styleUrls: ['./locationbutton.component.scss']
})
export class LocationButtonComponent {
  @Output() addComponentClick = new EventEmitter();
   constructor() { }
// tslint:disable-next-line:eofline
}