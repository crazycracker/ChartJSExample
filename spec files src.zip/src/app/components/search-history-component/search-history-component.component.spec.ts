import { async, ComponentFixture, inject, TestBed } from '@angular/core/testing';
import { SearchHistoryComponentComponent } from './search-history-component.component';
import { APIService } from '../../services/api-service/api.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import {PagerService} from '../../services/Pagination-service/pager.service';
import { SearchHistoryService } from '../../services/search-history/search-history.service';
import {Observable, of} from 'rxjs';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
const mockResponse = {
  data: { success: true }
};
const alldata = {
    'Labels': {
      'TimeLabel': 'Time'},
      'InputValues':  [{
        'Time': '7:00pm',
        'JobId': '213457',
        'Qualification1': 'B.Sc Psychology, Italy',
        'Qualification2': 'Masters in Fashion Mgmt, London',
        'Experience': '2yrs',
        'Skill1': 'FashionDesign',
        'Skill2': 'User research',
        'Skill3': 'Marketing',
        'Location': 'Newyork',
        'Industy': 'Pharmaceuticals',
        'EmploymentType': 'Full Time',
        'Language1': 'English',
        'Language2': 'French',
        'Priority': 'Need in 1 month',
        'EducationalDetails1': 'Tier 1 companies',
        'EducationalDetails2': 'Tier 1 Institutes'
      }]
    };
class MockAPIService {
  public get(): Observable<{}> {
    return of(mockResponse);
  }
}

class  SearchHistoryMockService  {
  public  getSearchHistoryDetails(): Observable<{}> {
    return of(alldata);
  }
}
describe('SearchHistoryComponentComponent', () => {
  let component: SearchHistoryComponentComponent;
  let fixture: ComponentFixture<SearchHistoryComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchHistoryComponentComponent ],
      imports: [
        HttpClientTestingModule,
        BrowserAnimationsModule
      ],
      providers: [
        APIService,
        PagerService,
        { provide: APIService, useClass: MockAPIService },
        { provide:  SearchHistoryService,  useClass: SearchHistoryMockService }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchHistoryComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create component and get data from service',  inject([SearchHistoryService], (service: SearchHistoryService) => {
    spyOn(service, 'getSearchHistoryDetails').and.callThrough();
    service.getSearchHistoryDetails();
   component.searchHistoryLabel = alldata;
  expect(component).toBeTruthy();
  expect(component.pagedItems[0].Skill1).toEqual('FashionDesign');
})
);
});
