import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { WhyUsComponent } from './why-us.component';
import { APIService } from '../../services/api-service/api.service';
import { Http2Service } from '../../services/http2/http2.service';
import { WhyusService } from '../../services/whyus/why-us.service';
import { Observable, of } from 'rxjs';

class MockService {
  getLabelDetails(): Observable <{}> {
   return of (data);
  }
}

const data = {
  Labels: {
    clickhereLabel: 'Click Here',
    whyelixirLabel: 'Why Elixir?',
    DescriptionLabel: 'When you work at Elixir, it is not just another job.',
    awardsGaloreLabel: 'Awards Galore',
    awardsDescriptionlabel: 'In Eastat’s 2017 survey, Elixir featured amongst the top 3 organizations to work at.',
    imageUrl: 'assets/images/meetPeopleImage.png'

  }
};

describe('WhyUsComponent', () => {
  let component: WhyUsComponent;
  let fixture: ComponentFixture<WhyUsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WhyUsComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
      providers: [
        APIService,
        Http2Service,
        WhyusService,
        { provide: WhyusService, useClass: MockService }
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WhyUsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should get the labels from JSON', inject(
    [WhyusService],
    (service: WhyusService) => {
      spyOn(service, 'getLabelDetails').and.callThrough();
      service.getLabelDetails();
      expect(component.labels).toEqual(data.Labels);
    }
  ));
  it('should get Elixir description', () => {
    component.isElixirDescription = true;
    component.loadImages();
    expect(component.isElixirDescription).toBe(false);
  });
  // it('should get the current image', () => {
  //   const imageData = {
  //     imageUrl: '../../../assets/images/swimText.png'
  //   };
  //   component.showCurremtImage(imageData);
  //   expect(component.showImage).toBe('../../../assets/images/swimText.png');
  // });
});
