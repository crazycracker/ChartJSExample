import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-irene-full-calendar',
  templateUrl: './full-calendar.component.html',
  styleUrls: ['./full-calendar.component.scss']
})
export class FullCalendarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
