import { async, ComponentFixture, inject, TestBed } from '@angular/core/testing';
import { APIService } from '../../services/api-service/api.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { EmailsService } from '../../services/emails-service/emails.service';
import {Observable, of} from 'rxjs';
import { EMailsComponent } from './e-mails.component';
const mockResponse = {
  data: { success: true }
};
const data =
  [{
    'Labels': [{
      'receivedlabel': 'EMAILS RECEIVED BY ELIXIR',
    }]
  }];
  class MockAPIService {
    public get(): Observable<{}> {
      return of(mockResponse);
    }
  }
  class  EmailMockService  {
    public  getLabelDetails(): Observable<{}> {
      return of(data);
    }
  }
describe('EMailsComponent', () => {
  let component: EMailsComponent;
  let fixture: ComponentFixture<EMailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [EMailsComponent ],
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        { provide: APIService, useClass: MockAPIService },
        { provide:  EmailsService,  useClass:  EmailMockService }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EMailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should get data from service',  inject([EmailsService], (service: EmailsService) => {
    spyOn(service, 'getLabelDetails').and.callThrough();
    service.getLabelDetails();
    expect(component.labels).toEqual({ receivedlabel: 'EMAILS RECEIVED BY ELIXIR' });
    expect(component.data).toBeDefined();
})
);
});
