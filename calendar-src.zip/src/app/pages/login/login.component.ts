import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {Store} from '@ngrx/store';

import {IAppState} from '../../app.state';
import {FetchProfile} from '../../actions/profile.actions';
import {ProfileData} from '../../models/user-profile/userProfile';
import {UserLogin} from '../../actions/user.actions';

import {AuthenticationService} from '../../services/authentication-service/authentication.service';
import {UtilService} from '../../services/util/util.service';
import {ViewProfileService} from '../../services/view-profile-service/view-profile.service';


export interface IUserlogin {
  userName: string;
  password: string;
  forgetUserName: string;
}

@Component({
  selector: 'app-irene-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})

export class LoginComponent implements OnInit {
  public loginLabels: any;
  public loginHeader: any;
  public loginContent: any;

  public showLoginCard: Boolean = true;

  public isCandidateProfile;
  public toggleEvent;
  public isLoginPage: Boolean = false;
  public userData: any = [];
  public incorrectCredentials = false;
  public userRole: any;
  public loginData: any;
  public passwordSent: Boolean = false;
  public incorrectEmailId: Boolean = false;

  public formData: IUserlogin = {
    userName: '',
    password: '',
    forgetUserName: ''
  };

  constructor(
    private store: Store<IAppState>,
    private router: Router,
    private authService: AuthenticationService,
    private viewProfileService: ViewProfileService,
    private utilService: UtilService,
  ) {
  }

  ngOnInit() {
    this.authService.getLoginDetails().subscribe(res => {
      this.loginLabels = res;
      this.loginHeader = this.loginLabels.WebsiteName;
      this.loginContent = this.loginLabels.LoginLabels;
    });
  }

  toggleLoginCard() {
    this.showLoginCard = !this.showLoginCard;
    this.passwordSent = false;
    this.incorrectEmailId = false;
    this.formData.forgetUserName = '';
  }

  /**
   * @method onSubmit
   * @description: to validate username and password from service
   */

  onSubmit() {
    if (this.formData.userName !== '' && this.formData.password !== '') {
      this.authService.login(this.formData.userName, this.formData.password).subscribe(response => {
        localStorage.clear();
        if (response['body'].contextId !== '') {
          this.loginData = response['body'].loginData;
          const obj = JSON.parse(this.loginData);
          this.userRole = obj[0].user_role;
          this.defineUserRole(this.userRole);
          this.userData.push({
            'contextID': response['body'].contextId,
            'loginData': obj[0],
            'userRole': this.userRole
          });
          this.store.dispatch(UserLogin(this.userData));
          this.viewProfileService.fetchProfileDetails().subscribe(res => {
            const profileArray: ProfileData = JSON.parse(res['body'].profileData);
            if (!this.utilService.isObjectEmpty(profileArray)) {
              this.store.dispatch(FetchProfile(profileArray[0]));
            }
          }, error => {
            console.log(error);
          });
          if (this.router.url === '/login' || this.router.url === '/forgotPassword') {
            this.isLoginPage = !this.isLoginPage;
          }
        } else {
          this.incorrectCredentials = true;
        }
      });
    }
  }

  /**
   onForgetPassword(values) {
    if (this.formData.forgetUserName !== '') {
    this.authService.postForgotPasswordDetails(this.formData.forgetUserName).subscribe(response => {
        if (response['body'].contextId !== '') {
              this.passwordSent = true;
     } else {
      this.incorrectEmailId = true;
     }
     });
    }
}
   /**
   * @method defineUserRol
   * @description: To determine user role and navigate the page accordingly
   * @param: userRole data from service
   */
  defineUserRole(userRole) {
    if (this.userRole === 'HR') {
      this.router.navigate(['/findbestresume']);
    } else if ((this.userRole === 'user')) {
      this.router.navigate(['/chatbot']);
    }
  }
}
