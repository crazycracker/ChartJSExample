
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { FindResumeComponent } from './find-best.component';
import { FormsModule } from '@angular/forms';
import { AddAnotherFeatureComponent } from './add-another-feature/add-another-feature.component';
@NgModule({
  declarations: [
    FindResumeComponent,
    AddAnotherFeatureComponent
  ],
  exports: [
    FindResumeComponent,
    AddAnotherFeatureComponent
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
})
export class FindResumeModule { }
