import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { map } from 'rxjs/operators';
import { Headers } from '@angular/http';
import { HttpResponse } from '@angular/common/http';
import { APIService } from '../api-service/api.service';
import { Scheme } from '../../models/http2/http2';
import { IAPIServiceOpts } from '../../models/http2/request';
import { environment } from '../../../environments/environment';
import { Http2Service } from '../../services/http2/http2.service';
import { IRequestOpts } from '../../models/http2/request';
import { IAppState } from '../../app.state';
import { IUserState } from '../../state/user.state';

@Injectable({
  providedIn: 'root'
})
export class SuitableJobsService {
  private url = '/assets/data/suitable-jobs.json';
  contextId: string;
  userData: Object = [];

  /**
    * @constructor injects the dependent services
    * @description : The constructor initialises the class variables with the dependencies injected into the class
    * @param {apiService} APIService
   */
  constructor(
    private apiService: APIService,
    private httpService: Http2Service,
    private store: Store<IAppState>
  ) {
    this.store.select('user').subscribe((userState: IUserState) => {
      if (userState.user && userState.user[0].contextID) {
        this.contextId = userState.user[0].contextID;
        this.userData = userState.user[0].loginData;
      }
    });
  }  /**
    * @method getLabelDetails
    * @description:The method fetches labels from the json to display them on user interface
    * @return {Observable} : Observable of data
    */
  public getLabelDetails(): Observable<{}> {
    const request: IAPIServiceOpts<{}> = {
      path: this.url,
    };

    return this.apiService.get(request).pipe(map((res: HttpResponse<{}>) => res.body));
  }

  public postJobDetails(): Observable<{}> {
    const apiPayload = {
      // TODO will be implemented further once we get required details

      candidateID: this.userData['candidate_id'],
      sessionParam: {
        contextId: this.contextId,
        SenderId: this.userData['candidate_id'],
        SenderName: this.userData['user_name']
      }


    };
    return this.apiService.postMethod(apiPayload, environment.api.suitable_jobs);
  }
  /**
   * @method postFormDetails
   * @description: The post method posts all the data that is collected from the form
   * @param {formData}: collecting all the data from the form
   * @returns {Observable}
   */
  public postFormDetails(formData: any): Observable<{}> {
    const options: IAPIServiceOpts<{}> = {
      body: JSON.stringify(formData),
      headers: {
        ['Content-Type']: 'application/json'
      }
    };
    return this.apiService.post(options)
      .pipe(map((res: HttpResponse<{}>) => res.body));
  }
}
