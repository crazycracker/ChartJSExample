/**
 * Global ngrx/store state
 */

import { IUserState } from './state/user.state';

export interface IAppState {
  user: IUserState;
}
