import { TestBed, inject } from '@angular/core/testing';

import { PagerService } from './pager.service';

describe('PagerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PagerService]
    });
  });

  it('should be created', inject([PagerService], (service: PagerService) => {
    expect(service).toBeTruthy();
  }));
  it('should arrange the pages according to page size', inject( [PagerService], ( service: PagerService ) => {
  service.getPager(10, 1, 2);
  expect(service.getPager).toBeTruthy();
  expect(service.getPager(10, 1, 2.).currentPage).toBe(1);
  expect(service.getPager(10, 1, 2.).totalItems).toBe(10);
  expect(service.getPager(10, 1, 2).pageSize).toBe(2);
  expect(service.getPager(10, 1, 2).totalPages).toBe(5);
  expect(service.getPager(10, 1, 2).startPage).toBe(1);
  expect(service.getPager(10, 1, 2).endPage).toBe(5);
  expect(service.getPager(10, 1, 2).startIndex).toBe(0);
  expect(service.getPager(10, 1, 2).endIndex).toBe(1);
  expect(service.getPager(10, 2, 1).pages).toEqual([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
  }));
});
