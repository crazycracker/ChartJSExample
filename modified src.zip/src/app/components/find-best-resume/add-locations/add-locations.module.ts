import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AddLocationsComponent } from '../add-locations/add-locations.component';
import { LocationButtonComponent } from './locationbutton/locationbutton.component';
import { LocationDropDownComponent } from './locationdropdown/locationdropdown.component';
import { LocationSectionComponent } from './section.component';

@NgModule({
    declarations: [
        AddLocationsComponent,
        LocationButtonComponent,
        LocationDropDownComponent,
        LocationSectionComponent
    ],
    exports: [
        AddLocationsComponent,
        LocationButtonComponent,
        LocationDropDownComponent,
        LocationSectionComponent
    ],
    imports: [
        CommonModule,
        FormsModule
    ],
    entryComponents: [
        LocationDropDownComponent
    ]
})
export class AddLocationsModule { }
