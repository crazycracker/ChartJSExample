import { Component, OnInit } from '@angular/core';
import { FindBestResumeService } from '../../../services/find-best-resume-service/find-best-resume.service';

@Component({
  selector: 'app-irene-add-languages',
  templateUrl: './add-languages.component.html',
  styleUrls: ['./add-languages.component.scss']
})
export class AddLanguagesComponent implements OnInit {

  constructor(private service: FindBestResumeService) { }
  public selectItems;
  public data: any = [];
ngOnInit() {
    this.service.getLabelDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.selectItems = this.data.InputValues;
      }
    });
  }

}
