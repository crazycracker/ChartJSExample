import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpResponse } from '@angular/common/http';
import { APIService } from '../api-service/api.service';
import { IAPIServiceOpts } from '../../models/http2/request';
import { Http, Response, Headers } from '@angular/http';
import { Store } from '@ngrx/store';
import { IAppState } from '../../app.state';
import { IUserState } from '../../state/user.state';
import { environment } from '../../../environments/environment';
import { forEach } from '@angular/router/src/utils/collection';

@Injectable({
  providedIn: 'root'
})
export class FindBestResumeService {
  private url = '/assets/data/findBestResume.json';
  contextId;
  userData;

  constructor(
    private apiService: APIService,
    private _http: Http,
    private store: Store<IAppState>
  ) {
    this.store.select('user').subscribe((userState: IUserState) => {
      if (userState.user && userState.user[0].contextID) {
        this.contextId = userState.user[0].contextID;
        this.userData = userState.user[0].loginData;
      }
    });
   }
  public getLabelDetails(): Observable<{}> {
    const request: IAPIServiceOpts<{}> = {
      path: this.url,
    };

    return this.apiService.get(request).pipe(map((res: HttpResponse<{}>) => res.body));
  }
  public postFormDetails(formData: any): Observable<{}>  {
    const body = JSON.stringify(formData);
    const header = new Headers();
    header.append('Content-Type', 'application/json');
    return this._http.post('', body , { headers: header })
    .pipe( map ((res: Response) => res.json) );

  }

  /**
   * @method: fetchCandidateDetails
   * @description: method to initiate the api request for candidate details
   * @return Observable of type response
   */
  public fetchRequisitionIDJobs(jobId): Observable<{}> {
    const request = {
      jobreqId: jobId,
    };

    return this.apiService.postMethod(request, environment.api.job_requisition_details);
  }


  /**
   * @method: fetchBestResume
   * @description: method to initiate the api request for candidate details
   * @return Observable of type response
   */
  public fetchBestResume(): Observable<{}> {
    const request = {
      sessionParam: {
        contextId: this.contextId,
        SenderId: this.userData['candidate_id'],
        SenderName: this.userData['user_name']
      }
    };

    return this.apiService.postMethod(request, environment.api.get_best_resume);
  }

  private parseJSONData(data): Array<object> {
    const parsedData = [];
    data.filter((element) => {
      const x = JSON.parse(element);
      x.profileData = JSON.parse(x.profileData);
      parsedData.push(x);
    });
    return parsedData;
  }

  /**
   * @method: filterBestResume
   * @description: method to initiate the api request for candidate details
   * @param: data to be filtered
   * @param: params based on which needs to be filtered to be filtered
   * @return filtered response
   */
  public filterBestResume(data, params): Array<Object> {
    const parsedData = this.parseJSONData(data);
    return parsedData;
  }
}
