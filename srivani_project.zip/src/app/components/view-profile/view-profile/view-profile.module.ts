
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ViewProfileComponent } from './view-profile.component';

@NgModule({
  declarations: [
    ViewProfileComponent,
  ],
  exports: [
    ViewProfileComponent,
  ],
  imports: [
    CommonModule,
    RouterModule,

  ],
})
export class ViewProfileModule { }
