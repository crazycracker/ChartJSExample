import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpResponse } from '@angular/common/http';
import { APIService } from '../../services/api-service/api.service';
import { IAPIServiceOpts } from '../../models/http2/request';
import { Http, Response, Headers } from '@angular/http';

@Injectable({
  providedIn: 'root'
})
export class SuitableJobsService {
  private url = '/assets/Data/suitable-jobs.json';
  /**
    * @constructor injects the dependent services
    * @description : The constructor initialises the class variables with the dependencies injected into the class
    * @param {apiService} APIService
   */
  constructor(private apiService: APIService, private _http: Http) { }
  public getLabelDetails(): Observable<{}> {
    const request: IAPIServiceOpts<{}> = {
      path: this.url,
    };

    return this.apiService.get(request).pipe(map((res: HttpResponse<{}>) => res.body));
  }
  public postFormDetails(formData: any): Observable<{}>  {
    const options: IAPIServiceOpts<{}> = {
      body: JSON.stringify(formData),
      headers: {
        ['Content-Type']: 'application/json'
      }
    };
    return this.apiService.post(options)
    .pipe( map ((res: HttpResponse<{}>) => res.body) );
  }

}
