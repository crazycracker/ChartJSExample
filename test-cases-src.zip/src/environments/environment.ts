// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  api: {
    chat_service: '/workday-virtual-agent/aaip/workday/chatbot',
    file_upload: '/workday-virtual-agent/aaip/workday/inject',
    fetchprofile_service: '/workday-virtual-agent/aaip/workday/fetchprofiledata',
  },
  config: {
    recaptcha_site_key: '6LdOQCkUAAAAAAStqNngVSoaQoKNpmLf_MergNO0',
  },
  content: {
    collections: {
      countries: 'countryList',
    },
    pages: {
    },
    path: 'api/contentPageService/contentPage/',
  },
  host: 'localhost:4200',
  production: false,
  scheme: 'http',
  url: 'latest-777018cbfeebba53.elb.ap-south-1.amazonaws.com',
};


/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
