import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../services/authentication-service/authentication.service';
import { Store } from '@ngrx/store';
import { IAppState } from '../../app.state';
import { UserLogin } from '../../actions/user.actions';

export interface IUserlogin {
  userName: string;
  password: string;
}

@Component({
  selector: 'app-irene-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})

export class LoginComponent implements OnInit {
  public loginLabels: any;
  public loginHeader: any;
  public loginContent: any;

  public showLoginCard: Boolean = true;

  public isCandidateProfile;
  public toggleEvent;
  public isLoginPage: Boolean = false;
  public userData: any;

  public formData: IUserlogin = {
    userName: '',
    password: '',
  };

  constructor(
    private store: Store<IAppState>,
    private router: Router,
    private authService: AuthenticationService,
  ) { }

  ngOnInit() {
    this.authService.getLoginDetails().subscribe(res => {
      this.loginLabels = res;
      this.loginHeader = this.loginLabels.WebsiteName;
      this.loginContent = this.loginLabels.LoginLabels;
    });
  }

  toggleLoginCard() {
    this.showLoginCard = !this.showLoginCard;
  }

  onSubmit() {
    this.authService.login(this.formData.userName, this.formData.password).subscribe(response => {
      this.isCandidateProfile = response['isCandidate'];
      this.userData = response;
      this.store.dispatch(UserLogin(this.userData));
      if (this.router.url === '/login' || this.router.url === '/forgotPassword') {
        this.isLoginPage = !this.isLoginPage;
      }
    });
  }

}
