import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { IUserState } from '../../state/user.state';
import { IAppState } from '../../app.state';
import { UserLogin } from '../../actions/user.actions';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../services/authentication-service/authentication.service';

@Component({
  selector: 'app-home-layout',
  templateUrl: './home-layout.component.html',
  styleUrls: ['./home-layout.component.scss']
})

export class HomeLayoutComponent {
  title = 'app';
  public isCandidateProfile;
  public toggleEvent;
  public isLoginPage: Boolean = false;
  public userData: any;

  /**
 * @constructor injects the dependent services
 * @description : The constructor initialises the class variables with the dependencies injected into the class
 * @param {store} Store
 * @param {authService} AuthenticationService
 */
  constructor(
    private store: Store<IAppState>,
    private router: Router,
    private authService: AuthenticationService,
  ) {
    this.authService.login('userName', 'password').subscribe(response => {
      this.isCandidateProfile = response[0].isCandidate;
      this.userData = response[0];
      this.store.dispatch(UserLogin(response[0]));
      if (this.router.url === '/login' || this.router.url === '/forgotPassword') {
        this.isLoginPage = !this.isLoginPage;
      }
    });
  }

  public onToggleSideBar(event) {
    this.toggleEvent = event;
  }


  // TODO need to remove this function once User profile login is intergated
  public navigateToHR() {
    this.userData.isCandidate = !this.isCandidateProfile;
    this.store.dispatch(UserLogin(this.userData));
    this.isCandidateProfile = !this.isCandidateProfile;
  }
}
