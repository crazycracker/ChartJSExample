import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

interface Images {
  imageUrl: string;
}

@Component({
  selector: 'app-irene-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss']
})

export class CarouselComponent implements OnInit {
  public showArrows: Boolean = false;
  public displayArray: Array<Images>;
  public storeOrginalArrayIndex: Array<number> = [];
  public selectedItem;

  @Output() public currentImage = new EventEmitter();
  @Input() dataArray: Array<Images>;
  @Input() showNumber: number;

 /**
 * @method ngOnInit
 * @description : Method used to initalize the component
 */
  public ngOnInit(): void {
    this.showArrows = this.dataArray.length > this.showNumber;
    if (this.showArrows) {
      this.displayArray = this.forgeNewArray();
    } else {
      this.displayArray = this.dataArray;
    }
  }

 /**
 * @method showImage
 * @description :Method to get the current image url
 * @param {string} imagePath and index: url and index of selected image
 */
  public showImage(imagePath, index): void {
    this.selectedItem = index;
     this.currentImage.emit(imagePath);
  }

 /**
 * @method setClickedImage
 * @description :Method to get the index of current image
 * @param {string} index :index of selected image
 */
  public setClickedImage(index) {
    this.selectedItem = index;
  }

  /**
   * @method forgeNewArray
   * @description: Method to forge the displayArray of images
   */
  public forgeNewArray(): Array<Images> {
    const arrayReturn: Array<Images> = [];
    for (const arrayItem in this.dataArray) {
      if (parseFloat(arrayItem) < this.showNumber) {
        arrayReturn.push(this.dataArray[arrayItem]);
        this.storeOrginalArrayIndex.push(parseFloat(arrayItem));
      }
    }
    return arrayReturn;
  }

  /**
   *@method moveToNext
   * @description: Method to move to next image in carousel
   */
  public moveToNext(): void {
    const isNextAvailable: boolean = this.storeOrginalArrayIndex[this.storeOrginalArrayIndex.length - 1] === this.dataArray.length - 1;
    if (!isNextAvailable) {
      const endIndex: number = this.storeOrginalArrayIndex[this.storeOrginalArrayIndex.length - 1] + 1;
      const startIndex: number = endIndex - this.showNumber;
      this.buildDisplayArray(startIndex, endIndex);
    }
  }

  /**
   * @method buildDisplayArray
   * @description: Method to Build the display array of images
   * @param {number} startIndex :index of first image in carousel
   * @param {number} endIndex: :index of last image in carousel
   */
  public buildDisplayArray(startIndex: number, endIndex: number): void {

    const arrayReturn: Array<Images> = [];
    this.storeOrginalArrayIndex = [];
    for (const arrayItem in this.dataArray) {
      if (parseFloat(arrayItem) > startIndex && parseFloat(arrayItem) <= endIndex) {
        arrayReturn.push(this.dataArray[arrayItem]);
        this.storeOrginalArrayIndex.push(parseFloat(arrayItem));
      }
    }
    this.displayArray = arrayReturn;
  }

 /**
 * @method moveToPrevious
 * @description :Method to move to previous image in carousel
 */
  public moveToPrevious(): void {
    const isPreviousAvailable: boolean = this.storeOrginalArrayIndex[0] === 0;
    if (!isPreviousAvailable) {
      const startIndex: number = this.storeOrginalArrayIndex[0] - 2;
      const endIndex: number = startIndex + this.showNumber;
      this.buildDisplayArray(startIndex, endIndex);
    }
  }

}
