import { TestBed, inject } from '@angular/core/testing';
import { APIService } from '../../services/api-service/api.service';
import { Http2Service } from '../../services/http2/http2.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { SuitableJobsService } from './suitable-jobs.service';

describe('SuitableJobsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        SuitableJobsService,
        APIService,
        Http2Service,
      ],
    });
  });

  it('should be created', inject([SuitableJobsService], (service: SuitableJobsService) => {
    expect(service).toBeTruthy();
  }));
  it('retrieves all data from json', inject( [SuitableJobsService], ( service: SuitableJobsService ) => {
    service.getLabelDetails().subscribe( result => {
        expect(result).toBeGreaterThan(0);
    });
  }));
  it('should call formDetails method and post the data', inject(
    [SuitableJobsService],
    (service: SuitableJobsService) => {
      spyOn(service, 'postFormDetails').and.callThrough();
      service.postFormDetails(1).subscribe(result => {
          expect(result).toBeDefined();
      });
    }
  ));
});
