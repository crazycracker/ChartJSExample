import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { map } from 'rxjs/operators';
import { Headers } from '@angular/http';
import { HttpResponse } from '@angular/common/http';
import { APIService } from '../api-service/api.service';
import { IAPIServiceOpts } from '../../models/http2/request';
import { environment } from '../../../environments/environment';
import { Http2Service } from '../../services/http2/http2.service';
import { IRequestOpts } from '../../models/http2/request';
import {Profile, ProfileData} from '../../models/user-profile/userProfile';
import { IAppState } from '../../app.state';
import { IUserState } from '../../state/user.state';

@Injectable({
  providedIn: 'root'
})
export class ViewProfileService {
  private url = '/assets/data/viewProfile.json';
  contextId: string;
  userData: object = [];

  constructor(
    private apiService: APIService,
    private httpService: Http2Service,
    private store: Store<IAppState>
  ) {
    this.store.select('user').subscribe((userState: IUserState) => {
      if (userState.user && userState.user[0].contextID) {
        this.contextId = userState.user[0].contextID;
        this.userData = userState.user[0].loginData;
      }
    });
  }
  /**
   * @constructor injects the dependent services
   * @description : The constructor initialises the class variables with the dependencies injected into the class
   * @param {apiservice} APIService
   * @method getLabelDetails
   * @description:The method fetches labels from the json to display them on user interface

   */
  public getLabelDetails(): Observable<{}> {
    const request: IAPIServiceOpts<{}> = {
      path: this.url,
    };

    return this.apiService.get(request).pipe(map((res: HttpResponse<{}>) => res.body));
  }

  public getDummyProfileDetails(): Observable<any> {
    const request: IAPIServiceOpts<{}> = {
      path: '/assets/response/viewProfileResponse.json',
    };
    return this.apiService.get(request).pipe(map((res: HttpResponse<any>) => res.body));
  }

  /**
   * @method fetchProfileDetails
   * @description: The post method posts all the data that is collected from the form
   */
  public fetchProfileDetails(): Observable<{}> {
    const request = {
      userName: this.userData['user_name'],
      candidateID: this.userData['candidate_id'],
      sessionParam: {
        contextId: this.contextId,
        SenderId: this.userData['candidate_id'],
        SenderName: this.userData['user_name']
      }
    };

    return this.apiService.postMethod(request, environment.api.fetchprofile_service);
  }

  /**
   * @method fetchProfileDetails
   * @description: The post method posts all the data that is collected from the form
   */
  public saveProfileDetails(profile: Profile): Observable<{}> {
    const profileData: any = [];
    profileData.push(profile);
    const request = {
      updateProfileData: profileData,
      userName: this.userData['user_name'],
      candidateID: this.userData['candidate_id'],
      sessionParam: {
        contextId: this.contextId,
        SenderId: this.userData['candidate_id'],
        SenderName: this.userData['user_name']
      }
    };

    return this.apiService.postMethod(request, environment.api.updateprofile_service);
  }
}
