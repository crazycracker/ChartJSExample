import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { DocumentsComponent } from './documents.component';
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [
    DocumentsComponent,
  ],
  exports: [
    DocumentsComponent,
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
})
export class DocumentsModule { }
