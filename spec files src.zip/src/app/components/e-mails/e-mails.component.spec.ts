import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { EMailsComponent } from './e-mails.component';
import { APIService } from '../../services/api-service/api.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { EmailsService } from '../../services/emails-service/emails.service';
import { Observable, of } from 'rxjs';
const mockResponse = {
  data: { success: true }
};

const data = [{
  'Labels': [{
    'receivedlabel': 'EMAILS RECEIVED BY ELIXIR',
    'sentlabel': 'REPLIES SENT TO ELIXIR'
  }],
  'EmailsReceived': [{
    'date': '04',
    'month': 'MAR',
    'title': 'Candidate ID number',
    // tslint:disable-next-line:max-line-length
    'description': 'Hi There. Thank you so much for your interest in ELIXIR. We have received your application for Senior Visual Merchandiser... ',
    'link': 'View Full Email'
  }
  ],
  'EmailsSent': [
  ]
}];
class MockAPIService {
  public get(): Observable<{}> {
    return of(mockResponse);
  }
}
class MailsService {
  public getLabelDetails(): Observable<{}> {
    return of(data);
  }
}


describe('EMailsComponent', () => {
  let component: EMailsComponent;
  let fixture: ComponentFixture<EMailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [EMailsComponent],
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        APIService,
        { provide: APIService, useClass: MockAPIService },
        { provide: EmailsService, useClass: MailsService }]
    })
      .compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(EMailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create component and get data from service', inject([EmailsService], (service: EmailsService) => {
    spyOn(service, 'getLabelDetails').and.callThrough();
    expect(component).toBeTruthy();
    service.getLabelDetails();
    component.labels = data;
  })
  );
});
