import {Injectable} from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UtilService {

  constructor() {
  }

  /**
   * @method isObjectEmpty()
   * @description : To check is object is empty or not
   * @return {boolean} : boolean
   */
  public isObjectEmpty(obj: any): boolean {
    return Object.keys(obj).length === 0 && obj.constructor === Object;
  }
}
