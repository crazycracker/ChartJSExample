import { Injectable } from '@angular/core';
import { APIService } from '../api-service/api.service';
import { Observable } from 'rxjs';
import { IAPIServiceOpts } from '../../models/http2/request';
import { HttpResponse } from '@angular/common/http';
import { map } from 'rxjs/internal/operators/map';

@Injectable({
  providedIn: 'root'
})
export class ContactDetailsService {

  private url = '/assets/Data/ContactDetails.json';

  constructor(private apiService: APIService) { }

  /**
   * @method getConatactDetails()
   * @description : Used to Fetch the data from ContactDetails.json
   * @return {Observable} : Observable of data
   */
  public getContactDetails(): Observable<{}> {
    const request: IAPIServiceOpts<{}> = {
      path: this.url,
    };

    return this.apiService.get(request).pipe(map((res: HttpResponse<{}>) => res.body));
  }
}
