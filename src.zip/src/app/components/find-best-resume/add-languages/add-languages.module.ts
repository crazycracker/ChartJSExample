import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { LanguageButtonComponent } from '../add-languages/languagebutton/languagebutton.component';
import { LanguageDropDownComponent } from '../add-languages/languagedropdown/languagedropdown.component';
import { LanguageSectionComponent } from './section.component';
import { AddLanguagesComponent } from '../add-languages/add-languages.component';

@NgModule({
    declarations: [
        LanguageButtonComponent,
        LanguageDropDownComponent,
        LanguageSectionComponent,
        AddLanguagesComponent
    ],
    exports: [
        LanguageButtonComponent,
        LanguageDropDownComponent,
        LanguageSectionComponent,
        AddLanguagesComponent
    ],
    imports: [
        CommonModule,
        FormsModule
    ],
    entryComponents: [

    ]
})
export class AddLanguagesModule { }
