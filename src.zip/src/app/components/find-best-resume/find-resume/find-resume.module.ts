import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FindResumeComponent } from './find-resume.component';
import { FormsModule } from '@angular/forms';
import { AddSkillsComponent } from '../add-skills/add-skills.component';
import { AddLanguagesComponent } from '../add-languages/add-languages.component';
import { AddLocationsComponent } from '../add-locations/add-locations.component';
@NgModule({
  declarations: [
    FindResumeComponent,
    AddSkillsComponent,
    AddLanguagesComponent,
    AddLocationsComponent
  ],
  exports: [
    FindResumeComponent,
    AddSkillsComponent,
    AddLanguagesComponent,
    AddLocationsComponent
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
})
export class FindResumeModule { }
