import {Action} from '@ngrx/store';
import {Profile} from '../models/user-profile/userProfile';
import {ICoreAction} from './actions';

export const FETCH_PROFILE = 'FETCH_PROFILE';
export const REMOVE_PROFILE = 'REMOVE_PROFILE';

class ProfileAction implements ICoreAction<any> {
  constructor(
    public readonly type: string,
    public readonly payload: Profile,
  ) {
  }
}

export const FetchProfile: (profile: Profile) => ProfileAction =
  (profile: Profile) => new ProfileAction(FETCH_PROFILE, profile);

export const RemoveProfile: () => ProfileAction =
  () => new ProfileAction(REMOVE_PROFILE, null);
