import { Component, OnInit } from '@angular/core';
import { ScreenedProfileService } from '../../services/screened_profile-service/screened-profile.service';
@Component({
  selector: 'app-irene-screened-profile',
  templateUrl: './screened-profiles.component.html',
  styleUrls: ['./screened-profiles.component.scss']
})
export class ScreenedProfilesComponent implements OnInit {
  /**
   * current: For using accordion on dropdown
   * iteration: For iterating table values
   * loop: For iterating education and work experience inside dropdown click function
   */
  public show = false;
  current = 0;
  constructor(private service: ScreenedProfileService) { }
  public data: any = [];
  public labels;
  public iteration;
  public loop;
  ngOnInit() {
    this.service.getDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.labels = this.data[0].Labels[0];
        this.iteration = this.data[0];
        this.loop = this.data[0];
      }
    });
  }
  /**
    * @method toggle()
    * @description : Used to Change the value of show false to true for the click fn of dropdown
    */
  toggle() {
    this.show = !this.show;
  }
}




