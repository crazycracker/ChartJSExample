import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AddSkillsComponent } from '../add-skills/add-skills.component';
@NgModule({
    declarations: [
        AddSkillsComponent
    ],
    exports: [
        AddSkillsComponent
    ],
    imports: [
        CommonModule,
        FormsModule
    ],
    entryComponents: [

    ]
})
export class AddSkillsModule { }
