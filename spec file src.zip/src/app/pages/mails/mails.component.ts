import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-irene-mails',
  templateUrl: './mails.component.html',
  styleUrls: ['./mails.component.scss']
})
export class MailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
