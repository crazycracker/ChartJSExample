import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LanguageDropDownComponent } from './languagedropdown.component';

describe('LanguageDropDownComponent', () => {
  let component: LanguageDropDownComponent;
  let fixture: ComponentFixture<LanguageDropDownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LanguageDropDownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LanguageDropDownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
