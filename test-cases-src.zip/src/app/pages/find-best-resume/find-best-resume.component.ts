import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-find-best-resume',
  templateUrl: './find-best-resume.component.html',
  styleUrls: ['./find-best-resume.component.scss']
})
export class FindBestResumeComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }


}
