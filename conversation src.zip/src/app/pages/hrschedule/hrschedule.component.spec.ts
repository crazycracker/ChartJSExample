import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HrscheduleComponent } from './hrschedule.component';

describe('HrscheduleComponent', () => {
  let component: HrscheduleComponent;
  let fixture: ComponentFixture<HrscheduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HrscheduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HrscheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
