import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-languagebutton',
  templateUrl: './languagebutton.component.html',
  styleUrls: ['./languagebutton.component.scss']
})
export class LanguageButtonComponent {
  @Output() addComponentClick = new EventEmitter();
   constructor() { }
// tslint:disable-next-line:eofline
}