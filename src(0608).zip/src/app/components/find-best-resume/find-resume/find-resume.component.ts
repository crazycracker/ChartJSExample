import { Component, OnInit } from '@angular/core';
import { FindBestResumeService } from '../../../services/find-best-resume-service/find-best-resume.service';

import 'rxjs';

export interface IKeyValue {
  key: string;
  value: string;
}

export interface ISkills {
  value: string;
  proficiency: '';
}

export interface IStateCity {
  state: IKeyValue;
  city: IKeyValue;
}

export interface IRecruiterFormData {
  skillsWeightage: string;
  jobid: string;
  hardskills: Array<ISkills>;
  softskills: Array<ISkills>;
  industryWeightage: string;
  industryType: string;
  subType: string;
  candidateDetailsWeightage: string;
  qualifications: string;
  lastExperienceInMedical: string;
  languagesKnownHeading: string;
  languagesKnown: Array<string>;
  educationAndOrganizationDetails: string;
  topAcademicInstitutions: string;
  organizations: string;
  profilesRequired: string;
  employmentType: string;
  employmentTypeInput: string;
  primaryLocations: string;
  cityState: Array<IStateCity>;
  priorityOfTheJobInput: string;
  priorityofthejob: string;
  diversity: string;
}

@Component({
  selector: 'app-find-resume',
  templateUrl: './find-resume.component.html',
  styleUrls: ['./find-resume.component.scss']
})
export class FindResumeComponent implements OnInit {
  constructor(private service: FindBestResumeService) {}
  public labels;
  public selectItems;
  public defaultChoice = 'Low';
  public initalLoad: Boolean = true;
  public skillproficiency = [];
  public availableLanguages = [];
  public data: any = [];
  public cityList: Array<object> = [];
  public stateList: Array<object> = [];
  public formData: IRecruiterFormData = {
    skillsWeightage: '',
    jobid: '',
    hardskills: [
      {
        value: '',
        proficiency: '',
      }
    ],
    softskills: [
      {
        value: '',
        proficiency: '',
      }
    ],
    industryWeightage: '',
    industryType: '',
    subType: '',
    candidateDetailsWeightage: '',
    qualifications: '',
    lastExperienceInMedical: '',
    languagesKnownHeading: '',
    languagesKnown: [''],
    educationAndOrganizationDetails: '',
    topAcademicInstitutions: '',
    organizations: '',
    profilesRequired: '',
    employmentType: '',
    employmentTypeInput: '',
    primaryLocations: '',
    cityState: [{ state: {key: '', value: ''}, city: {key: '', value: ''} }],
    priorityOfTheJobInput: '',
    priorityofthejob: '',
    diversity: '',
  };

  ngOnInit() {
    this.service.getLabelDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.labels = this.data.Labels;
        this.selectItems = this.data.InputValues;
        this.skillproficiency = this.data.skillproficiency;
        this.availableLanguages = this.data.availableLanguages;
        this.cityList = this.selectItems.city;
        this.stateList = this.selectItems.state;
      }
    });
  }

  public formDetails() {
    console.log(this.formData);
    this.service
      .postFormDetails(this.formData)
      .subscribe(data => console.log(data));
  }

  public addFeilds(value, field) {
    if (field === 'hardskills' || field === 'softskills') {
      this.formData[field].push(
        {
          value: value,
          proficiency: this.defaultChoice
        }
      );
    } else if (field === 'languagesKnown') {
      this.formData[field].push('');
    } else {
      this.formData[field].push({ state: '', city: '' });
    }
  }

  public removeSkill(skill): void {
    // const index = this.skills.indexOf(skill);
    // this.skills.splice(index, 1);
  }

  public onSelectionChange(skillType, skill,  entry) {
    this.formData[skillType].filter((element) => {
      if (element.value === skill) {
        element.proficiency = entry;
      }
    });
}

public filterForeCasts(filterVal: any, index) {
  if (filterVal !== '0') {
    this.formData.languagesKnown.splice(index, 1, filterVal);
  }
}

public compareFn(c1: any, c2: any): boolean {
  return c1 && c2 ? c1.id === c2.id : c1 === c2;
}

}
