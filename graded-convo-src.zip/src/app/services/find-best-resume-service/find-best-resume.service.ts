import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpResponse } from '@angular/common/http';
import { APIService } from '../api-service/api.service';
import { IAPIServiceOpts } from '../../models/http2/request';
import { Http, Response, Headers } from '@angular/http';
import { Store } from '@ngrx/store';
import { IAppState } from '../../app.state';
import { IUserState } from '../../state/user.state';
import { environment } from '../../../environments/environment';
import { forEach } from '@angular/router/src/utils/collection';

@Injectable({
  providedIn: 'root'
})
export class FindBestResumeService {
  private url = '/assets/data/findBestResume.json';
  contextId;
  userData;

  constructor(
    private apiService: APIService,
    private _http: Http,
    private store: Store<IAppState>
  ) {
    this.store.select('user').subscribe((userState: IUserState) => {
      if (userState.user && userState.user[0].contextID) {
        this.contextId = userState.user[0].contextID;
        this.userData = userState.user[0].loginData;
      }
    });
   }
  public getLabelDetails(): Observable<{}> {
    const request: IAPIServiceOpts<{}> = {
      path: this.url,
    };

    return this.apiService.get(request).pipe(map((res: HttpResponse<{}>) => res.body));
  }
  public postFormDetails(formData: any): Observable<{}>  {
    const body = JSON.stringify(formData);
    const header = new Headers();
    header.append('Content-Type', 'application/json');
    return this._http.post('', body , { headers: header })
    .pipe( map ((res: Response) => res.json) );

  }

  /**
   * @method: fetchCandidateDetails
   * @description: method to initiate the api request for candidate details
   * @return Observable of type response
   */
  public fetchRequisitionIDJobs(jobId): Observable<{}> {
    const request = {
      jobreqId: jobId,
    };

    return this.apiService.postMethod(request, environment.api.job_requisition_details);
  }

  /**
   * @method: fetchBestResume
   * @description: method to initiate the api request for candidate details
   * @return Observable of type response
   */
  public mapJobRequisitionData(formData, jobData) {
    formData.jobid = jobData.jobReqID;
    formData.diversity = jobData.diversity;
    formData.subType = jobData.industrySubType;
    formData.industryType = jobData.industryType;
    formData.industryWeightage = jobData.industryWeightage;
    formData.languagesKnown = jobData.languageKnown === null ? ['Select'] : jobData.languageKnown;
    formData.qualifications = jobData.qualification;
    formData.skillsWeightage = jobData.skillsWeightage;
    formData.hardskills = this.createSkillData(jobData.hardSkills.hardSkill);
    formData.softskills = this.createSkillData(jobData.softSkills.softSkill);
    formData.jobDescription = jobData.jobDescription;
    return formData;
  }

  private createSkillData(skill) {
    const skillArray = [];
    for (let i = 0; i < 5; i++) {
      skillArray.push({
        value: skill[i],
        proficiency: 'low',
      });
    }
    return skillArray;
  }


  /**
   * @method: fetchBestResume
   * @description: method to initiate the api request for candidate details
   * @return Observable of type response
   */
  public fetchBestResume(formData): Observable<{}> {
    const request = {
      jobReqId : formData.jobid,
      skillWeightage : formData.skillsWeightage,
      hardSkill : formData.hardskills,
      softSkill : formData.softskills,
      industryWeightage : formData.industryWeightage,
      industryType : formData.industryType,
      industrySubtype : formData.subType,
      candidateDetailsWeightage : formData.candidateDetailsWeightage,
      qualification : formData.qualifications,
      lastExperienceInMedical : formData.lastExperienceInMedical,
      diversity : formData.diversity,
      languagesKnown : formData.languagesKnown,
      numberOfProfilesRequired : formData.profilesRequired,
      employmentTypeWeightage : formData.employmentTypeWeightage,
      employmentType : formData.employmentType,
      state : this.cityStateData(formData.cityState, 'state'),
      city : this.cityStateData(formData.cityState, 'city'),
      priorityOfJobWeightage : formData.priorityofthejobWeightage,
      priorityOfJob : formData.priorityOfTheJob,
      jobDescription: formData.jobDescription,
      sessionParam: {
        contextId: this.contextId,
        SenderId: this.userData['candidate_id'],
        SenderName: this.userData['user_name']
      }
    };
    return this.apiService.postMethod(request, environment.api.get_best_resume);
  }


  private cityStateData(list, location) {
    const locationArray = [];
    for (let i = 0; i < list.length; i++) {
      locationArray.push(list[i][location]);
    }
    return locationArray;
  }

  private parseJSONData(data): Array<object> {
    const parsedData = [];
    data.filter((element) => {
      const x = JSON.parse(element);
      x.profileData = JSON.parse(x.profileData);
      parsedData.push(x);
    });
    return parsedData;
  }

  /**
   * @method: filterBestResume
   * @description: method to initiate the api request for candidate details
   * @param: data to be filtered
   * @param: params based on which needs to be filtered to be filtered
   * @return filtered response
   */
  public filterBestResume(data, params): Array<Object> {
    const parsedData = this.parseJSONData(data);
    return parsedData;
  }
}
