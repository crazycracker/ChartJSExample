import { Component, OnInit } from '@angular/core';
import { CalendarService } from '../../services/calendar-service/calendar.service';

@Component({
  selector: 'app-irene-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.scss']
})
export class CalendarComponent implements OnInit {

  public data: any = [];
  public labels;
  public days;
  public dates;
  constructor(private service: CalendarService) { }

  ngOnInit() {
    this.service.getLabelDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.labels = this.data[0].Labels[0];
        this.days = this.data[0].Days;
        this.dates = this.data[0].Dates;
      }
    });
  }
}
