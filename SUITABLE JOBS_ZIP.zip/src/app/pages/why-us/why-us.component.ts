import { Component, OnInit } from '@angular/core';
import { WhyUsConstants } from './whyus.constants.component';

interface Images {
  imageUrl: string;
}

@Component({
  selector: 'app-irene-why-us',
  templateUrl: './why-us.component.html',
  styleUrls: ['./why-us.component.scss']
})


export class WhyUsComponent implements OnInit {

public imageUrl: Array<Images> = WhyUsConstants;
public imagePath: any;
public showImage = this.imageUrl[0].imageUrl;
noOfScreens = 7;

  constructor() { }

 /**
 * @method showCurremtImage
 * @description :Method to get the currentImage path from carousel componen
 * @param {string} currentImage: url of selected image
 */

showCurremtImage(currentImage: HTMLElement): void {
  this.showImage = currentImage['imageUrl'] ;
  }

 /**
 * @method ngOnInit
 * @description : Method used to determine the size of window at the time of loading the application
 */
  ngOnInit() {
    if (window.screen.width < 1025) { // 768px portrait
      this.noOfScreens = 3;
  }
 }
}
