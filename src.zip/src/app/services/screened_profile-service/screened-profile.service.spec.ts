import { TestBed, inject } from '@angular/core/testing';

import { ScreenedProfileService } from './screened-profile.service';

describe('ScreenedProfileService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ScreenedProfileService]
    });
  });

  it('should be created', inject([ScreenedProfileService], (service: ScreenedProfileService) => {
    expect(service).toBeTruthy();
  }));
});
