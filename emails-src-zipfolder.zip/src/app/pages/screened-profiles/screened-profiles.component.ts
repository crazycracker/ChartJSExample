import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'irene-profiles',
  templateUrl: './screened-profiles.component.html',
  styleUrls: ['./screened-profiles.component.scss']
})
export class ScreenedProfilesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}