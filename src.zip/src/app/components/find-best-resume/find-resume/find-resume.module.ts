import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FindResumeComponent } from './find-resume.component';
import { FormsModule } from '@angular/forms';
import { AddSkillsComponent } from '../add-skills/add-skills.component';
@NgModule({
  declarations: [
    FindResumeComponent,
    AddSkillsComponent
  ],
  exports: [
    FindResumeComponent,
    AddSkillsComponent
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
})
export class FindResumeModule { }
