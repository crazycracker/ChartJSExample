import { Component, Input, ViewContainerRef } from '@angular/core';

@Component({
   // tslint:disable-next-line:component-selector
   selector: 'div[app-type=Locationsection]',
   template: '',
   styles: ['div { width: 100% }']
})
export class LocationSectionComponent {
  @Input() active: boolean;
   /**
   * @constructor injects the dependant services
   * @description The constructor initialises the class variables with the dependencies injected into the class
   * @param  {ViewContainerRef} viewContainerRef
   */
   constructor(public viewContainerRef: ViewContainerRef) { }
}
