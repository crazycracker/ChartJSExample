import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAnotherFeatureComponent } from './add-another-feature.component';

describe('AddAnotherFeatureComponent', () => {
  let component: AddAnotherFeatureComponent;
  let fixture: ComponentFixture<AddAnotherFeatureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddAnotherFeatureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddAnotherFeatureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
