import { Component, OnInit } from '@angular/core';
import { WhyUsConstants } from './whyus.constants.component';

interface Images {
  imageUrl: string;
}

@Component({
  selector: 'app-irene-why-us',
  templateUrl: './why-us.component.html',
  styleUrls: ['./why-us.component.scss']
})


export class WhyUsComponent {

public imageUrl: Array<Images> = WhyUsConstants;
public imagePath: any;

  constructor() { }

 /**
 * @method showCurremtImage
 * @description :Method to get the currentImage path from carousel componen
 * @param {string} currentImage: url of selected image
 */

showCurremtImage(currentImage: HTMLElement): void {
  document.getElementById('mainImage').style.backgroundImage = 'url(' + currentImage['imageUrl'] + ')';
  }

}
