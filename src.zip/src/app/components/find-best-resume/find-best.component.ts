import { Component, OnInit } from '@angular/core';
import { FindBestResumeService } from '../../services/find-best-resume-service/find-best-resume.service';
@Component({
  selector: 'app-find-resume',
  templateUrl: './find-best.component.html',
  styleUrls: ['./find-best.component.scss']
})
export class FindResumeComponent implements OnInit {

  constructor(private service: FindBestResumeService) { }
  public labels;
  public selectItems;
  public data: any = [];
  ngOnInit() {
    this.service.getLabelDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.labels = this.data[0].Labels[0];
        this.selectItems = this.data[0].InputValues[0];
      }
    });
  }

}
