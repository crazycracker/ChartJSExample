import { TestBed, inject } from '@angular/core/testing';

import { Workspace360Service } from './workspace360.service';

describe('Workspace360Service', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [Workspace360Service]
    });
  });

  it('should be created', inject([Workspace360Service], (service: Workspace360Service) => {
    expect(service).toBeTruthy();
  }));
});
