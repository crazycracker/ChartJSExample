import { Component, Input, ViewContainerRef } from '@angular/core';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'div[app-type=Languagesection]',
  template: '',
})
export class LanguageSectionComponent {
  @Input() active: boolean;
  /**
   * @constructor injects the dependant services
   * @description The constructor initialises the class variables with the dependencies injected into the class
   * @param  {ViewContainerRef} viewContainerRef
   */
  constructor(public viewContainerRef: ViewContainerRef) { }
}
