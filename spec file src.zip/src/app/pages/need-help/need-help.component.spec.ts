import { async, ComponentFixture, TestBed, inject} from '@angular/core/testing';
import { APIService } from '../../services/api-service/api.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NeedHelpComponent } from './need-help.component';
import { of, Observable} from 'rxjs';
import {ContactDetailsService} from '../../services/contact-service/contact-details.service';

const MockResponse = {
  data: {success: true}
};
const data = {
  'ContactInfo' : [
      {
      'headerText': 'If you are a Healthcare Professional seeking job opportunities with us please feel free to contact us:',
      'ContactLabel': 'NEED HELP WITH CONTACT INFORMATION ?',
      'CallLabel': 'Call HR Now',
       'ContactNo': '+1-512-512-5120',
       'EmailLabel': 'Send Us a Message',
       'EmailID': 'Recruitment-team@Elixir.com',
       'SalesInfo': 'HR Hours',
       'SalesTime': '7am - 7pm CST',
       'MailLabel': 'MAILING ADDRESS',
       'MailAdd1': '22, Crescent Street',
       'MailAdd2': 'Austin, Texas 78701'
  }
  ]
};
class MockAPIService  {
  public get(): Observable<{}> {
    return of(MockResponse);
  }
}
class MockNeedhelpService {
  public getContactDetails(): Observable<{}> {
    return of(data);
  }
}
describe('NeedHelpComponent', () => {
  let component: NeedHelpComponent;
  let fixture: ComponentFixture<NeedHelpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NeedHelpComponent ],
      imports: [
        HttpClientTestingModule
      ],
      providers: [
        APIService,
        {provide : APIService , useClass : MockAPIService},
        {provide : ContactDetailsService , useClass : MockNeedhelpService}
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NeedHelpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should fetch data from the Service', inject([ContactDetailsService], (service: ContactDetailsService) => {
    spyOn(service, 'getContactDetails').and.callThrough();
    service.getContactDetails();
    expect(component.needContact).toBeDefined();
  }));
});
