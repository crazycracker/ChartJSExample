export const environment = {
  api: {
    chat_service: '/workday-virtual-agent/aaip/workday/chatbot',
    file_upload: '/workday-virtual-agent/aaip/workday/inject',
    login_service: '/workday-virtual-agent/aaip/workday/authenticateuser',
    fetchprofile_service: '/workday-virtual-agent/aaip/workday/fetchprofiledata',
  },
  production: true,
  host: 'ec2-13-232-88-48.ap-south-1.compute.amazonaws.com',
  scheme: 'https',
  url: 'ec2-13-232-88-48.ap-south-1.compute.amazonaws.com/backend',

  // host: '13.232.88.48',
  // scheme: 'http',
  // url: 'latest-777018cbfeebba53.elb.ap-south-1.amazonaws.com',
};
