/**
 * Pages module
 */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ComponentsModule } from '../components/components.module';
import { ChatbotComponent } from './chatbot/chatbot.component';
import { FindBestResumeComponent } from './find-best-resume/find-best-resume.component';
import { ScreenedProfilesComponent } from './screened-profiles/screened-profiles.component';
import { LoginComponent } from './login/login.component';
import { SuitableJobsComponent } from './suitable-jobs/suitable-jobs.component';
import { FaqsComponent } from './faqs/faqs.component';
import { NeedHelpComponent } from './need-help/need-help.component';
import { WhyUsComponent } from './why-us/why-us.component';
import { ProfileComponent } from './profile/profile.component';
import { SearchHistoryComponent } from './search-history/search-history.component';
import { DocumentpageComponent } from './documentpage/documentpage.component';
import { MailsComponent } from './mails/mails.component';
import { Workspace360Component } from './workspace360/workspace360.component';
import { FullCalendarComponent } from './full-calendar/full-calendar.component';

@NgModule({
  declarations: [
  ChatbotComponent,
  FindBestResumeComponent,
  ScreenedProfilesComponent,
  LoginComponent,
  SuitableJobsComponent,
  FaqsComponent,
  NeedHelpComponent,
  WhyUsComponent,
  ProfileComponent,
  SearchHistoryComponent,
  DocumentpageComponent,
  MailsComponent,
  Workspace360Component,
  FullCalendarComponent,
],
  imports: [
    CommonModule,
    ComponentsModule,
    FormsModule,
  ],
})
export class PagesModule { }
