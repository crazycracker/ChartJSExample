import { async, ComponentFixture, TestBed , inject} from '@angular/core/testing';
import { SearchResultsComponent } from './search-results.component';
import { APIService } from '../../../services/api-service/api.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { SuitableJobsService } from '../../../services/suitable-jobs-service/suitable-jobs.service';
import {Observable, of} from 'rxjs';
const mockResponse = {
  data: { success: true }
};
const data = [{
  'Labels': [{
    'titleLabel': 'Suitable Jobs For You',
    'radioButton1Label': 'All keywords',
    'radioButton2Label': 'Any keywords',
    'advancedsearchLabel': 'Advanced Search',
    'rolesLabel': 'Roles and Responsibility:',
    'applyNowLabel': 'APPLY NOW',
    'favouriteLabel': 'FAVORITE'
  }],
  'InputValues': [{
    'location': [
      {
        'key': '1',
        'value': 'Hyderabad'
      },
    ],
    'experience': [
      {
        'key': '1',
        'value': '1-2 yrs'
      },
    ]
  }],
  'SuitableJobs': [{
      'JOB_REQ_ID': 'E-00001',
      'Job_Posting_Title': 'Multiple Customer Service Career Opportunities!',
      'Number_of_Openings_Total': '0',
      'Job_Description_Summary': ' trouble-shooting and problem escalation.',
      'Job_Description': '<p>Our</p>',
      'Qualifications': 'Job Competence (Proficient); Conflict Management (Proficient); Core Values (Proficient)',
      'Recruiting_Start_Date': '2017-02-13',
      'Scheduled_Weekly_Hours': '40',
      'Worker_Sub-Type_Hiring_Requirement': 'Regular',
      'Job_Requisition_Primary_Location': 'Chicago',
      'Job_Requisition_Additional_Locations_-_External_Name': 'New York; San Francisco',
      'Time_Type_Hiring_Requirement': 'Full time',
      'Pay_Rate_Type': 'Exception Hourly; Salaried',
      'Contract_Pay_Rate': '0',
      'referenceID': 'Full_time',
      'Primary_Internal_Questionnaire': 'Customer Service',
      'Primary_External_Questionnaire': 'Customer Service',
      'Secondary_External_Questionnaire': 'External - Eligibility',
      'Post': 'Posted on - 12th Jan',
      'Job_Posting_Details_group': [{
          'Post_Job_Business_Process': 'Post Job: E-00001 Multiple Customer Service Career Opportunities!'
        },
        {
          'Post_Job_Business_Process': 'Post Job: E-00001 Multiple Customer Service Career Opportunities!'
        }
      ]
    },
  ],
  'Links': [{
    'rel': 'alternate',
    'href': 'https://www.google.com/'
  }]
}];
class MockAPIService {
  public get(): Observable<{}> {
    return of(mockResponse);
  }
}
class  SearchresultMockService  {
  public  getLabelDetails(): Observable<{}> {
    return of(data);
  }
}
describe('SearchResultsComponent', () => {
  let component: SearchResultsComponent;
  let fixture: ComponentFixture<SearchResultsComponent>;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SearchResultsComponent],
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        APIService,
        { provide: APIService, useClass: MockAPIService },
        { provide:  SuitableJobsService,  useClass:  SearchresultMockService }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create component and get data from service',  inject([SuitableJobsService], (service: SuitableJobsService) => {
    spyOn(service, 'getLabelDetails').and.callThrough();
    expect(component).toBeTruthy();
    service.getLabelDetails();
   component.labels = data;
})
);
it('should call the toggleImage function and change the image on click', () => {
  component.toggleImage('assets/icons/screened-profiles-icon.png');
  expect(component.imageRef.value).toBe('assets/icons/screened-profiles-icon.png');
});
});
