import { TestBed, inject } from '@angular/core/testing';
import { APIService } from '../../services/api-service/api.service';
import { Http2Service } from '../../services/http2/http2.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Workspace360Service } from './workspace360.service';

describe('Workspace360Service', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        Workspace360Service,
        APIService,
        Http2Service,
      ],
    });
  });

  it('should be created', inject([Workspace360Service], (service: Workspace360Service) => {
    expect(service).toBeTruthy();
  }));
  it('retrieves all data from json', inject( [Workspace360Service], ( service: Workspace360Service ) => {
    service.getLabelDetails().subscribe( result => {
        expect(result).toBeGreaterThan(0);
    });
  }));
});

