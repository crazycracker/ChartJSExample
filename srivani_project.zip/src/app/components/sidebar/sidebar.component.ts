import { Component, OnInit, OnDestroy } from '@angular/core';
import { AppIreneNavConstants, AppHRNavConstants } from '../../app.constants.component';
import { Router } from '@angular/router';

import { Store } from '@ngrx/store';
import { IUserState } from '../../state/user.state';
import { IAppState } from '../../app.state';

import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

// interface created for navigation Items
interface InavItems {
  linkText: string;
  imageUrl: string;
  navigateTo: Object;
}

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})

export class SidebarComponent implements OnInit, OnDestroy {
  public NavItems: Array<InavItems> = [];
  public selectedItem = 1;
  public isCandidateProfile;
  private ngUnsubscribe: Subject<void> = new Subject<void>();

  /**
   * @constructor injects the dependent services
   * @description : The constructor initialises the class variables with the dependencies injected into the class
   * @param {store} Store
   */
  constructor(private store: Store<IAppState>,
  private router: Router) { }

  /**
   * @method ngOnInit
   * @description : Method used to initalize the component
   */
  ngOnInit() {
    this.store
      .select((storeState: IAppState) => storeState.user)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe(
        (userState: IUserState): void => {
          if (userState.user) {
            this.isCandidateProfile = userState.user['isCandidate'];
            this.NavItems = this.isCandidateProfile ? AppIreneNavConstants : AppHRNavConstants;
          }
        }
      );
  }

  /**
   * @method setClickedRow
   * @description : Method used to highlight the selected navigation item
   * @param {string} index: index of selected item
   */
  public setClickedRow (index) {
    this.selectedItem = index;
  }

  /**
   * @method ngOnDestroy
   * @description Method to clean up any listeners when the component is destroyed
   * to prevent memory leaks and resource consumption
   */
  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

/**
   * @method needHelp
   * @description : Method used to navigate to need-help page
   */
public needHelp(): void {
  this.router.navigate(['/needhelp']);
  }

  /**
   * @method meetPeople
   * @description : Method used to navigate to why-us page
   */
  public meetPeople(): void {
    this.router.navigate(['/whyus']);
  }
}
