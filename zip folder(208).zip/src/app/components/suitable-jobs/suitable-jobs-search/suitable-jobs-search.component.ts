import { Component, OnInit } from '@angular/core';
import { SuitableJobsService } from '../../../services/suitable-jobs-service/suitable-jobs.service';

@Component({
  selector: 'app-irene-suitable-jobs-search',
  templateUrl: './suitable-jobs-search.component.html',
  styleUrls: ['./suitable-jobs-search.component.scss']
})
export class SuitableJobsSearchComponent implements OnInit {
  public data: any = [];
  public labels;
  public selectItems;
  public expanded = false;
  public expanded1 = false;

  /**
  * @constructor injects the dependent services
  * @description : The constructor initialises the class variables with the dependencies injected into the class
  * @param {service} SuitableJobsService
 */
  constructor(private service: SuitableJobsService) { }

  /**
   * @method ngOnInit
   * @description : Method used to initalize the component
   */
  ngOnInit() {
    this.service.getLabelDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.labels = this.data[0].Labels[0];
        this.selectItems = this.data[0].InputValues[0];
      }
    });
  }
  public showCheckboxes() {
    const checkboxes = document.getElementById('checkboxes');
    if (!this.expanded) {
      checkboxes.style.display = 'block';
      this.expanded = true;
    } else {
      checkboxes.style.display = 'none';
      this.expanded = false;
    }
  }
  public showCheckboxes1() {
    const checkboxes1 = document.getElementById('checkboxes1');
    if (!this.expanded1) {
      checkboxes1.style.display = 'block';
      this.expanded1 = true;
    } else {
      checkboxes1.style.display = 'none';
      this.expanded1 = false;
    }
  }
}


