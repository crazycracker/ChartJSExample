/**
 * Defines global user state
 */

import { User } from '../models/user-profile/user';

export interface IUserState {
  loggedIn: boolean;
  lastActive: number;
  user?: User;
}
