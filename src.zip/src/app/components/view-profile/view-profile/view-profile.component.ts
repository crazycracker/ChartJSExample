import { Component, OnInit } from '@angular/core';
import { ViewProfileService } from '../../../services/view-profile-service/view-profile.service';
import { monthsConstants } from '../../../app.constants.component';
@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrls: ['./view-profile.component.scss']
})
export class ViewProfileComponent implements OnInit {
  public data: any = [];
  public labels;
  public isEditEducation: Boolean = false;
  public isEditExperience: Boolean = false;
  public isEditContact: Boolean = false;
  public isEditSkills: Boolean = false;
  public isEditInProgress: Boolean = false;
  public selectItems;
  public years = [];
  public months = monthsConstants;
  constructor(private service: ViewProfileService) { }

  ngOnInit() {


    const year = new Date().getFullYear();
    const range = [];
    range.push(year);
    for (let i = 1; i < 47; i++) {
      range.push(year - i);
    }
    this.years = range;


    this.service.getLabelDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.labels = this.data[0].Labels[0];
        this.selectItems = this.data[0].InputValues[0];

      }
    });
  }
  public enableEdit(section) {
    this.isEditEducation = false;
    this.isEditExperience = false;
    this.isEditContact = false;
    this.isEditSkills = false;
    this.enableDisableSection(section);
  }
  private enableDisableSection(sectionName) {
    if (sectionName === 'education') {
      this.isEditEducation = !this.isEditEducation;
    }
    if (sectionName === 'experience') {
      this.isEditExperience = !this.isEditExperience;
    }
    if (sectionName === 'contact') {
      this.isEditContact = !this.isEditContact;
    }
    if (sectionName === 'skills') {
      this.isEditSkills = !this.isEditSkills;
    }
  }

  public saveData(section) {
    this.enableDisableSection(section);
  }
}

