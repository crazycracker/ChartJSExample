import { Component, OnInit } from '@angular/core';
import { SearchHistoryService } from '../../services/search-history/search-history.service';
import { expandCollapse } from '../../utils/animations/carousel.component.animations';
import {PagerService} from '../../services/Pagination-service/pager.service';

@Component({
  selector: 'app-search-history-component',
  templateUrl: './search-history-component.component.html',
  styleUrls: ['./search-history-component.component.scss'],
  animations: [expandCollapse]
})
export class SearchHistoryComponentComponent implements OnInit {

  public searchHistorydata: any;
  public searchHistoryLabel: any;
  public searchHistoryValues: any;
  private allItems: any[];
  public pager: any = {};
  public  pagedItems: any[];

  constructor(private searchHistory: SearchHistoryService,
              private pagerService: PagerService) { }

   /**
   * @method ngOnInit
   * @description : Getting the data from SearchHistory service
   */
  ngOnInit(): void {
    this.searchHistory.getSearchHistoryDetails().subscribe(res => {
      this.searchHistorydata = res;
      this.searchHistoryLabel = this.searchHistorydata.Labels;
      this.allItems = this.searchHistorydata.InputValues;
      this.setPage(1);
    });
  }

 /**
 * @method setPage
 * @description :Method to get the search history data with pagination
 * @param {number} page: no of page
 */
  setPage(page: number) {
    // get pager object from service
    this.pager = this.pagerService.getPager(this.allItems.length, page);

    // get current page of items
    this.pagedItems = this.allItems.slice(this.pager.startIndex, this.pager.endIndex + 1);
    console.log(this.pagedItems);
}
}
