/**
 * Constants
 */
export const AppComponentConstants = {
  PAGE_LOAD: 'On Page Load',
};
export const AppRouteConstants = {
  // Routes
  CHATBOT: 'chatbot',
  FAQs: 'faqs',
  LOGIN: 'login',
  MY_PROFILE: 'myprofile',
  WORK_LOCATION: 'worklocation',
  FIND_BEST_RESUME: 'findbestresume',
  SCREENED_PROFILE : 'screenedprofile',
  SUITABLE_JOBS: 'suitablejobs',
  FORGOT_PASSWORD: 'forgotPassword',
  NEED_HELP: 'needhelp',
  VIEW_PROFILE: 'viewprofile',
  WHY_US: 'whyus',
  SEARCH_HISTORY: 'search-history'
};
export const AppIreneNavConstants = [
  {
    linkText: 'My Profile',
    imageUrl: '../assets/icons/profile-icon@2x.png',
    navigateTo: ['/viewprofile']
   },
   {
    linkText: 'Chatbot',
    imageUrl: '../assets/icons/chatbot@2x.png',
    navigateTo: ['/chatbot']
   },
  //  {
  //   linkText: 'Work Locations',
  //   imageUrl: '../assets/icons/location@2x.png',
  //   navigateTo: ['/chatbot']
  //  },
  //  {
  //   linkText: 'Workspace 360',
  //   imageUrl: '../assets/icons/360@2x.png',
  //   navigateTo: ['/chatbot']
  //  },
   {
    linkText: 'Suitable Jobs',
    imageUrl: '../assets/icons/jobs@2x.png',
    navigateTo: ['/suitablejobs']
   },
  //  {
  //   linkText: 'Calender',
  //   imageUrl: '../assets/icons/calender@2x.png',
  //   navigateTo: ['/chatbot']
  //  },
  //  {
  //   linkText: 'Documents',
  //   imageUrl: '../assets/icons/documents.png',
  //   navigateTo: ['/chatbot']
  //  },
  //  {
  //   linkText: 'E-mails',
  //   imageUrl: '../assets/icons/email@2x.png',
  //   navigateTo: ['/chatbot']
  //  },
   {
    linkText: 'FAQs',
    imageUrl: '../assets/icons/faq@2x.png',
    navigateTo: ['/faqs']
   },
];
export const AppHRNavConstants = [
  {
    linkText: 'My Profile',
    imageUrl: '../assets/icons/profile-icon@2x.png',
    navigateTo: ['/viewprofile']
   },
   {
    linkText: 'Find Best Resume',
    imageUrl: '../assets/icons/find-best-resume-icon@2x.png',
    navigateTo: ['/findbestresume']
   },
   {
    linkText: 'Search History',
    imageUrl: '../assets/icons/search-history-icon@2x.png',
    navigateTo: ['/search-history']
   },
   {
    linkText: 'Screened Profiles',
    imageUrl: '../assets/icons/screened-profiles-icon@2x.png',
    navigateTo: ['/screenedprofile']
   },
   {
    linkText: 'Analytics',
    imageUrl: '../assets/icons/analytics-icon@2x.png',
    navigateTo: ['/findbestresume']
   },
];

export const monthsConstants = ['JAN', 'FEB', 'MAR', 'APR', 'May', 'JUN',
'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

export const ChatConstants = {
  AM: 'AM',
  PM: 'PM',
  FILE_TYPE_PDF: 'pdf',
  FILE_TYPE_DOC: 'docx'
};
