import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'irene-search-history',
  templateUrl: './search-history.component.html',
  styleUrls: ['./search-history.component.scss']
})
export class SearchHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
