import { TestBed, inject } from '@angular/core/testing';
import { APIService } from '../../services/api-service/api.service';
import { Http2Service } from '../../services/http2/http2.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FindBestResumeService } from './find-best-resume.service';
import { HttpModule } from '@angular/http';

describe('FindBestResumeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        HttpModule
      ],
      providers: [
        FindBestResumeService,
        APIService,
        Http2Service,
      ],
    });
  });

  it('should be created', inject([FindBestResumeService], (service: FindBestResumeService) => {
    expect(service).toBeTruthy();
  }));
});
