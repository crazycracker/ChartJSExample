import { async, ComponentFixture, inject,  TestBed } from '@angular/core/testing';
import { APIService } from '../../services/api-service/api.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FaqsComponent } from './faqs.component';
import { FaqsService } from '../../services/faq-service/faqs.service';
import {Observable, of} from 'rxjs';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

const mockResponse = {
  data: { success: true }
};

const data = {
  'Header': {
    'label': 'Frequently Asked Questions'
  },
  'FAQs': [{
      'title': 'Can I apply for another position while one is in progress?',
      'description': ' getting you onboard with us. Having said that, you must be a versatile professional!',
      'category': 'Multiple job applications'
  }]
};
class MockAPIService {
  public get(): Observable<{}> {
    return of(mockResponse);
  }
}
class  FaqMockService {
  public getFaqDetails(): Observable<{}> {
    return of(data);
  }
}
describe('FaqsComponent', () => {
  let component: FaqsComponent;
  let fixture: ComponentFixture<FaqsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FaqsComponent ],
      imports: [
        HttpClientTestingModule,
        BrowserAnimationsModule
      ],
      providers: [
        APIService,
        { provide: APIService, useClass: MockAPIService },
        { provide:  FaqsService,  useClass:  FaqMockService },

      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FaqsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create and get data from service',  inject([FaqsService], (service: FaqsService) => {
    spyOn(service, 'getFaqDetails').and.callThrough();
     service.getFaqDetails();
     component.faqs = data;
    expect(component).toBeTruthy();
  })
  );
});
