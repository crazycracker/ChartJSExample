import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ChatService } from '../../services/chatbot-service/chat.service';
import { SpeechRecognitionService } from '../../services/chatbot-service/speech-recognition.service';



@Component({
  selector: 'app-chatbot-page',
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.scss']
})

export class ChatbotComponent implements OnInit, OnDestroy {

  public replyMessage: any = '';
  public chatMessages: any = [];
  public nochat: Boolean = true;
  public fileName: String = '';
  public date: any;
  public hours: number;
  public minutes: any;
  public ampm: string;
  public strTime: any;
  public completeDate: any;
  public fileSize: any;
  public attachment: boolean;
  public fileType: any;
  public height: any = 280;
  public marginLeft: any = 'auto';
  public errorFlag: Boolean = false;
  public chatbotMessages: any;
  public recognition: any;
  public final_transcript: any;
  public errorFlagGreater: Boolean = false;

  constructor(private chatService: ChatService, private http: HttpClient,
    private speechRecognitionService: SpeechRecognitionService) { }

  /**
   * @method ngOnInit
   * @description : Getting the Constants from chatbot.constants Component
   */

  ngOnInit(): void {
    this.chatService.getChatDetails().subscribe(res => {
      this.chatbotMessages = res;
    });
  }
  public replyReceived(): void {
    this.attachment = false;
    if (this.replyMessage !== '') {
      this.nochat = false;
      this.marginLeft = 5;
      if (this.height > 100) {
        this.height = this.height - 30;
      }
      this.date = new Date();
      this.hours = this.date.getHours();
      this.minutes = this.date.getMinutes();
      this.ampm = this.hours >= 12 ? 'PM' : 'AM';
      this.hours = this.hours % 12;
      this.hours = this.hours ? this.hours : 12; // the hour '0' should be '12'
      this.minutes = this.minutes < 10 ? '0' + this.minutes : this.minutes;
      this.strTime = this.hours + ':' + this.minutes + ' ' + this.ampm;
      this.chatMessages.push({
        'text': this.replyMessage,
        'self': true,
        'timeStamp': this.strTime
      });
      this.nochat = false;
      this.completeDate = this.date.getFullYear() + '-'
        + this.date.getMonth() + '-'
        + this.date.getDate();
      const a = this.replyMessage;
      const b: any = a.split('.')[a.split('.').length - 1];
      if (b === 'pdf') {
        this.attachment = true;
        this.fileType = b;
      }
      if (b === 'txt') {
        this.attachment = true;
        this.fileType = b;
      }
      this.replyMessage = '';
      this.strTime = '';
    }
  }
  /**
 * Method to handle file click
 * If any feature is to be overriden
*/
  public handleFileInput(): void {
    // Ride overrides if required
  }

  /**
   * @description: Method to actually send file to server via
   * http protocol.
   * @param: files {File}, as selected by user
   */
  public uploadFileSet(files: File[]): void {
    this.errorFlag = false;
    this.errorFlagGreater = false;
    this.fileSize = 0;
    this.replyMessage = files[0].name;
    this.fileSize = (files[0].size / 1024).toFixed(2);
    if (parseInt(this.fileSize, 10) < 2) {
      this.errorFlag = true;
      this.replyMessage = '';
    }
    if (parseInt(this.fileSize, 10) > 200) {
      this.errorFlagGreater = true;
      this.replyMessage = '';
    }
    const formData: FormData = new FormData();
    Array.from(files).forEach(f => formData.append('file', f));
    console.log(formData);
    console.log(this.fileSize);
    this.http.post('https://abcd.com', formData)
      .subscribe(event => {
      });
  }

  /**
   * @descrition: start Capturing speech
   */
  public startCapture(): void {
    const msg = new SpeechSynthesisUtterance(this.replyMessage);
    msg.lang = 'en-GB';
    window.speechSynthesis.speak(msg);


    this.speechRecognitionService.recordVoice()
      .subscribe(
        (recordedObject) => {
          this.replyMessage = recordedObject;
        },
        (err) => {
          if (err.error === 'no speech') {
            this.startCapture();
          }
        }
      );
  }


  /**
   * @description: End capture event
  */
  public endCapture(): void {
    this.speechRecognitionService.destroySpeechObject();
  }

  /**
   * @description: angular lifecycle hook
   */
  public ngOnDestroy(): void {
    this.speechRecognitionService.destroySpeechObject();
  }
}
