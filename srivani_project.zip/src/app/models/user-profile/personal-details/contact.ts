/**
 * Data model for a account summary contact
 */

export interface IContact {
  contactType?: string;
  phoneNumber?: string;
  preferedContact?: string;
}
export class Contact implements IContact {
  constructor(
  public contactType: string,
  public phoneNumber: string,
  public preferedContact: string,
  ) { }
}
