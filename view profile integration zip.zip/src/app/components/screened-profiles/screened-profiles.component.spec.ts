import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ScreenedProfilesComponent } from './screened-profiles.component';
import { APIService } from '../../services/api-service/api.service';
import { Http2Service } from '../../services/http2/http2.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('ScreenedProfilesComponent', () => {
  let component: ScreenedProfilesComponent;
  let fixture: ComponentFixture<ScreenedProfilesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ScreenedProfilesComponent ],
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        APIService,
        Http2Service,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScreenedProfilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
