import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ScreenedProfilesComponent } from './screened-profiles.component';
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [
    ScreenedProfilesComponent,
  ],
  exports: [
    ScreenedProfilesComponent,
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
})
export class ProfileTileModule { }
