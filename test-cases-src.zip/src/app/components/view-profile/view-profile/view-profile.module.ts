import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {RouterModule} from '@angular/router';

import {ModalModule} from '../../modal/modal.module';
import {ViewProfileComponent} from './view-profile.component';

@NgModule({
  declarations: [
    ViewProfileComponent,

  ],
  exports: [
    ViewProfileComponent,

  ],
  imports: [
    CommonModule,
    RouterModule,
    ModalModule,
    FormsModule
  ],
})
export class ViewProfileModule {
}
