import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import { ViewProfileService } from "../../../services/view-profile-service/view-profile.service";
import { monthsConstants } from "../../../app.constants.component";
import { ModalComponent } from "../../modal/modal.component";
import {
  ContactData,
  EducationData,
  ExperienceData,
  SkillsData,
  ProfileData,
  IContactData,
  IEducationData,
  IExperienceData,
  ISkillData
} from "../../../models/user-profile/userProfile";
import { Store } from "@ngrx/store";
import { IAppState } from "../../../app.state";
import { IUserState } from "../../../state/user.state";

@Component({
  selector: "app-view-profile",
  templateUrl: "./view-profile.component.html",
  styleUrls: ["./view-profile.component.scss"]
})
export class ViewProfileComponent implements OnInit {
  public data: any = [];
  public labels;
  public isEditEducation: Boolean = false;
  public isEditExperience: Boolean = false;
  public isEditContact: Boolean = false;
  public isEditSkills: Boolean = false;
  public isEditInProgress: Boolean = false;
  public selectItems;
  public years = [];
  public formData;
  public months = monthsConstants;
  public experienceData: ExperienceData;
  public educationData: EducationData;
  public skillsData: SkillsData;
  public contactData: ContactData;
  public isCandidateProfile;
  public userData: any;
  public profileData: ProfileData;

  @ViewChild("updateProfileImage")
  profileImageModal: ModalComponent;
  @ViewChild("saveSection")
  saveSectionModal: ModalComponent;
  constructor(
    private service: ViewProfileService,
    private element: ElementRef,
    private store: Store<IAppState>
  ) {}

  /**
   * @method {ngOnIt}
   *@description: The method gets the data from the Json
   */

  ngOnInit() {
    const year = new Date().getFullYear();
    const range = [];
    range.push(year);
    for (let i = 1; i < 47; i++) {
      range.push(year - i);
    }
    this.years = range;
    this.service.getLabelDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.labels = this.data[0].Labels[0];
        this.selectItems = this.data[0].InputValues[0];
      }
    });
    this.store.select("user").subscribe((userState: IUserState) => {
      if (userState.user && userState.user["isCandidate"]) {
        this.isCandidateProfile = userState.user["isCandidate"];
      }
    });

    this.service.postProfileDetails(this.profileData).subscribe(res => {
      this.profileData = res["body"].profileData;
      console.log(this.profileData);
      this.contactData = {} as IContactData;
      this.educationData = {} as IEducationData;
      this.experienceData = {} as IExperienceData;
      this.skillsData = {} as ISkillData;
      this.contactData.contactDetails = this.profileData.contactDetails;
      this.educationData.educationalDetails = this.profileData.educationalDetails;
      this.experienceData.experienceDetails = this.profileData.experienceDetails;
      this.skillsData.skills = this.profileData.skills;
    });
  }
  /**@method {pushDataInEditMode}
   * @description:This method pushes data that is being edited in edit mode
   * @param {pushTo}:Specifies item to be added  to the beginning of element
   */
  pushDataInEditMode(data, pushTo): void {
    data.forEach(element => {
      pushTo.unshift(element);
    });
  }

  public enableEdit(section) {
    this.isEditEducation = false;
    this.isEditExperience = false;
    this.isEditContact = false;
    this.isEditSkills = false;
    this.enableDisableSection(section);
  }
  private enableDisableSection(sectionName) {
    if (sectionName === "education") {
      this.isEditEducation = !this.isEditEducation;
      this.educationData = {
        educationalDetails: [
          {
            fromYearEducation: "",
            fromMonthEducation: "",
            toYearEducation: "",
            toMonthEducation: "",
            instituteEducation: ""
          }
        ]
      };
      this.pushDataInEditMode(
        this.labels.educationalDetails,
        this.educationData.educationalDetails
      );
    }
    if (sectionName === "experience") {
      this.isEditExperience = !this.isEditExperience;
      this.experienceData = {
        experienceDetails: [
          {
            fromYearExperience: "",
            fromMonthExperience: "",
            toYearExperience: "",
            toMonthExperience: "",
            companyExperience: "",
            designationExperience: "",
            imageLink: ""
          }
        ]
      };
      this.pushDataInEditMode(
        this.labels.experienceDetails,
        this.experienceData.experienceDetails
      );
    }
    if (sectionName === "contact") {
      this.isEditContact = !this.isEditContact;
      this.contactData = {
        contactDetails: [
          {
            mobile: "",
            email: "",
            address: ""
          }
        ]
      };
    }
    if (sectionName === "skills") {
      this.isEditSkills = !this.isEditSkills;
      this.skillsData = {
        skills: [
          {
            imageLink: "",
            skillLabel: this.selectItems.skillDetails[0].value
          }
        ]
      };
      this.pushDataInEditMode(this.labels.skillDetails, this.skillsData.skills);
    }
  }

  /**
   *@method {saveData}
   *@description: The method posts the data collected from the form
   *@param { section}:this specifies which data we are collecting from the form
   */
  public saveData(section) {
    this.enableDisableSection(section);
    // this.saveSectionModal.openModal();
    if (section === "education") {
      this.formData = this.educationData;
    } else if (section === "experienceData") {
      this.formData = this.experienceData;
    } else if (section === "skillsData") {
      this.formData = this.skillsData;
    } else {
      this.formData = this.contactData;
    }
  }
  /**
   * @method addEducationalDetails
   *@description: The method posts the educationalDetails collected from education field in the form to the server
   */
  public addEducationalDetails() {
    this.educationData["educationalDetails"].push({
      fromYearEducation: "",
      fromMonthEducation: "",
      toYearEducation: "",
      toMonthEducation: "",
      instituteEducation: ""
    });
  }
  /**
   * @method addExperienceDetails
   *@description:This method posts the experienceDetails collected from the experience field in form to the server
   */
  public addExperienceDetails() {
    this.experienceData["experienceDetails"].push({
      fromYearExperience: "",
      fromMonthExperience: "",
      toYearExperience: "",
      toMonthExperience: "",
      companyExperience: "",
      designationExperience: "",
      imageLink: ""
    });
  }
  /**
   * @method addSkills
   *@description:This method posts the skills data collected from the skills field in form to the server
   */
  public addSkills() {
    this.skillsData["skills"].push({
      imageLink: "",
      skillLabel: this.selectItems.skillDetails[0].value
    });
  }
  /**
   * @method addContactDetails
   *@description: This method posts the contactDetails collected from the contact field in form to the server
   */
  public addContactDetails() {
    this.contactData["contactDetails"].push({
      mobile: "",
      email: "",
      address: ""
    });
  }

  /**
   * @method saveModal
   * @description the method passes the closeModal command to the viewchild
   */
  public saveModal(): void {
    this.saveSectionModal.closeModal();
  }

  /**
   * @method openModal
   * @description the method passes the openModal command to the viewchild
   */
  public openModal(): void {
    this.profileImageModal.openModal();
  }

  /**
   * @method closeModal
   * @description the method passes the Close Modal command to the viewchild
   */
  public closeModal(): void {
    this.profileImageModal.closeModal();
  }

  /**
   * @method editPicture
   * @description the method passes the openModal command to the viewchild
   */
  public editPicture() {
    this.profileImageModal.openModal();
  }
  public cancel(section) {
    this.enableDisableSection(section);
  }
  removePicture() {
    const image = this.element.nativeElement.querySelector(".change-image");
    image.src = "assets/images/profile@2x.png";
  }

  numberOnly(event): Boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  removeAddedRow(section, index) {
    if (section === "educationalDetails") {
      this.educationData[section].splice(index, 1);
    } else if (section === "experienceDetails") {
      this.experienceData[section].splice(index, 1);
    } else {
      this.skillsData[section].splice(index, 1);
    }
  }
}
