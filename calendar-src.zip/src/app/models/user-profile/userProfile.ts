/**
 * Represents a user profile
 */

import {PageContent} from './pageContent';
import {PersonalDetails} from './personal-details/personalDetails';
import {JobPreference} from './personal-details/jobPreference';

export interface IUserProfile {
  pageContent?: Array<PageContent>;
  personalDetail?: PersonalDetails;
  jobPreference?: JobPreference;
}

export class UserProfile implements IUserProfile {
  constructor(
    public pageContent?: Array<PageContent>,
    public personalDetail?: PersonalDetails,
    public jobPreference?: JobPreference,
  ) {
  }
}

interface IRecruiterFormData {
  fromYearEducation: string;
  fromMonthEducation: string;
  toYearEducation: string;
  toMonthEducation: string;
  instituteEducation: string;
}

export class RecruiterFormData implements IRecruiterFormData {
  constructor(
    public fromYearEducation: string,
    public fromMonthEducation: string,
    public toYearEducation: string,
    public toMonthEducation: string,
    public instituteEducation: string,
  ) {
  }
}

interface IContactFormData {
  phoneNumber: string;
  personalEmailId: string;
  address: string;
}

export class ContactFormData implements IContactFormData {
  constructor(
    public phoneNumber: string,
    public personalEmailId: string,
    public address: string,
  ) {
  }
}

interface IContactData {
  contactDetails: Array<IContactFormData>;
}

export class ContactData implements IContactData {
  constructor(
    public contactDetails: Array<IContactFormData>,
  ) {
  }
}

interface IEducationData {
  educationalDetails: Array<IRecruiterFormData>;
}

export class EducationData implements IEducationData {
  constructor(
    public educationalDetails: Array<IRecruiterFormData>,
  ) {
  }
}

interface IExperienceFormData {
  fromYearExperience: string;
  fromMonthExperience: string;
  toYearExperience: string;
  toMonthExperience: string;
  companyExperience: string;
  designationExperience: string;
  companyName: string;
}

export class ExperienceFormData implements IExperienceFormData {
  constructor(
    public fromYearExperience: string,
    public fromMonthExperience: string,
    public toYearExperience: string,
    public toMonthExperience: string,
    public companyExperience: string,
    public designationExperience: string,
    public companyName: string,
  ) {
  }
}

interface IExperienceData {
  experienceDetails: Array<IExperienceFormData>;
}

export class ExperienceData implements IExperienceData {
  constructor(
    public experienceDetails: Array<IExperienceFormData>,
  ) {
  }
}

export interface ISkills {
  skillIcon: string;
  skillLabel: string;
}

export class SkillFormData implements ISkills {
  constructor(
    public skillIcon: string,
    public skillLabel: string,
  ) {
  }
}

interface ISkillData {
  skills: Array<ISkills>;
}

export class SkillsData implements ISkillData {
  constructor(
    public skills: Array<ISkills>,
  ) {
  }
}

export interface IProfile {
  educationalDetails: Array<IRecruiterFormData>;
  experienceDetails: Array<IExperienceFormData>;
  skillDetails: Array<ISkills>;
  phoneNumber: string;
  personalEmailId: string;
  address: string;
  firstName: string;
  lastName: string;
  country: string;
  gender: string;
  disability: string;
  postalCode: string;
  research: string;
  veteranStatus: string;
  yearsOfExperience: string;
  careerSummary: string;
  state: string;
  hispanic_Latino: string;
  race: string;
  languages: string;
  volunteer_Community_Experience: string;
  personalAttributes: string;
  certifications: string;
  aspiration: string;
  maritalStatus: string;
  hobby: string;
}

export class Profile implements IProfile {
  constructor(
    public educationalDetails: Array<IRecruiterFormData>,
    public experienceDetails: Array<IExperienceFormData>,
    public skillDetails: Array<ISkills>,
    public phoneNumber: string,
    public personalEmailId: string,
    public address: string,
    public firstName: string,
    public lastName: string,
    public country: string,
    public gender: string,
    public disability: string,
    public postalCode: string,
    public candidateID: string,
    public research: string,
    public veteranStatus: string,
    public yearsOfExperience: string,
    public careerSummary: string,
    public state: string,
    public hispanic_Latino: string,
    public race: string,
    public languages: string,
    public volunteer_Community_Experience: string,
    public personalAttributes: string,
    public certifications: string,
    public aspiration: string,
    public maritalStatus: string,
    public hobby: string,
  ) {
  }
}

export interface IProfileData {
  profileData: Array<ProfileData>;
}

export class ProfileData implements IProfileData {
  constructor(
    public profileData: Array<ProfileData>,
  ) {
  }
}
