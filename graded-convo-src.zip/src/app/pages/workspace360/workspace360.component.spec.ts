import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Workspace360Component } from './workspace360.component';

describe('Workspace360Component', () => {
  let component: Workspace360Component;
  let fixture: ComponentFixture<Workspace360Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Workspace360Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Workspace360Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
