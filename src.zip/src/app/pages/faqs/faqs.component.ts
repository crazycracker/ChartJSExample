import { Component, OnInit } from '@angular/core';
import { FaqsService } from '../../services/faq-service/faqs.service';
import { expandCollapse } from './faqs.component.animations';
@Component({
  selector: 'app-irene-faqs',
  templateUrl: './faqs.component.html',
  styleUrls: ['./faqs.component.scss'],
  animations: [ expandCollapse ]
})
export class FaqsComponent implements OnInit {
  current: any = 0;
  public faqMessages: any;
  public faqHeader: any;
  public faqs: any;

  constructor(private faqService: FaqsService) {}

  /**
   * @method ngOnInit
   * @description : Getting the data from FaqService
   */
  ngOnInit() {
    this.faqService.getFaqDetails().subscribe(res => {
      this.faqMessages = res;
      this.faqHeader = this.faqMessages.Header;
      this.faqs = this.faqMessages.FAQs;
    });
  }
}
