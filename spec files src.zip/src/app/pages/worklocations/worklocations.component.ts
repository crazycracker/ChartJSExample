import { Component, OnInit } from '@angular/core';
import { WorklocationsService } from '../../services/worklocations/worklocations.service';

interface IformData {
  category: string;
  location: string;
}
export class Locationdata implements IformData {
  constructor(
    public category: string,
    public location: string,
    ) { }
}

@Component({
  selector: 'app-irene-worklocations',
  templateUrl: './worklocations.component.html',
  styleUrls: ['./worklocations.component.scss']
})
export class WorklocationsComponent implements OnInit {
  latitude;
  longitude;
  public data: any = [];
  public labels;
  public selectJobs;
  public selectItems;
  public locations;
  public formData;
  public selectedLocation;
  zoom = 16;
  currentLocationData = [];
  constructor(private service: WorklocationsService) { }
  /**
   * @method ngOnInit
   * @description : Method used to initalize the component
   */

  ngOnInit() {
    this.latitude = 1.29418;
    this.longitude = 103.85;
    this.service.getLabelDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.labels = this.data.Labels;
        this.selectJobs = this.data.Worklocations;
        this.currentLocationData = this.selectJobs;
        this.locations = this.data.Locations;
        this.selectItems = this.data.InputValues;
        this.formData = new Locationdata(this.selectItems.Category[0], '');
      }
    });
  }
  counter(i: number) {
    return new Array(i);
  }

  addLocations(category) {
    if (category === 'Primary Office') {
      this.selectedLocation = this.selectItems.PrimaryOffice;
    } else if (category === 'Research Centre') {
      this.selectedLocation = this.selectItems.ResearchOffice;
    } else if (category === 'Sales Office') {
      this.selectedLocation = this.selectItems.SalesOffice;
    }
    this.formData.location = 'Select Location';
  }

  setMapLocation() {
    this.selectedLocation.filter((item) => {
      if (item.value === this.formData.location) {
        this.latitude = item.lat;
        this.longitude = item.lang;
      }
    });
    this.fetchData();
  }

  private fetchData() {
    this.currentLocationData = [];
    this.selectJobs.filter((item) => {
      if (item.placeName === this.formData.location) {
        this.currentLocationData.push(item);
      }
    });
  }

}
