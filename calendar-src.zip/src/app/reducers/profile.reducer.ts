import { Action } from '@ngrx/store';
import { Profile } from '../models/user-profile/userProfile';
import * as ProfileAction from '../actions/profile.actions';
import {ICoreAction} from '../actions/actions';

/**
 * Ngrx reducer for profile
 * @param {ProfileAction} action - Fetch Profile action
 * @return {Profile} - The new user state
 */
export function profileReducer(state: Profile[] = [], action: ICoreAction<any>) {

  switch (action.type) {
    case ProfileAction.FETCH_PROFILE :
      return [...state, action.payload];
    case ProfileAction.REMOVE_PROFILE :
      return [];
    default:
      return state;
  }
}
