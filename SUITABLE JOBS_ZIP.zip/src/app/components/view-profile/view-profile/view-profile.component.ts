import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ViewProfileService } from '../../../services/view-profile-service/view-profile.service';
import { monthsConstants } from '../../../app.constants.component';
import { ModalComponent } from '../../modal/modal.component';
import { ContactData, EducationData, ExperienceData, SkillsData} from '../../../models/user-profile/userProfile';

@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrls: ['./view-profile.component.scss']
})
export class ViewProfileComponent implements OnInit {
  public data: any = [];
  public labels;
  public isEditEducation: Boolean = false;
  public isEditExperience: Boolean = false;
  public isEditContact: Boolean = false;
  public isEditSkills: Boolean = false;
  public isEditInProgress: Boolean = false;
  public selectItems;
  public years = [];
  public formData;
  public months = monthsConstants;
  @ViewChild('updateProfileImage') profileImageModal: ModalComponent;
  @ViewChild('saveSection') saveSectionModal: ModalComponent;
  constructor(
    private service: ViewProfileService, private element: ElementRef
  ) { }

  public educationData: EducationData = {
    educationalDetails: [{
      fromYearEducation: '',
      fromMonthEducation: '',
      toYearEducation: '',
      toMonthEducation: '',
      instituteEducation: '',
    }]

  };

  public experienceData: ExperienceData = {
    experienceDetails: [{
      fromYearExperience: '',
      fromMonthExperience: '',
      toYearExperience: '',
      toMonthExperience: '',
      companyExperience: '',
      designationExperience: '',
    }]
  };

  public skillsData: SkillsData = {
    skills: [''],
  };

  public contactData: ContactData = {
    contactDetails: [{
      mobile: '',
      email: '',
      address: '',
    }]
  };

  /**
  * @method {ngOnIt}
  *@description: The method gets the data from the Json
    */

  ngOnInit() {
    const year = new Date().getFullYear();
    const range = [];
    range.push(year);
    for (let i = 1; i < 47; i++) {
      range.push(year - i);
    }
    this.years = range;
    this.service.getLabelDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.labels = this.data[0].Labels[0];
        this.selectItems = this.data[0].InputValues[0];
      }
    });
  }

  public enableEdit(section) {
    this.isEditEducation = false;
    this.isEditExperience = false;
    this.isEditContact = false;
    this.isEditSkills = false;
    this.enableDisableSection(section);
  }
  private enableDisableSection(sectionName) {
    if (sectionName === 'education') {
      this.isEditEducation = !this.isEditEducation;
    }
    if (sectionName === 'experience') {
      this.isEditExperience = !this.isEditExperience;
    }
    if (sectionName === 'contact') {
      this.isEditContact = !this.isEditContact;
    }
    if (sectionName === 'skills') {
      this.isEditSkills = !this.isEditSkills;
    }
  }
  /**
    * @method {saveData}
    *@description: The method posts the data collected from the form
     *@param { section}:this specifies which data we are collecting from the form
      */
  public saveData(section) {
    this.enableDisableSection(section);
    // this.saveSectionModal.openModal();
    if (section === 'education') {
      this.formData = this.educationData;
    } else if (section === 'experienceData') {
      this.formData = this.experienceData;
    } else if (section === 'skillsData') {
      this.formData = this.skillsData;
    } else {
      this.formData = this.contactData;
    }
    this.service
      .postFormDetails(this.formData)
      .subscribe(data => console.log(data));
  }
  /**
  * @method addEducationalDetails
  *@description: The method posts the educationalDetails collected from education field in the form to the server
        */
  public addEducationalDetails() {
    this.educationData['educationalDetails'].push({
      fromYearEducation: '',
      fromMonthEducation: '',
      toYearEducation: '',
      toMonthEducation: '',
      instituteEducation: '',
    });
  }
  /**
* @method addExperienceDetails
*@description:This method posts the experienceDetails collected from the experience field in form to the server
      */
  public addExperienceDetails() {
    this.experienceData['experienceDetails'].push({
      fromYearExperience: '',
      fromMonthExperience: '',
      toYearExperience: '',
      toMonthExperience: '',
      companyExperience: '',
      designationExperience: '',
    });
  }
  /**
* @method addSkills
*@description:This method posts the skills data collected from the skills field in form to the server
       */
  public addSkills() {
    this.skillsData['skills'].push('');
  }
  /**
* @method addContactDetails
*@description: This method posts the contactDetails collected from the contact field in form to the server
      */
  public addContactDetails() {
    this.contactData['contactDetails'].push({
      mobile: '',
      email: '',
      address: '',
    });
  }

  /**
   * @method saveModal
   * @description the method passes the closeModal command to the viewchild
   */
  public saveModal(): void {
    this.saveSectionModal.closeModal();
  }


  /**
   * @method openModal
   * @description the method passes the openModal command to the viewchild
   */
  public openModal(): void {
    this.profileImageModal.openModal();
  }

  /**
  * @method closeModal
  * @description the method passes the Close Modal command to the viewchild
  */
  public closeModal(): void {
    this.profileImageModal.closeModal();
  }

  /**
  * @method editPicture
  * @description the method passes the openModal command to the viewchild
  */
  public editPicture() {
    this.profileImageModal.openModal();

  }
  public cancel(section) {
    this.enableDisableSection(section);
  }
  removePicture() {
    const image = this.element.nativeElement.querySelector('.change-image');
    image.src = 'assets/images/profile@2x.png';
  }

}
