import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import {  ScheduleComponent } from './schedule.component';
import { FormsModule } from '@angular/forms';
import {ModalModule} from '../modal/modal.module';

@NgModule({
  declarations: [
    ScheduleComponent,
  ],
  exports: [
    ScheduleComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    ModalModule
  ],
})
export class ScheduleModule {
}
