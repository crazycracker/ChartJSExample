import { Component, OnInit } from '@angular/core';
import { FaqsService } from '../../services/chatbot-service/faqs.service';
import { expandCollapse } from './faqs.component.animations';
@Component({
  selector: 'irene-faqs',
  templateUrl: './faqs.component.html',
  styleUrls: ['./faqs.component.scss'],
  animations: [ expandCollapse ]
})
export class FaqsComponent implements OnInit {
  current: Number = 0;
  public faqMessages: any;
  public header: any;
  public faqs: any;

  constructor(private faqService: FaqsService) {}

  /**
   * @method ngOnInit
   * @description : Getting the data from FaqService
   */
  ngOnInit() {
    this.faqService.getFaqDetails().subscribe(res => {
      this.faqMessages = res;
      this.header = this.faqMessages.Header;
      this.faqs = this.faqMessages.FAQs;
    });
  }
}
