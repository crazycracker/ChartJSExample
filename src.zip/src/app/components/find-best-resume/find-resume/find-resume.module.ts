import { LocationDropDownComponent } from './../add-locations/locationdropdown/locationdropdown.component';
import { LanguageButtonComponent } from './../add-languages/languagebutton/languagebutton.component';
import { LanguageDropDownComponent } from './../add-languages/languagedropdown/languagedropdown.component';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FindResumeComponent } from './find-resume.component';
import { AddSkillsComponent } from '../add-skills/add-skills.component';
import { AddLanguagesModule } from '../add-languages/add-languages.module';
import { AddLocationsModule } from '../add-locations/locationdropdown/add-locations.module';

@NgModule({
  declarations: [
    FindResumeComponent,
    AddSkillsComponent
  ],
  exports: [
    FindResumeComponent,
    AddSkillsComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    AddLanguagesModule,
    AddLocationsModule
  ],
  entryComponents: [
    LanguageDropDownComponent,
    LocationDropDownComponent
  ]
})
export class FindResumeModule { }
