import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AppRouteConstants } from './app.constants.component';
import { ChatbotComponent } from './pages/chatbot/chatbot.component';
import { FindBestResumeComponent } from './pages/find-best-resume/find-best-resume.component';
import { SuitableJobsComponent } from './pages/suitable-jobs/suitable-jobs.component';
import { FaqsComponent } from './pages/faqs/faqs.component';


const Routes: Routes = [
  { path: '', redirectTo: AppRouteConstants.CHATBOT, pathMatch: 'full' },
  { path: AppRouteConstants.CHATBOT, component: ChatbotComponent },
  { path: AppRouteConstants.FIND_BEST_RESUME, component: FindBestResumeComponent },
  { path: AppRouteConstants.SUITABLE_JOBS, component: SuitableJobsComponent },
  { path: AppRouteConstants.FAQs, component: FaqsComponent }
];

@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forRoot(Routes)],
  providers: [],
})
export class AppRoutingModule {
}
