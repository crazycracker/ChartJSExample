/**
 * Represents a user profile
 */

import { PageContent } from './pageContent';
import { PersonalDetails } from '../user-profile/personal-details/personalDetails';
import { JobPreference } from './personal-details/jobPreference';

export interface IUserProfile {
  pageContent?: Array<PageContent>;
  personalDetail?: PersonalDetails;
  jobPreference?: JobPreference;
}
export class UserProfile implements IUserProfile {
  constructor(
  public pageContent?: Array<PageContent>,
  public personalDetail?: PersonalDetails,
  public jobPreference?: JobPreference,
  ) { }
}
