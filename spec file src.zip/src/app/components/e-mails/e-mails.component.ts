import { Component, OnInit } from '@angular/core';
import { EmailsService } from '../../services/emails-service/emails.service';
@Component({
  selector: 'app-irene-e-mails',
  templateUrl: './e-mails.component.html',
  styleUrls: ['./e-mails.component.scss']
})
export class EMailsComponent implements OnInit {
  public data: any = [];
  public labels;
  public received;
  public sent;

   /**
   * @constructor injects the dependent services
   * @description : The constructor initialises the class variables with the dependencies injected into the class
   * @param {service} EmailsService
  */
  constructor(private service: EmailsService) { }

  /**
   * @method ngOnInit
   * @description : Method used to initalize the component
   */
  ngOnInit() {
    this.service.getLabelDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.labels = this.data[0].Labels[0];
        this.received = this.data[0].EmailsReceived;
        this.sent = this.data[0].EmailsSent;
      }
    });
  }

}
