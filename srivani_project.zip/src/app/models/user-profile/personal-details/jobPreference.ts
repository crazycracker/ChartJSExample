/**
 * Data model for a account summary regional rental preferences
 */

export interface IPreference  {
  countryPreferences: Array<string>;
  skillPreferences: Array<string>;
}

export class JobPreference implements IPreference {
  constructor(
    public countryPreferences: Array<string>,
    public skillPreferences: Array<string>,
  ) { }
}

