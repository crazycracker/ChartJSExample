import { Component } from '@angular/core';

import { Store } from '@ngrx/store';
import { IUserState } from './state/user.state';
import { IAppState } from '../app/app.state';
import { AuthenticationService } from './services/authentication-service/authentication.service';
import { UserLogin } from './actions/user.actions';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'app';
  public isCandidateProfile;
  public toggleEvent;
  userData: IUserState;

  /**
   * @constructor injects the dependent services
   * @description : The constructor initialises the class variables with the dependencies injected into the class
   * @param {store} Store
   * @param {authService} AuthenticationService
   */
  constructor(
    private store: Store<IAppState>,
    private authService: AuthenticationService
  ) {
    this.authService.login('userName', 'password').subscribe(response => {
      this.isCandidateProfile = response[0].isCandidate;
      this.store.dispatch(UserLogin(response[0]));
    });
  }

  public onToggleSideBar(event) {
    this.toggleEvent = event;
  }
}
