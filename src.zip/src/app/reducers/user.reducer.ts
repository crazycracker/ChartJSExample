/**
 * Ngrx reducer for a user
 */
// tslint:disable no-any

import {
  ACTIVITY,
  GUEST_USER,
  LOGIN,
  LOGOUT,
  TIMEOUT,
} from '../actions/user.actions';

import { ICoreAction } from '../actions/actions';
import { IUserState } from '../state/user.state';

const initialState = {
  lastActive: Date.now(),
  loggedIn: false,
  softLogout: false,
  user: null,
} as IUserState;

/**
 * Ngrx reducer for user actions
 * @param {IUserState} state - The user state
 * @param {ICoreAction<User>} action - A user action
 * @return {IUserState} - The new user state
 */
export const userReducer: (state: IUserState, action: ICoreAction<any>) => IUserState =
  (state: IUserState = initialState, action: ICoreAction<any>) => {
    switch (action.type) {
      case LOGIN: return {
        ...state,
        lastActive: Date.now(),
        loggedIn: action.loggedInFlag,
        softLogout: false,
        user: action.payload,
      } as IUserState;

      case LOGOUT: return {
        ...state,
        loggedIn: false,
        softLogout: false,
        user: null,
      } as IUserState;

      case TIMEOUT: return {
        ...state,
        loggedIn: false,
        softLogout: true,
        user: null,
      } as IUserState;

      case GUEST_USER: return {
        ...state,
        lastActive: Date.now(),
        loggedIn: false,
        user: action.payload,
      } as IUserState;

      case ACTIVITY: return {
        ...state,
        lastActive: action.payload,
      } as IUserState;

      default: return state;
    }
  };
