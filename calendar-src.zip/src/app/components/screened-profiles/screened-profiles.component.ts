import { Component, OnInit, OnDestroy } from '@angular/core';
import { ScreenedProfileService } from '../../services/screened_profile-service/screened-profile.service';
import { PagerService } from '../../services/Pagination-service/pager.service';

@Component({
  selector: 'app-irene-screened-profile',
  templateUrl: './screened-profiles.component.html',
  styleUrls: ['./screened-profiles.component.scss']
})

export class ScreenedProfilesComponent implements OnInit, OnDestroy {
  /**
   * current: For using accordion on dropdown
   * allItems: array of all items to be paged
   * pager: pager object
   */
  constructor(
    private service: ScreenedProfileService,
    private pagerService: PagerService
  ) {}

  current = 0;
  expand = 0;
  public data: any = [];
  public labels;
  private allItems: any[];
  pager: any = {};
  pagedItems: any[];
  bestResumeList: Array<object>;
  displayPage = false;
  ngOnInit() {
    this.service.getDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.labels = this.data[0].Labels[0];
        this.checkDataStorage();
      }
    });
  }

  private checkDataStorage() {
    const filteredResume = localStorage.getItem('bestResume');
    if (filteredResume) {
      this.displayPage = true;
      this.bestResumeList = JSON.parse(filteredResume);
      this.allItems = this.bestResumeList;
      this.setPage(1);
    }
  }

  setPage(page: number) {
    // get object with all pager properties required by the view from the Pager Service
    this.pager = this.pagerService.getPager(this.allItems.length, page);
    // get all items present in the current page
    this.pagedItems = this.allItems.slice(
      this.pager.startIndex,
      this.pager.endIndex + 1
    );
    console.log(this.pagedItems);
  }

  ngOnDestroy() {
    localStorage.removeItem('bestResume');
  }
}
