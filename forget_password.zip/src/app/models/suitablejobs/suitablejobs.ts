interface IKeyValue {
    key: string;
    value: string;
}
export class KeyValue implements IKeyValue {
    constructor(
        public key: string,
        public value: string,
    ) { }
}
interface ILocation {
    location: IKeyValue;
}
export class Location implements ILocation {
    constructor(
        public location: IKeyValue,
    ) { }
}
interface ISuitableFormsData {
    searchText: string;
    locations: Array<ILocation>;
    experiences: string;
}
export class SuitableFormsData implements ISuitableFormsData {
    constructor(
        public searchText: string,
        public locations: Array<ILocation>,
        public experiences: string,
    ) { }
}
