/**
 * Represents a user profile
 */

import { PageContent } from './pageContent';
import { PersonalDetails } from './personal-details/personalDetails';
import { JobPreference } from './personal-details/jobPreference';

export interface IUserProfile {
  pageContent?: Array<PageContent>;
  personalDetail?: PersonalDetails;
  jobPreference?: JobPreference;
}

export class UserProfile implements IUserProfile {
  constructor(
  public pageContent?: Array<PageContent>,
  public personalDetail?: PersonalDetails,
  public jobPreference?: JobPreference,
  ) { }
}


interface IRecruiterFormData {
  fromYearEducation: string;
  fromMonthEducation: string;
  toYearEducation: string;
  toMonthEducation: string;
  instituteEducation: string;
}

export class RecruiterFormData implements IRecruiterFormData {
  constructor(
    public fromYearEducation: string,
    public fromMonthEducation: string,
    public toYearEducation: string,
    public toMonthEducation: string,
    public instituteEducation: string,
  ) { }
}

interface IContactFormData {
  mobile: string;
  email: string;
  address: string;
}

export class ContactFormData implements IContactFormData {
  constructor(
    public mobile: string,
    public email: string,
    public address: string,
  ) { }
}

interface IContactData {
  contactDetails: Array<IContactFormData>;
}

export class ContactData implements IContactData {
  constructor(
    public contactDetails: Array<IContactFormData>,
  ) { }
}

interface IEducationData {
  educationalDetails: Array<IRecruiterFormData>;
}

export class EducationData implements IEducationData {
  constructor(
    public educationalDetails: Array<IRecruiterFormData>,
  ) { }
}

interface IExperienceFormData {
  fromYearExperience: string;
  fromMonthExperience: string;
  toYearExperience: string;
  toMonthExperience: string;
  companyExperience: string;
  designationExperience: string;
}

export class ExperienceFormData implements IExperienceFormData {
  constructor(
    public fromYearExperience: string,
    public fromMonthExperience: string,
    public toYearExperience: string,
    public toMonthExperience: string,
    public companyExperience: string,
    public designationExperience: string,
  ) { }
}

interface IExperienceData {
  experienceDetails: Array<IExperienceFormData>;
}

export class ExperienceData implements IExperienceData {
  constructor(
    public experienceDetails: Array<IExperienceFormData>,
  ) { }
}

interface ISkillsData {
  skills: Array<string>;
}

export class SkillsData implements ISkillsData {
  constructor(
    public skills: Array<string>,
  ) { }
}
