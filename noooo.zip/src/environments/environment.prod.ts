export const environment = {
  api: {
    chat_service: '/workday-virtual-agent/aaip/workday/chatbot',
    file_upload: '/workday-virtual-agent/aaip/workday/inject',
  },
  production: true,
  host: '13.232.88.48',
  scheme: 'http',
  url: 'latest-777018cbfeebba53.elb.ap-south-1.amazonaws.com',
};
