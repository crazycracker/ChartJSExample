export const environment = {
  production: true,
  host: '13.232.88.48',
  scheme: 'http'
};
