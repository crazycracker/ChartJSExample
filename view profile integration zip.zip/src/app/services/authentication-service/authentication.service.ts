import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { IAppState } from '../../app.state';
import { UserLogin } from '../../actions/user.actions';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { HttpResponse } from '@angular/common/http';
import { IAPIServiceOpts } from '../../models/http2/request';
import { APIService } from '../api-service/api.service';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';

@Injectable()
export class AuthenticationService {

  private loggedIn = new BehaviorSubject<boolean>(false);

  get isLoggedIn() {
    return this.loggedIn.asObservable();
  }

  /**
   * @constructor injects the dependent services
   * @description : The constructor initialises the class variables with the dependencies injected into the class
   * @param {apiService} APIService
   */
  constructor(
    private store: Store<IAppState>,
    private apiService: APIService,
    private router: Router
  ) {}

  /**
   * @method login
   * @description : service call to fecth the user profile JSON
   * @param {string} index: index of selected item
   * @returns {Array<Object>} JSON data
   */
  public login(username: string, password: string): Observable<{}> {
    if (username !== '' && password !== '' ) {
      this.loggedIn.next(true);
      const request: IAPIServiceOpts<{}> = {
        path: '/assets/data/userProfile.json',
      };
      if (username === 'admin' && password === 'admin') {
        this.router.navigate(['/myprofile']);
        return this.apiService.get(request).pipe(map((res: HttpResponse<{}>) => res.body['isHr']));
      } else {
        this.router.navigate(['/chatbot']);
        return this.apiService.get(request).pipe(map((res: HttpResponse<{}>) => res.body['isCandidate']));
      }
    }
  }

  /**
   * @method getLoginDetails()
   * @description : Used to Fetch the data from LoginDetails.json
   * @return {Observable} : Observable of data
   */
  public getLoginDetails(): Observable<{}> {
    const request: IAPIServiceOpts<{}> = {
      path: '/assets/data/loginDetails.json',
    };

    return this.apiService.get(request).pipe(map((res: HttpResponse<{}>) => res.body));
  }
}
