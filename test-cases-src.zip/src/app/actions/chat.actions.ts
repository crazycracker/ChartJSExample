import { Action } from '@ngrx/store';
import { Chat } from '../models/chat-messages/chat';

export const ADD_CHAT       = '[CHAT] Add';

export class AddChat implements Action {
    readonly type = ADD_CHAT;

    constructor(public payload: Chat ) {}
}

export type Actions = AddChat ;
