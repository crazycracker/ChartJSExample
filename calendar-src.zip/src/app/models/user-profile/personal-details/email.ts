/**
 * Data model for a account summary email
 */

export interface IEmail {
  emailAddress?: string;
  emailType?: string;
  preferedEmail?: boolean;
}
export class Email implements IEmail {
  constructor(
  public emailAddress: string,
  public emailType: string,
  public preferedEmail: boolean,
  ) { }
}
