import { Component, OnInit } from '@angular/core';
import { ViewProfileService } from '../../../services/view-profile-service/view-profile.service';
@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrls: ['./view-profile.component.scss']
})
export class ViewProfileComponent implements OnInit {
  public data: any = [];
  public labels;
  public months;
  public isEditEducation: Boolean = false;
  public isEditExperience: Boolean = false;
  public isEditContact: Boolean = false;
  constructor(private service: ViewProfileService) { }

  ngOnInit() {
    this.service.getLabelDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.labels = this.data[0].Labels[0];
        this.months = this.data.startmonth;

      }
    });
  }
  public enableEdit(section) {
    if (section === 'education') {
      this.isEditEducation = !this.isEditEducation;
    }
    if (section === 'experience') {
      this.isEditExperience = !this.isEditExperience;
    }
    if (section === 'contact') {
      this.isEditContact = !this.isEditContact;
    }

  }

}


