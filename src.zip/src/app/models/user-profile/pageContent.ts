/**
 * Data model for a account summary page content
 */

export interface IPageContent {
  content?: string;
}
export class PageContent implements IPageContent {
  constructor(
  public content: string,
  ) { }
}
