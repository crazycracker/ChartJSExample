interface ChatDetails {
    text: string ;
    self: boolean;
    timeStamp: string;
    attachment: string;
    attachmentSize: number;
    date: number;
}

export interface Chat {
    chatText: Array<ChatDetails> ;
}
