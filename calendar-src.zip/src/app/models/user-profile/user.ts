/**
 * Represents a user
 */
import { UserProfile } from './userprofile';

export interface IUser {
  username: string;
  userToken: string;
  tokenExpiration: number;
  userRefreshToken?: string;
  userProfile?: UserProfile;
  loginType?: string;
  memberTier?: string;
  memberId?: string;
  isHRUser?: boolean;
  userType?: string;
}

export class User implements IUser {
  constructor(
    public username: string,
    public userToken: string,
    public tokenExpiration: number,
    public userRefreshToken?: string,
    public userProfile?: UserProfile,
    public loginType?: string,
    public memberTier?: string,
    public memberId?: string,
    public isHRUser?: boolean,
  ) { }
}
