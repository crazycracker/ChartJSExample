/**
 * Definitions for ngrx actions
 */

import { Action } from '@ngrx/store';

export interface ICoreAction<T> extends Action {
  readonly type: string;
  readonly payload: T;
  readonly page?: string;
  readonly loggedInFlag?: boolean;
}
