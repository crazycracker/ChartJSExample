import { async, ComponentFixture, inject, TestBed } from '@angular/core/testing';
import { APIService } from '../../services/api-service/api.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DocumentService } from '../../services/document-service/document.service';
import {Observable, of} from 'rxjs';
import { DocumentsComponent } from './documents.component';
const mockResponse = {
  data: { success: true }
};
const alldata =
  [{
    'Labels': [{
      'recievedlabel': 'RECIEVED BY ATIENNE',
      'sentlabel': 'SENT TO ATIENNE'
    }]
  }];
  class MockAPIService {
    public get(): Observable<{}> {
      return of(mockResponse);
    }
  }
  class  ScreenedprofileMockService  {
    public  getDetails(): Observable<{}> {
      return of(alldata);
    }
  }
describe('DocumentsComponent', () => {
  let component: DocumentsComponent;
  let fixture: ComponentFixture<DocumentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DocumentsComponent],
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        { provide: APIService, useClass: MockAPIService },
        { provide:  DocumentService,  useClass:  DocumentService }]
    })
      .compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should get data from service',  inject([DocumentService], (service: DocumentService) => {
    spyOn(service, 'getDetails').and.callThrough();
    service.getDetails();
   expect(component.labels).toEqual(component.data.Labels);
})
);
});
