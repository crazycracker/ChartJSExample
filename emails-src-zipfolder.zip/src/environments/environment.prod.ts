export const environment = {
  api: {
    chat_service: '/workday-virtual-agent/aaip/workday/chatbot',
    file_upload: '/workday-virtual-agent/aaip/featureExtraction/inject',
    login_service: '/workday-virtual-agent/aaip/workday/authenticateuser',
    fetchprofile_service: '/workday-virtual-agent/aaip/workday/fetchprofiledata',
    candidate_data_service: '/workday-virtual-agent/aaip/workday/fetchWDCandidateData',
    updateprofile_service: '/workday-virtual-agent/aaip/workday/updateProfileData',
    job_requisition_details: '/workday-virtual-agent/aaip/workday/getJobRequisitionDetails',
    get_best_resume: '/workday-virtual-agent/aaip/workday/getBestResume',
  },
  production: true,
  host: 'ec2-35-154-52-214.ap-south-1.compute.amazonaws.com',
  scheme: 'https',
  url: 'ec2-35-154-52-214.ap-south-1.compute.amazonaws.com/backend',

  // host: '35.154.52.214',
  // scheme: 'http',
  // url: 'latest-777018cbfeebba53.elb.ap-south-1.amazonaws.com',
};
