import { Component, OnInit } from '@angular/core';
import { FindBestResumeService } from '../../../services/find-best-resume-service/find-best-resume.service';
import { RecruiterFormData } from '../../../models/find-best-resume/find-best-resume';

@Component({
  selector: 'app-find-resume',
  templateUrl: './find-resume.component.html',
  styleUrls: ['./find-resume.component.scss']
})
export class FindResumeComponent implements OnInit {
  constructor(private service: FindBestResumeService) {}
  labels;
  selectItems;
  defaultChoice = 'Low';
  initalLoad: Boolean = true;
  skillproficiency = [];
  availableLanguages = [];
  data: any = [];
  cityList: Array<object> = [];
  stateList: Array<object> = [];
  formData;
  isHardSkillEmpty: Boolean = false;
  isSoftSkillEmpty: Boolean = false;
  isLanguageEmpty: Boolean = false;
  isCityStateEmpty: Boolean = false;
  hardSkillText: string;
  softSkillText: string;
  hardSkillExist: Boolean = false;
  softSkillExist: Boolean = false;
  industryTypeDisabled: Boolean = true;

/**
 * @method ngOnInit
 * @description :Method to initalize the component and ftech the label details
 */
ngOnInit() {
    this.service.getLabelDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.labels = this.data.Labels;
        this.selectItems = this.data.InputValues;
        this.skillproficiency = this.data.skillproficiency;
        this.availableLanguages = this.data.availableLanguages;
        this.cityList = this.selectItems.city;
        this.stateList = this.selectItems.state;
        this.formData = new RecruiterFormData (
          '',
          this.selectItems.weightage[0],
          [],
          [],
          this.selectItems.weightage[0],
          this.selectItems.industryType[0],
          this.selectItems.subType[0],
          this.selectItems.weightage[0],
          this.selectItems.qualifications[0],
          this.selectItems.lastExperienceInMedical[0],
          this.selectItems.weightage[0],
          [this.selectItems.languagesKnown[0]],
          this.selectItems.weightage[0],
          this.selectItems.topAcademicInstitutions[0],
          this.selectItems.organizations[0],
          '',
          this.selectItems.weightage[0],
          this.selectItems.employmentType[0],
          this.selectItems.weightage[0],
          [{ state: [this.selectItems.state[0]], city: [this.selectItems.city[0]] }],
          this.selectItems.priorityOfTheJob[0],
          this.selectItems.weightage[0],
          this.selectItems.diversity[0]
        );
      }
    });
  }

  /**
   * @method fetchCandidateStatus
   * @description: this method initates the API call for candidate details
   */
  public fetchRequisitionIdJobs(jobId) {
    this.service.fetchRequisitionIDJobs(jobId).subscribe(res => {
      if (res['body'] !== undefined && res['body'] !== null) {
        const data = res['body'].candidateLatestJobData;
        localStorage.setItem('candidateData', data);
      }
    });
  }

  /**
 * @method formDetails
 * @description :Method to submit the selected data - calls the POST method
 */
  public formDetails() {
    this.service.fetchBestResume()
      .subscribe(data => {
        const filteredData = this.service.filterBestResume(data['body'], this.formData);
        console.log(filteredData);
      }
    );
  }

/**
 * @method addFeilds
 * @description: Method to add extra fields
 * @param {string} value: value of the field
 * @param {string} field: fields which needs to be added
 */
  public addFeilds(value, field) {
    this.hardSkillExist = false;
    this.softSkillExist = false;
    if (value !== '' ||  field === 'languagesKnown' || field === 'cityState') {
      this.validateData(value, field);
    } else {
      this.isHardSkillEmpty = field === 'hardskills';
      this.isSoftSkillEmpty = field === 'softskills';
      this.isLanguageEmpty = field === 'languagesKnown';
      this.isCityStateEmpty = field === 'cityState';
    }
  }

  /**
 * @method validateData
 * @description: Method to valiadte if skills can be added
 * @param {string} value: skill which needs added in formdata
 * @param {string} field: fieldName - if its hard, soft skill, language or state city
 */
  private validateData(value, field) {
    if (field === 'hardskills') {
      this.updateFormData(value, field);
      this.isHardSkillEmpty = false;
      this.hardSkillText = '';
    } else if (field === 'softskills') {
      this.updateFormData(value, field);
      this.isSoftSkillEmpty = false;
      this.softSkillText = '';
    } else if (field === 'languagesKnown') {
      this.formData[field].push(this.selectItems.languagesKnown[0]);
    } else {
      this.formData[field].push({ state: this.selectItems.state[0], city: this.selectItems.city[0]});
    }
  }

/**
 * @method updateFormData
 * @description: Method to update the form data with added field
 * @param {string} value: skill which needs updated in formdata
 * @param {string} field: fieldName - if its hard or soft skill
 */
  private updateFormData(value, field) {
    const isSkillAvailable = this.formData[field].filter((obj) => obj.value === value).length > 0;
    if (isSkillAvailable) {
      this.hardSkillExist = field === 'hardskills';
      this.softSkillExist = field === 'softskills';
    } else {
      this.formData[field].push({
        value: value,
        proficiency: this.defaultChoice
      });
      this.hardSkillExist = false;
      this.softSkillExist = false;
    }
  }

/**
 * @method removeSkills
 * @description: Method to remove the added skills
 * @param {string} skill: skill which needs to be removed
 * @param {string} field: fieldName - if its hard or soft skill
 */
  public removeSkills(skill, field): void {
    const index = this.formData[field].indexOf(skill);
    this.formData[field].splice(index, 1);
  }

/**
 * @method removeDropDownField
 * @description: Method to remove the added Languages and City/State
 * @param {number} index: index of item needs to be removed
 * @param {string} field: fieldName - if its language or city state
 */
  public removeDropDownField(index, field) {
    this.formData[field].splice(index, 1);
  }

/**
 * @method onSelectionChange
 * @description :Method to select the clicked value
 * @param {string} skillType: Skill type
 * @param {string} skill: Skill
 * @param {string} entry: proficency level
 */
  public onSelectionChange(skillType, skill,  entry) {
    this.formData[skillType].filter((element) => {
      if (element.value === skill) {
        element.proficiency = entry;
      }
    });
}

/**
 * @method filterForeCasts
 * @description :Method to filter the languages known based on the provided language
 * @param {any} filterVal: filterVal
 * @param {string} index: index of selected value
 */
public filterForeCasts(filterVal: any, index) {
  if (filterVal !== '0') {
    this.formData.languagesKnown.splice(index, 1, filterVal);
  }
}

}
