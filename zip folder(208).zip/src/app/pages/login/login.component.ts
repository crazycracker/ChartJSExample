import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../services/authentication-service/authentication.service';

export interface IUserlogin {
  userName: string;
  password: string;
}

@Component({
  selector: 'app-irene-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})

export class LoginComponent implements OnInit {
 public loginLabels: any;
 public loginHeader: any;
 public loginContent: any;

 public showLoginCard: Boolean = true;

public formData: IUserlogin = {
  userName: '',
  password: '',
};

  constructor(
    private router: Router,
    private authService: AuthenticationService,
  ) { }

  ngOnInit() {
    this.authService.getLoginDetails().subscribe( res => {
      this.loginLabels = res;
      this.loginHeader = this.loginLabels.WebsiteName;
      this.loginContent = this.loginLabels.LoginLabels;
    });
  }

  toggleLoginCard() {
    this.showLoginCard = !this.showLoginCard;
  }

  onSubmit() {
    this.authService.login(this.formData.userName, this.formData.password);
  }

}
