import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { IAppState } from '../../app.state';
import { IUserState } from '../../state/user.state';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home-layout',
  templateUrl: './home-layout.component.html',
  styleUrls: ['./home-layout.component.scss']
})

export class HomeLayoutComponent {
  title = 'app';
  public isCandidateProfile;
  public toggleEvent;
  public isLoginPage: Boolean = false;
  public userData: any;
  isChatBotPage = false;

  /**
 * @constructor injects the dependent services
 * @description : The constructor initialises the class variables with the dependencies injected into the class
 * @param {store} Store
 * @param {authService} AuthenticationService
 */
  constructor(
    private store: Store<IAppState>,
    private router: Router,
  ) {
    this.store.select('user').subscribe((userState: IUserState) => {
      if (userState.user) {
        this.isCandidateProfile = userState.user[0].userRole;
      }
    });
   }

  public changeOfRoutes() {
    if (this.router.url === '/chatbot') {
      this.isChatBotPage = true;
    } else {
      this.isChatBotPage = false;
    }
  }

  public onToggleSideBar(event) {
    this.toggleEvent = event;
  }
}
