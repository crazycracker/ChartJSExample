import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Headers } from '@angular/http';
import { HttpResponse } from '@angular/common/http';
import { APIService } from '../api-service/api.service';
import { IAPIServiceOpts } from '../../models/http2/request';
import { environment } from '../../../environments/environment';
import { Http2Service } from '../../services/http2/http2.service';
import { IRequestOpts } from '../../models/http2/request';
import {ProfileData} from '../../models/user-profile/userProfile';

@Injectable({
  providedIn: 'root'
})
export class ViewProfileService {
  private url = '/assets/data/viewProfile.json';
  constructor(private apiService: APIService, private httpService: Http2Service) { }
  /**
   * @constructor injects the dependent services
   * @description : The constructor initialises the class variables with the dependencies injected into the class
   * @param {apiservice} APIService
   * @method getLabelDetails
   * @description:The method fetches labels from the json to display them on user interface

   */
  public getLabelDetails(): Observable<{}> {
    const request: IAPIServiceOpts<{}> = {
      path: this.url,
    };

    return this.apiService.get(request).pipe(map((res: HttpResponse<{}>) => res.body));
  }

  public getDummyProfileDetails(): Observable<ProfileData> {
    const request: IAPIServiceOpts<{}> = {
      path: '/assets/response/viewProfileResponse.json',
    };
    return this.apiService.get(request).pipe(map((res: HttpResponse<ProfileData>) => res.body));
  }

  /**
   * @method postFormDetails
   *@description: The post method posts all the data that is collected from the form
   *@param {formData}: collecting all the data from the form
   */

  private setContentTypeRequestHeader(headers: Headers): void {
    headers.set('Content-Type', 'application/json');
  }

  private postFormDetails(request: {}, apiUrl: string): Observable<{}> {
    const headers = new Headers();
    this.setContentTypeRequestHeader(headers);
    const apiRequestConfig: IRequestOpts<{}> = {
      body: request,
      headers: headers.toJSON(),
      host: environment.url,
      path: apiUrl,
      scheme: 'http',
    };
    return this.httpService.post(apiRequestConfig);
  }
  public fetchProfileDetails(): Observable<{}> {
    const request = {
      'userName': 'venkat',
      'candidateID': 'CAND-1233',
      'sessionParam': {
        'contextId': '7b02d48b8ac620f757095c3fb04eb86e598d51913d07f33bacad125ad466a53b',
        'SenderId': 'Venkat',
        'SenderName': 'Venkat'
      }
    };

    return this.postFormDetails(request, environment.api.fetchprofile_service);
  }
}
