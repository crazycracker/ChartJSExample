import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TestBed, ComponentFixture, async, inject } from '@angular/core/testing';
import { HomeLayoutComponent } from './home-layout.component';
import { RouterTestingModule } from '@angular/router/testing';
import { Store, StoreModule } from '@ngrx/store';
import { userReducer } from '../../reducers/user.reducer';
import { AuthenticationService } from '../../services/authentication-service/authentication.service';
import { APIService } from '../../services/api-service/api.service';
import { Http2Service } from '../../services/http2/http2.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { IAppState } from '../../app.state';
import { Router } from '@angular/router';
import { LoaderService } from '../../services/loader/loader.service';


const router = {
  navigate: jasmine.createSpy('navigate'),
  url: '/chatbot'
};

describe('HomeLayoutComponent', () => {
  let component: HomeLayoutComponent;
  let fixture: ComponentFixture<HomeLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        HomeLayoutComponent
      ],
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        StoreModule.forRoot(userReducer),
      ],
      providers: [
        AuthenticationService,
        APIService,
        Http2Service,
        LoaderService,
        { provide: Router, useValue: router }
      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should navigate to chatbot page', () => {
    component.changeOfRoutes();
    expect(component.isChatBotPage).toBe(true);
  });
  it('should capture the event', () => {
    const event = 'newEvenet';
    component.onToggleSideBar(event);
    expect(component.toggleEvent).toBe(event);
  });
});
