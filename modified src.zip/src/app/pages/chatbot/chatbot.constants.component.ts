/**
 * Constants
 */
export const AppChatbotPage = {
    USER_NAME : 'Hi David!',
    MESSAGE1 : 'Great to know that you decided to continue your application process with Atienne!',
    MESSAGE2 : 'To make your recruitment journey seamles and personalised, our Recruiter Bot here will engage with you through out, and make all the little tasks completely hassle-free.',
    
};