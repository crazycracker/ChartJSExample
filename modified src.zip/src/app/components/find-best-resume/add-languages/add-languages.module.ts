import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { LanguageButtonComponent } from './languagebutton/languagebutton.component';
import { LanguageDropDownComponent } from './languagedropdown/languagedropdown.component';
import { LanguageSectionComponent } from './section.component';
import { AddLanguagesComponent } from './add-languages.component';

@NgModule({
    declarations: [
        LanguageButtonComponent,
        LanguageDropDownComponent,
        LanguageSectionComponent,
        AddLanguagesComponent
    ],
    exports: [
        LanguageButtonComponent,
        LanguageDropDownComponent,
        LanguageSectionComponent,
        AddLanguagesComponent
    ],
    imports: [
        CommonModule,
        FormsModule
    ],
    entryComponents: [
        LanguageDropDownComponent
    ]
})
export class AddLanguagesModule { }
