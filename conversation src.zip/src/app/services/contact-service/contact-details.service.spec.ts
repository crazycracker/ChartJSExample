import { TestBed, inject } from '@angular/core/testing';
import { APIService } from '../../services/api-service/api.service';
import { Http2Service } from '../../services/http2/http2.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ContactDetailsService } from './contact-details.service';

describe('ContactDetailsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule
      ],
      providers: [
        ContactDetailsService,
        APIService,
        Http2Service,
      ],
    });
  });

  it('should be created', inject([ContactDetailsService], (service: ContactDetailsService) => {
    expect(service).toBeTruthy();
  }));
  it('should fetch data from json', inject([ContactDetailsService], (service: ContactDetailsService) => {
    service.getContactDetails().subscribe( result => {
      expect(result).toBeDefined();
    });
  }));
});
