import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalComponent } from './modal.component';
import { emitKeypressEvents } from 'readline';
import { KeyValue } from '../../models/suitablejobs/suitablejobs';

describe('ModalComponent', () => {
  let component: ModalComponent;
  let fixture: ComponentFixture<ModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call the onResize function', () => {
    component.onResize(1);
     expect(component.onResize).toBeTruthy();
  });
  it('should call the KeyValue function', () => {
    component.clickout(KeyValue);
     expect(component.handleKeyboardEvent).toBeTruthy();
  });
  it('should call openModel', () => {
    component.openModal();
    expect(component.openModal).toBeTruthy();
  });
  it('should call the closeModal function', () => {
    component.closeModal();
   expect(component.closeModal).toBeTruthy();
  });
  it('should call the resizeModal function', () => {
    component.resizeModal(3);
     expect(component.resizeModal).toBeTruthy();
  });
});
