import { async, ComponentFixture, inject, TestBed} from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Observable, of } from 'rxjs';
import { FindResumeComponent } from './find-resume.component';
import { FindBestResumeService } from '../../../services/find-best-resume-service/find-best-resume.service';
import { RecruiterFormData } from '../../../models/find-best-resume/find-best-resume';

const mockResponse = {
  data: { success: true }
};
const data = {
  Labels: {
    searchLabel: 'Search'
  },
  skillproficiency: ['High', 'Medium', 'Low'],
  availableLanguages: ['English', 'French', 'German', 'Italian', 'Chiniese'],
  InputValues: {
    weightage: ['Choose weightage', '1', '2', '3'],
    languagesKnown: ['Select', 'English', 'French', 'Hindi'],
    state: ['Select', 'State1', 'State2', 'State3'],
    city: ['Select', 'City1', 'City2', 'City3']
  }
};

class MockService {
  public getLabelDetails(): Observable<{}> {
    return of(data);
  }

  public postFormDetails(): Observable<{}> {
    return of(mockResponse);
  }
}

describe('FindResumeComponent', () => {
  let component: FindResumeComponent;
  let fixture: ComponentFixture<FindResumeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FindResumeComponent],
      imports: [FormsModule, HttpClientTestingModule],
      providers: [
        { provide: FindBestResumeService, useClass: MockService }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FindResumeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.formData = new RecruiterFormData(
      '',
      'Select',
      [],
      [],
      'Select',
      'Select',
      'Select',
      'Select',
      'Select',
      'Select',
      'Select',
      ['Select'],
      'Select',
      'Select',
      'Select',
      '',
      'Select',
      'Select',
      'Select',
      [{ state: ['Select'], city: ['Select'] }],
      'Select',
      'Select',
      'Select'
    );
  });

  it('should create FindResumeComponent', inject(
    [FindBestResumeService],
    (service: FindBestResumeService) => {
      spyOn(service, 'getLabelDetails').and.callThrough();
      service.getLabelDetails();
      expect(component).toBeTruthy();
      expect(component.labels).toEqual(component.data.Labels);
    }
  ));

  it('should call formDetails method and post the data', inject(
    [FindBestResumeService],
    (service: FindBestResumeService) => {
      spyOn(service, 'postFormDetails').and.callThrough();
      component.formDetails();
      service.postFormDetails(data).subscribe(res => {
        expect(res).toEqual(mockResponse);
      });
    }
  ));

  it('should call addFeilds method and checks for new fields added', () => {
    component.addFeilds('html', 'hardskills');
    expect(component.formData.hardskills[0].value).toBe('html');
    component.addFeilds('Comm', 'softskills');
    expect(component.formData.softskills[0].value).toBe('Comm');
    component.addFeilds('English', 'languagesknown');
    expect(component.formData.languagesknown[0].value).toBe('English');
    component.addFeilds('London', 'cityState');
    expect(component.formData.citystate[0].value).toBe('London');
  });

  it('should call removeSkills method and remove the added skills', () => {
    component.removeSkills('html', 'hardskills');
    expect(component.formData.hardskills[0].value.splice(0, 1));
    component.removeSkills('Comm', 'softskills');
    expect(component.formData.softskills[0].value).toBeFalsy('Comm');
  });
  it('should call removeSkills method and remove the added Languages and City/State', () => {
    component.removeDropDownField(0, 'hardskill');
  });

  it('should call onSelectionChange method and checks for selected fields', () => {
    (component.formData.softskills = [
      {
        value: 'xyz',
        proficiency: ''
      },
      {
        value: 'Comm',
        proficiency: ''
      }
    ]),
      component.onSelectionChange('softskills', 'Comm', 'abc');
    expect(component.formData.softskills[0].value).toEqual('xyz');
  });

  it('should call filterForeCasts method and checks for selected fields', () => {
    component.filterForeCasts('English', 1);
    expect(component.formData.languagesKnown[1]).toEqual('English');
  });
});
