import { Component, OnInit } from '@angular/core';
import { ContactDetailsService } from '../../services/contact-service/contact-details.service';

@Component({
  selector: 'app-irene-need-help',
  templateUrl: './need-help.component.html',
  styleUrls: ['./need-help.component.scss']
})
export class NeedHelpComponent implements OnInit {
public contactInfo: any;
public needContact: any;
  constructor(private contactDetails: ContactDetailsService) { }
    /**
   * @method ngOnInit
   * @description : Getting the data from the ContactDetails service
   */

  ngOnInit(): void {
    this.contactDetails.getContactDetails().subscribe(
      res => {
        this.needContact = res;
        this.contactInfo = this.needContact.ContactInfo;
        console.log(this.contactInfo);
      });
  }

}
