import { Component, OnInit } from '@angular/core';
import { Workspace360Service } from '../../services/workspace360/workspace360.service';
import { WhyUsConstants } from '../../pages/why-us/whyus.constants.component';
interface Images {
  imageUrl: string;
}

@Component({
  selector: 'app-workspace360',
  templateUrl: './workspace360.component.html',
  styleUrls: ['./workspace360.component.scss']
})
export class Workspace360Component implements OnInit {
  public data: any = [];
  public labels;
  public imageUrl: Array<Images> = WhyUsConstants;
  public imagePath: any;
  public showImage = this.imageUrl[0].imageUrl;
  noOfScreens = 7;


  constructor(private service: Workspace360Service) {

  }
  showCurremtImage(currentImage: HTMLElement): void {
    this.showImage = currentImage['imageUrl'];
  }
  /**
  * @method ngOnInit
  * @description : Method used to initalize the component
  */
  ngOnInit() {
    this.service.getLabelDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.labels = this.data.Labels;
      }
    });



  }
}
