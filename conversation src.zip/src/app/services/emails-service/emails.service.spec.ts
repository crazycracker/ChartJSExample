import { TestBed, inject } from '@angular/core/testing';
import { APIService } from '../../services/api-service/api.service';
import { Http2Service } from '../../services/http2/http2.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { EmailsService } from './emails.service';

describe('EmailsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        EmailsService,
        APIService,
        Http2Service,
      ],
    });
  });

  it('should be created', inject([EmailsService], (service: EmailsService) => {
    expect(service).toBeTruthy();
  }));
  it('retrieves all data from json', inject( [EmailsService], ( service: EmailsService ) => {
    service.getLabelDetails().subscribe( result => {
        expect(result).toBeGreaterThan(0);
    });
  }));
});
