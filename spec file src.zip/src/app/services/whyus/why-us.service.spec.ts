import { TestBed, inject } from '@angular/core/testing';
import { APIService } from '../../services/api-service/api.service';
import { Http2Service } from '../../services/http2/http2.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { WhyusService } from './why-us.service';

describe('WhyusService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        WhyusService,
        APIService,
        Http2Service,
      ],
    });
  });

  it('should be created', inject([WhyusService], (service: WhyusService) => {
    expect(service).toBeTruthy();
  }));
  it('retrieves all data from json', inject( [WhyusService], ( service: WhyusService ) => {
    service.getLabelDetails().subscribe( result => {
        expect(result).toBeGreaterThan(0);
    });
  }));
});
