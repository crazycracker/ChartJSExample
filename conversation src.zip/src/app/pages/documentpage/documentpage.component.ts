import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-irene-documentpage',
  templateUrl: './documentpage.component.html',
  styleUrls: ['./documentpage.component.scss']
})
export class DocumentpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
