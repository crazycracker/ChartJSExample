/**
 * Services module
 */

import {NgModule} from '@angular/core';

import {AuthenticationService} from './authentication-service/authentication.service';
import {APIService} from './api-service/api.service';
import {ChatService} from './chatbot-service/chat.service';
import {Http2Service} from './http2/http2.service';
import {UtilService} from './util/util.service';

@NgModule({
  providers: [
    AuthenticationService,
    APIService,
    ChatService,
    Http2Service,
    UtilService,
  ],
})
export class ServicesModule {
}
