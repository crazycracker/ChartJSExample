import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CarouselComponent } from './carousel.component';

describe('CarouselComponent', () => {
  let component: CarouselComponent;
  let fixture: ComponentFixture<CarouselComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CarouselComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CarouselComponent);
    component = fixture.componentInstance;
    component.dataArray = [{imageUrl: '1'}, {imageUrl: '2'}];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call showImage function and emit the current image url', () => {
    component.showImage('assets/icon', 0);
     expect(component.selectedItem).toBe(0);
  });
  it('should call setClickedImage function and get the index of current image', () => {
    component.setClickedImage(1);
     expect(component.selectedItem).toBe(1);
  });
  it('should call forgeNewArray function and forge diaplayArray of images', () => {
    component.forgeNewArray();
    expect(component).toBeTruthy();
  });
  it('should call the buildDisplayArray function and build the display array of image', () => {
    component.buildDisplayArray(0, 1);
    expect(component.displayArray).toEqual([{imageUrl: '2'}]);
  });
  it('should call moveToNext function  move to next and previous images in carousel', () => {
    component.moveToNext();
    expect(component.buildDisplayArray).toBeTruthy();
    component.moveToPrevious();
    expect(component.buildDisplayArray).toBeTruthy();
  }
);
});
