import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { HttpResponse } from '@angular/common/http';
import { IAPIServiceOpts } from '../../models/http2/request';
import { APIService } from '../api-service/api.service';

@Injectable()
export class AuthenticationService {

  /**
   * @constructor injects the dependent services
   * @description : The constructor initialises the class variables with the dependencies injected into the class
   * @param {apiService} APIService
   */
  constructor(
    private apiService: APIService
  ) {}

  /**
   * @method login
   * @description : service call to fecth the user profile JSON
   * @param {string} index: index of selected item
   * @returns {Array<Object>} JSON data
   */
  public login(username: string, password: string): Observable<{}> {
    const request: IAPIServiceOpts<{}> = {
      path: '/assets/Data/userProfile.json',
    };

    return this.apiService.get(request).pipe(map((res: HttpResponse<{}>) => res.body));
  }
}
