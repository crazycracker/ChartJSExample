/**
 * Represents an ngrx action against a user
 */
// tslint:disable no-any

import { User } from '../models/user-profile/user';

import { ICoreAction } from './actions';

export const LOGIN = 'LOGIN';
export const LOGOUT = 'LOGOUT';
export const GUEST_USER = 'GUESTUSER';
export const TIMEOUT = 'TIMEOUT';
export const ACTIVITY = 'ACTIVITY';

class UserAction implements ICoreAction<any> {
  constructor(
    public readonly type: string,
    public readonly payload: any,
    public readonly loggedInFlag?: boolean,
  ) {  }
}

/**
 * Creates a UserLogin action
 * @param {User} user - The user to log in
 * @param {Boolean} loggedInFlag - The login action
 * @return {UserAction} - The login action
 */
export const UserLogin: (user: User, loggedInFlag?: boolean) => UserAction =
  (user: User, loggedInFlag?: boolean) => new UserAction(LOGIN, user, (loggedInFlag !== undefined) ? loggedInFlag : true);

/**
 * Creates a GuestUser action
 * @param {User} user - The user to log in
 * @return {UserAction} - The login action
 */
export const GuestUser: (user: User) => UserAction =
  (user: User) => new UserAction(GUEST_USER, user);

/**
 * Creates a UserLogout action
 * @return {UserAction} - The logout action
 */
export const UserLogout: () => UserAction =
  () => new UserAction(LOGOUT, null);

/**
 * Creates a Timeout action
 * @return {UserAction} - The timeout action
 */
export const UserTimeout: () => UserAction =
  () => new UserAction(TIMEOUT, null);

/**
 * Creates an Activity action
 * @param {number} timestamp - The timestamp of the latest activity
 */
export const UserActivity: (timestamp: number) => UserAction =
  (timestamp: number) => new UserAction(ACTIVITY, timestamp);
