import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpResponse } from '@angular/common/http';
import { APIService } from '../api-service/api.service';
import { IAPIServiceOpts } from '../../models/http2/request';
import { Http, Response, Headers } from '@angular/http';

@Injectable({
  providedIn: 'root'
})
export class ViewProfileService {
  private url = '/assets/data/viewProfile.json';
  constructor(private apiService: APIService, private _http: Http) { }
  /**
 * @constructor injects the dependent services
 * @description : The constructor initialises the class variables with the dependencies injected into the class
 * @param {apiservice} APIService
 * @method getLabelDetails
 * @description:The method fetches labels from the json to display them on user interface

 */
  public getLabelDetails(): Observable<{}> {
    const request: IAPIServiceOpts<{}> = {
      path: this.url,
    };

    return this.apiService.get(request).pipe(map((res: HttpResponse<{}>) => res.body));
  }
  /**
   * @method postFormDetails
   *@description: The post method posts all the data that is collected from the form
   *@param {formData}: collecting all the data from the form
     */
  public postFormDetails(formData: any): Observable<{}> {
    const body = JSON.stringify(formData);
    const header = new Headers();
    header.append('Content-Type', 'application/json');
    return this._http.post('', body, { headers: header })
      .pipe(map((res: Response) => res.json));

  }


}
