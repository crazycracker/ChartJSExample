import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-irene-suitable-jobs',
  templateUrl: './suitable-jobs.component.html',
  styleUrls: ['./suitable-jobs.component.scss']
})
export class SuitableJobsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
