import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-router.module';
import { ComponentsModule } from './components/components.module';
import { ServicesModule } from './services/services.module';
import { PagesModule } from './pages/pages.module';
import { StoreModule } from '@ngrx/store';
import { userReducer } from './reducers/user.reducer';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { HomeLayoutComponent } from './layouts/home-layout/home-layout.component';
import { LoginLayoutComponent } from './layouts/login-layout/login-layout.component';
import { AuthenticationService } from './services/authentication-service/authentication.service';
import { AuthGuard } from './services/authentication-service/authentication.guard';

@NgModule({
  declarations: [
    AppComponent,
    HomeLayoutComponent,
    LoginLayoutComponent,
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    ComponentsModule,
    PagesModule,
    ServicesModule,
    RouterModule,
    HttpModule,
    HttpClientModule,
    BrowserAnimationsModule,
    StoreModule.forRoot(
      { user: userReducer },
    ),
  ],
  providers: [AuthenticationService, AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
