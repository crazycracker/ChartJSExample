import { LanguageDropDownComponent } from './languagedropdown/languagedropdown.component';
import { Component, AfterViewInit, ViewChildren, QueryList, ComponentFactoryResolver, ComponentFactory, OnInit } from '@angular/core';
import { LanguageSectionComponent } from './section.component';

@Component({
  selector: 'app-irene-add-languages',
  templateUrl: './add-languages.component.html',
  styleUrls: ['./add-languages.component.scss']
})
export class AddLanguagesComponent implements AfterViewInit, OnInit {
  @ViewChildren(LanguageSectionComponent) sections: QueryList<LanguageSectionComponent>;
  activeSections: LanguageSectionComponent[];
  dropDownComponentFactory: ComponentFactory<LanguageDropDownComponent>;
  /**
   * @constructor injects the dependant services
   * @constructor The constructor initialises the class variables with the dependencies injected into the class
   * @param  {ComponentFactoryResolver} componentFactoryResolver
   */
  constructor(private componentFactoryResolver: ComponentFactoryResolver) { }
  /**
   * @method ngOnInit
   * @description : initializing the class variables with an instance of componentFactory resolved by componentFactoryResolver
   */
  ngOnInit() {
    this.dropDownComponentFactory = this.componentFactoryResolver.resolveComponentFactory(LanguageDropDownComponent);
  }
  /**
   * @method ngAfterViewInit
   * @description : initializing the activeSections variable with an aggregated value of the
   * Dropdown components listed in the sections query list
   */
  ngAfterViewInit() {
    this.activeSections = this.sections.reduce((result, section) => {
      if (section.active) {
        result.push(section);
      }
      return result;
    }, []);
  }
  /**
   * @method onAddComponentClick
   * @description : event Handler method to create a dropdown component
   */
  onAddComponentClick() {
    this.activeSections.forEach((section) => {
      section.viewContainerRef.createComponent(this.dropDownComponentFactory);
    });
  }
}
