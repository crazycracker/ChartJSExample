import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store } from '@ngrx/store';
import { IUserState } from '../../state/user.state';
import { IAppState } from '../../app.state';

import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, OnDestroy {
  public isCandidateProfile;
  private ngUnsubscribe: Subject<void> = new Subject<void>();

  /**
   * @constructor injects the dependent services
   * @description : The constructor initialises the class variables with the dependencies injected into the class
   * @param {store} Store
   */
    constructor(private store: Store<IAppState>) { }

  /**
   * @method ngOnInit
   * @description : Method used to initalize the component
   */
  ngOnInit() {
    this.store
    .select((storeState: IAppState) => storeState.user)
    .pipe(takeUntil(this.ngUnsubscribe))
    .subscribe(
      (userState: IUserState): void => {
        if (userState.user) {
          this.isCandidateProfile = userState.user['isCandidate'];
        }
      }
    );
  }

  /**
   * @method ngOnDestroy
   * @description Method to clean up any listeners when the component is destroyed
   * to prevent memory leaks and resource consumption
   */
  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
}
