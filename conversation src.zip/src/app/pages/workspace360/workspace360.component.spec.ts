import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import {APIService} from '../../services/api-service/api.service';
import { Workspace360Component } from './workspace360.component';
import { CarouselComponent } from '../../components/carousel/carousel.component';
import { Http2Service } from '../../services/http2/http2.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpModule } from '@angular/http';
import { Observable, of } from 'rxjs';
import { Workspace360Service } from '../../services/workspace360/workspace360.service';

const data = {
  Labels: {
  storeMessageLabel: 'Take a 360° tour of Atienne Yishun Store !',
  storeDescriptionLabel: 'Welcome to Atienne Fashion Store!'
  }
  };

  class MockService {
    public getLabelDetails(): Observable<{}> {
    return of (data);
    }
  }

describe('Workspace360Component', () => {
  let component: Workspace360Component;
  let fixture: ComponentFixture<Workspace360Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Workspace360Component, CarouselComponent ],
      providers: [
        APIService,
        Http2Service,
        Workspace360Service,
        { provide: Workspace360Service, useClass: MockService }
      ],
       imports: [  HttpClientTestingModule,
        HttpModule,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Workspace360Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should get the selected image', inject(
    [Workspace360Service],
    (service:  Workspace360Service) => {
      spyOn(service, 'getLabelDetails').and.callThrough();
      service.getLabelDetails();
      expect(component.labels).toEqual(data.Labels);
    }
  ));
  // it('should get the current image', () => {
  //   const imageData = {
  //     imageUrl: '../../../assets/images/swimText.png'
  //   };
  //   component.showCurremtImage(imageData);
  //   expect(component.showImage).toBe('../../../assets/images/swimText.png');
  // });

});
