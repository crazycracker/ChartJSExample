import {BestResume} from '../models/find-best-resume/find-best-resume';
import {ICoreAction} from './actions';

export const ADD_BESTRESUME = 'ADD_BESTRESUME';
export const REMOVE_BESTRESUME = 'REMOVE_BESTRESUME';

class BestResumeDataAction implements ICoreAction<any> {
  constructor(
    public readonly type: string,
    public readonly payload: BestResume,
  ) {
  }
}

export const AddBestResume: (bestResume: BestResume) => BestResumeDataAction =
  (BestResumes: BestResume) => new BestResumeDataAction(ADD_BESTRESUME, BestResumes);

export const RemoveBestResume: () => BestResumeDataAction =
  () => new BestResumeDataAction(REMOVE_BESTRESUME, null);
