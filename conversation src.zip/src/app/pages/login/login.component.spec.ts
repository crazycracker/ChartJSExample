import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from './login.component';
import { RouterTestingModule } from '@angular/router/testing';
import { APIService } from '../../services/api-service/api.service';
import { Http2Service } from '../../services/http2/http2.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { StoreModule } from '@ngrx/store';
import { userReducer } from '../../reducers/user.reducer';
import { Observable, of } from 'rxjs';
import { AuthenticationService } from '../../services/authentication-service/authentication.service';
import { Router } from '@angular/router';

const data = {
  WebsiteName: {
     label: 'ELIXIR PHARMA'
  },
  LoginLabels: {
      labelLogin: 'Login',
      labelRemember: 'Remember Me',
      labelForgot: 'Forgot Password?',
      forgotDetails: 'We just need your registered email address to send you reset password instructions',
      back: 'Back'
  }
};

const loginData = {
  body: {
    contextId: 'ada5fb1d54a3dd4e02043a12b268022aaecd3e2136e9062b2a2eb1ec4aea41e2',
    loginData: '[{\"user_name\":\"user\",\"candidate_id\":\"CAND-0002\",\"first_name\":\"user\",\"user_role\":\"user\"}]',
    status: 'success'
  }

};

class MockService {
  public getLoginDetails(): Observable<{}> {
    return of(data);
  }

  public login(x, y): Observable<{}> {
    return of(loginData);
  }
}
const router = {
  navigate: jasmine.createSpy('navigate'),
  url: '/login'
};

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginComponent ],
      imports: [
        FormsModule,
        RouterTestingModule,
        HttpClientTestingModule,
        StoreModule.forRoot(userReducer),
      ],
      providers: [
        APIService,
        Http2Service,
        AuthenticationService,
          { provide: AuthenticationService, useClass: MockService },
          { provide: Router, useValue: router }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should toggle the login and forgot password card', () => {
   component.showLoginCard = true;
    component.toggleLoginCard();
    expect(component.showLoginCard).toBe(false);
    expect(component.passwordSent).toBe(false);
    expect(component.incorrectEmailId).toBe(false);
  });
  it('should get the labels from service', inject(
    [AuthenticationService],
    (service: AuthenticationService) => {
      spyOn(service, 'getLoginDetails').and.callThrough();
      service.getLoginDetails();
      expect(component).toBeTruthy();
      expect(component.loginLabels).toBeDefined();
      expect(component.loginHeader).toEqual({ label: 'ELIXIR PHARMA'});
    }
  ));
  it('should get the data from login service', inject(
    [AuthenticationService],
    (service: AuthenticationService) => {
      spyOn(service, 'login').and.callThrough();
      component.formData.userName = 'user';
      component.formData.password = 'user';
      component.isLoginPage = true;
      component.onSubmit();
      service.login(component.formData.userName, component.formData.password);
      expect(component).toBeTruthy();
      expect(component.loginData).toEqual(loginData['body'].loginData);
      expect(component.isLoginPage).toBe(false);
    }
  ));
});
