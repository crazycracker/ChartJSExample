import { Component, OnInit } from '@angular/core';
import { FindBestResumeService } from '../../../services/find-best-resume-service/find-best-resume.service';

import 'rxjs';
interface RecruiterFormData {
  skillsWeightage: string;
  jobid: string;
  hardskills: string;
  softskills: string;
  industryWeightage: string;
  industryType: string;
  subType: string;
  candidateDetailsWeightage: string;
  qualifications: string;
  lastExperienceInMedical: string;
  languagesKnownHeading: string;
  languagesKnown: string;
  educationAndOrganizationDetails: string;
  topAcademicInstitutions: string;
  organizations: string;
  profilesRequired: string;
  employmentType: string;
  employmentTypeInput: string;
  primaryLocations: string;
  state: string;
  city: string;
  priorityOfTheJobInput: string;
  priorityofthejob: string;

}


@Component({
  selector: 'app-find-resume',
  templateUrl: './find-resume.component.html',
  styleUrls: ['./find-resume.component.scss']
})
export class FindResumeComponent implements OnInit {

  constructor(private service: FindBestResumeService) { }
  public labels;
  public selectItems;
  public data: any = [];
  public formData: RecruiterFormData = {
    skillsWeightage: '',
    jobid: '',
    hardskills: '',
    softskills: '',
    industryWeightage: '',
    industryType: '',
    subType: '',
    candidateDetailsWeightage: '',
    qualifications: '',
    lastExperienceInMedical: '',
    languagesKnownHeading: '',
    languagesKnown: '',
    educationAndOrganizationDetails: '',
    topAcademicInstitutions: '',
    organizations: '',
    profilesRequired: '',
    employmentType: '',
    employmentTypeInput: '',
    primaryLocations: '',
    state: '',
    city: '',
    priorityOfTheJobInput: '',
    priorityofthejob: '',
  };

  ngOnInit() {
    this.service.getLabelDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.labels = this.data.Labels;
        this.selectItems = this.data.InputValues;
      }
    });
  }
  public formDetails() {
    console.log(this.formData);
    this.service.postFormDetails(this.formData).subscribe(data => console.log(data));
  }

}
