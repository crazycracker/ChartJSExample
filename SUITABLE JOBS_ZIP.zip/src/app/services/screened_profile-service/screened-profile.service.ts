import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpResponse } from '@angular/common/http';
import { APIService } from '../api-service/api.service';
import { IAPIServiceOpts } from '../../models/http2/request';
import { Http, Response, Headers } from '@angular/http';
@Injectable({
  providedIn: 'root'
})
export class ScreenedProfileService {
  private url = '/assets/data/screened_profile.json';
  constructor(private apiService: APIService) { }
  /**
   * @method getDetails()
   * @description : Used to Fetch the data from screened_profile.json
   * @return {Observable} : Observable of data
   */
  public getDetails(): Observable<{}> {
    const request: IAPIServiceOpts<{}> = {
      path: this.url,
    };
    return this.apiService.get(request).pipe(map((res: HttpResponse<{}>) => res.body));
  }
}
