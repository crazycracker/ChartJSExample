import { TestBed, inject } from '@angular/core/testing';

import { WorklocationsService } from './worklocations.service';

describe('WorklocationsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WorklocationsService]
    });
  });

  it('should be created', inject([WorklocationsService], (service: WorklocationsService) => {
    expect(service).toBeTruthy();
  }));
});
