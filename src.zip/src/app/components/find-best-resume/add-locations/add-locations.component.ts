import { LocationDropDownComponent } from './locationdropdown/locationdropdown.component';
import { Component, AfterViewInit, ViewChildren, QueryList, ComponentFactoryResolver, ComponentFactory, OnInit } from '@angular/core';
import { LocationSectionComponent } from './section.component';

@Component({
  selector: 'app-irene-add-locations',
  templateUrl: './add-locations.component.html',
  styleUrls: ['./add-locations.component.scss']
})

export class AddLocationsComponent implements AfterViewInit, OnInit {
  @ViewChildren(LocationSectionComponent) sections: QueryList<LocationSectionComponent>;
  activeSections: LocationSectionComponent[];
  dropDownComponentFactory: ComponentFactory<LocationDropDownComponent>;

  /**
   * @constructor injects the dependant services
   * @constructor The constructor initialises the class variables with the dependencies injected into the class
   * @param  {ComponentFactoryResolver} componentFactoryResolver
   */
  constructor(private componentFactoryResolver: ComponentFactoryResolver) { }

  /**
   * @method ngOnInit
   * @description : initializing the class variables with an instance of componentFactory resolved by componentFactoryResolver
   */
  ngOnInit() {
    this.dropDownComponentFactory = this.componentFactoryResolver.resolveComponentFactory(LocationDropDownComponent);
  }

  /**
   * @method ngAfterViewInit
   * @description : initializing the activeSections variable with an aggregated value of the Dropdown components listed in the sections query list
   */
  ngAfterViewInit() {
    this.activeSections = this.sections.reduce((result, section, index) => {
      if (section.active) {
        result.push(section);
      }
      return result;
    }, []);
  }

  /**
   * @method onAddComponentClick
   * @description : event Handler method to create a dropdown component 
   */
  onAddComponentClick() {
    this.activeSections.forEach((section) => {
      section.viewContainerRef.createComponent(this.dropDownComponentFactory);
    });
  }
}
