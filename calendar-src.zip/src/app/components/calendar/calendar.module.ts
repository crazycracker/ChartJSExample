import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import {  CalendarComponent } from './calendar.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    CalendarComponent,
  ],
  exports: [
    CalendarComponent,
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
})
export class CalendarModule { }
