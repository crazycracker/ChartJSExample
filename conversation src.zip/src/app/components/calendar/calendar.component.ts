import {
  Component,
  ChangeDetectionStrategy,
  ViewChild,
  TemplateRef
} from '@angular/core';
import {
  startOfDay,
  endOfDay,
  subDays,
  addDays,
  endOfMonth,
  isSameDay,
  isSameMonth,
  addHours
} from 'date-fns';
import {Subject} from 'rxjs';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {
  CalendarEvent,
  CalendarEventAction,
  CalendarEventTimesChangedEvent,
  CalendarView
} from 'angular-calendar';
import {ModalComponent} from '../../components/modal/modal.component';
import {ACTIONS_SUBJECT_PROVIDERS} from '@ngrx/store/src/actions_subject';

@Component({
  selector: 'app-irene-calendar-dynamic',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.scss']
})

export class CalendarComponent {
  @ViewChild('modalContent')
  modalContent: ModalComponent;

  view: CalendarView = CalendarView.Month;

  CalendarView = CalendarView;

  viewDate: Date = new Date();

  colors: any = {
    scheduled: {
      primary: '#1671C7',
    },
    completed: {
      primary: '#00ED74',
    },
    preferred: {
      primary: '#FFCB00',
    }
  };

  modalData: {
    action: string;
    event: CalendarEvent;
  };

  actions: CalendarEventAction[] = [
    {
      label: '<img src=\'../../../assets/icons/edit@2x.png\'/>',
      onClick: ({event}: { event: CalendarEvent }): void => {
        this.handleEvent('Edited', event);
      }
    },
    {
      label: '  <img src=\'../../../assets/icons/cancel@2x.png\'/>',
      onClick: ({event}: { event: CalendarEvent }): void => {
        this.events = this.events.filter(iEvent => iEvent !== event);
        this.handleEvent('Deleted', event);
      }
    }
  ];

  refresh: Subject<any> = new Subject();

  events: CalendarEvent[] = [
    {
      start: subDays(startOfDay(new Date()), 7),
      end: subDays(startOfDay(new Date()), 7),
      title: 'CID :- 678545 Phone Interview',
      color: this.colors.completed,
      actions: this.actions,
      allDay: true,
      cssClass: 'c',
    },
    {
      start: addDays(new Date(), 1),
      end: addDays(new Date(), 1),
      title: 'CID :- 678547 Face to Face Interview',
      color: this.colors.scheduled,
      actions: this.actions,
      allDay: false,
      cssClass: 's',
    },
    {
      start: addDays(new Date(), 7),
      end: addDays(new Date(), 7),
      title: 'CID :- 678549 HR Discussion ',
      color: this.colors.preferred,
      actions: this.actions,
      allDay: false,
      cssClass: 'p',
    },
    {
      start: subDays(endOfMonth(new Date()), 4),
      end: subDays(endOfMonth(new Date()), 4),
      title: 'CID :- 678560 Final Settlement',
      color: this.colors.scheduled,
      actions: this.actions,
      allDay: false,
      cssClass: 's',
    },
    {
      start: subDays(endOfMonth(new Date()), 4),
      end: subDays(endOfMonth(new Date()), 4),
      title: 'CID :- 678570 Face to Face Interview',
      color: this.colors.preferred,
      actions: this.actions,
      allDay: false,
      cssClass: 'p',
    },
    {
      start: startOfDay(new Date()),
      end: startOfDay(new Date()),
      title: 'CID :- 678575 Technical Assessment',
      color: this.colors.preferred,
      actions: this.actions,
      allDay: false,
      cssClass: 'p',
    }
  ];

  /*events: CalendarEvent[] = [
    {
      start: subDays(startOfDay(new Date()), 1),
      end: addDays(new Date(), 1),
      title: 'A 3 day event',
      color: colors.scheduled,
      actions: this.actions,
      allDay: true,
      resizable: {
        beforeStart: true,
        afterEnd: true
      },
      draggable: true
    },
    {
      start: startOfDay(new Date()),
      title: 'An event with no end date',
      color: colors.scheduled,
      actions: this.actions
    },
    {
      start: subDays(endOfMonth(new Date()), 3),
      end: addDays(endOfMonth(new Date()), 3),
      title: 'A long event that spans 2 months',
      color: colors.confirmed,
      allDay: true
    },
    {
      start: addHours(startOfDay(new Date()), 2),
      end: new Date(),
      title: 'A draggable and resizable event',
      color: colors.confirmed,
      actions: this.actions,
      resizable: {
        beforeStart: true,
        afterEnd: true
      },
      draggable: true
    }
  ];*/

  activeDayIsOpen: boolean = true;

  constructor(private modal: NgbModal) {
  }

  dayClicked({date, events}: { date: Date; events: CalendarEvent[] }): void {
    if (isSameMonth(date, this.viewDate)) {
      this.viewDate = date;
      if (
        (isSameDay(this.viewDate, date) && this.activeDayIsOpen === true) ||
        events.length === 0
      ) {
        this.activeDayIsOpen = false;
      } else {
        this.activeDayIsOpen = true;
      }
    }
  }

  eventTimesChanged({
                      event,
                      newStart,
                      newEnd
                    }: CalendarEventTimesChangedEvent): void {
    event.start = newStart;
    event.end = newEnd;
    this.handleEvent('Dropped or resized', event);
    this.refresh.next();
  }

  handleEvent(action: string, event: CalendarEvent): void {
    this.modalData = {event, action};
    this.modal.open(this.modalContent, {size: 'lg'});
  }

  addEvent(): void {
    this.events.push({
      title: 'New event',
      start: startOfDay(new Date()),
      end: endOfDay(new Date()),
      color: this.colors.preferred,
      cssClass: 'p',
      allDay: false,
      actions: this.actions,
    });
    this.refresh.next();
  }
}
