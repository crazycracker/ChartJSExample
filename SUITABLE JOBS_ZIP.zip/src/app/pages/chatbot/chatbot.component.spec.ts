import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { ChatbotComponent } from './chatbot.component';
import { ChatService } from '../../services/chatbot-service/chat.service';
import { APIService } from '../../services/api-service/api.service';
import { Http2Service } from '../../services/http2/http2.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

xdescribe('ChatbotComponent', () => {
  let component: ChatbotComponent;
  let fixture: ComponentFixture<ChatbotComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChatbotComponent ],
      imports: [
        FormsModule,
        HttpClientTestingModule,
      ],
      providers: [
        ChatService,
        APIService,
        Http2Service,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChatbotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
