import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LocationDropDownComponent } from './locationdropdown.component';

describe('LocationdropdownComponent', () => {
  let component: LocationDropDownComponent;
  let fixture: ComponentFixture<LocationDropDownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LocationDropDownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LocationDropDownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
