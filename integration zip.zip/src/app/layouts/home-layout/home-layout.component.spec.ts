import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TestBed, ComponentFixture, async, inject } from '@angular/core/testing';
import { HomeLayoutComponent } from './home-layout.component';
import { RouterTestingModule } from '@angular/router/testing';
import { Store, StoreModule } from '@ngrx/store';
import { userReducer } from '../../reducers/user.reducer';
import { AuthenticationService } from '../../services/authentication-service/authentication.service';
import { APIService } from '../../services/api-service/api.service';
import { Http2Service } from '../../services/http2/http2.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { IAppState } from '../../app.state';

describe('HomeLayoutComponent', () => {
  let component: HomeLayoutComponent;
  let fixture: ComponentFixture<HomeLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        HomeLayoutComponent
      ],
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        StoreModule.forRoot(userReducer),
      ],
      providers: [
        AuthenticationService,
        APIService,
        Http2Service,
      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create',
    async(inject([ Store ], (store: Store<IAppState>) => {
    store.select('user');
    expect(component).toBeTruthy();
  })));
});
