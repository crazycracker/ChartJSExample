import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FindResumeComponent } from './find-resume.component';
import { AddLanguagesModule } from '../add-languages/add-languages.module';
import { AddLocationsModule } from '../add-locations/add-locations.module';
import { AddSkillsModule } from '../add-skills/add-skills.module';
@NgModule({
  declarations: [
    FindResumeComponent,
  ],
  exports: [
    FindResumeComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    AddSkillsModule,
    AddLanguagesModule,
    AddLocationsModule
  ],
  entryComponents: [
  ]
})
export class FindResumeModule { }
