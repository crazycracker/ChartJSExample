import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import {  EMailsComponent } from './e-mails.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    EMailsComponent,
  ],
  exports: [
    EMailsComponent,
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
})
export class EMailsModule { }
