import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FindBestComponent } from './find-best.component';
describe('FindBestResComponent', () => {
  let component: FindBestComponent;
  let fixture: ComponentFixture<FindBestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FindBestComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FindBestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
