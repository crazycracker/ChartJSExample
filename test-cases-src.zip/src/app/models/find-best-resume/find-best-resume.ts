
export interface IStateCity {
  state: Array<string>;
  city: Array<string>;
}

export interface ISkills {
  value: string;
  proficiency: string;
}

export interface IRecruiterFormData {
  skillsWeightage: string;
  jobid: string;
  hardskills: Array<ISkills>;
  softskills: Array<ISkills>;
  industryWeightage: string;
  industryType: string;
  subType: string;
  candidateDetailsWeightage: string;
  qualifications: string;
  lastExperienceInMedical: string;
  languagesKnownWeightage: string;
  languagesKnown: Array<string>;
  educationAndOrganizationDetails: string;
  topAcademicInstitutions: string;
  organizations: string;
  profilesRequired: string;
  employmentTypeWeightage: string;
  employmentType: string;
  primaryLocationsWeightage: string;
  cityState: Array<IStateCity>;
  priorityOfTheJob: string;
  priorityofthejobWeightage: string;
  diversity: string;
}

export class RecruiterFormData implements IRecruiterFormData {
  constructor(
    public jobid: string,
    public skillsWeightage: string,
    public hardskills: Array<ISkills>,
    public softskills: Array<ISkills>,
    public industryWeightage: string,
    public industryType: string,
    public subType: string,
    public candidateDetailsWeightage: string,
    public qualifications: string,
    public lastExperienceInMedical: string,
    public languagesKnownWeightage: string,
    public languagesKnown: Array<string>,
    public educationAndOrganizationDetails: string,
    public topAcademicInstitutions: string,
    public organizations: string,
    public profilesRequired: string,
    public employmentTypeWeightage: string,
    public employmentType: string,
    public primaryLocationsWeightage: string,
    public cityState: Array<IStateCity>,
    public priorityOfTheJob: string,
    public priorityofthejobWeightage: string,
    public diversity: string
  ) {}
}
