import { Action } from '@ngrx/store';
import { BestResume } from '../models/find-best-resume/find-best-resume';
import * as BestResumeDataAction from '../actions/best-resume.actions';
import {ICoreAction} from '../actions/actions';

/**
 * Ngrx reducer for profile
 * @param {ProfileAction} action - Fetch Profile action
 * @return {Profile} - The new user state
 */
export function bestResumeReducer(state: BestResume[] = [], action: ICoreAction<any>) {

  switch (action.type) {
    case BestResumeDataAction.ADD_BESTRESUME :
      return [...state, action.payload];
    case BestResumeDataAction.REMOVE_BESTRESUME :
      return [];
    default:
      return state;
  }
}
