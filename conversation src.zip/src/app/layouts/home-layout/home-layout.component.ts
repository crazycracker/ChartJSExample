import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { IAppState } from '../../app.state';
import { IUserState } from '../../state/user.state';
import { Router } from '@angular/router';
import { LoaderService } from '../../services/loader/loader.service';

@Component({
  selector: 'app-home-layout',
  templateUrl: './home-layout.component.html',
  styleUrls: ['./home-layout.component.scss'],

})

export class HomeLayoutComponent implements OnInit {
  title = 'app';
  public isCandidateProfile;
  public toggleEvent;
  public isLoginPage: Boolean = false;
  public userData: any;
  public isChatBotPage: Boolean = false;
  public showLoader: Boolean = false;

  /**
 * @constructor injects the dependent services
 * @description : The constructor initialises the class variables with the dependencies injected into the class
 * @param {store} Store
 * @param {authService} AuthenticationService
 */
  constructor(
    private store: Store<IAppState>,
    private router: Router,
    private loaderService: LoaderService
  ) {
    this.store.select('user').subscribe((userState: IUserState) => {
      if (userState.user) {
        this.isCandidateProfile = userState.user[0].userRole;
      }
    });
   }
   ngOnInit() {
    this.loaderService.status.subscribe((val: boolean) => {
      this.showLoader = val;
    });
   }

  public changeOfRoutes() {
    if (this.router.url === '/chatbot') {
      this.isChatBotPage = true;
    } else {
      this.isChatBotPage = false;
    }
  }

  public onToggleSideBar(event) {
    this.toggleEvent = event;
  }
}
