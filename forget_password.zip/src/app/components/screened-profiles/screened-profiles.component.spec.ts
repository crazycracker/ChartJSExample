import { async, ComponentFixture, inject, TestBed } from '@angular/core/testing';
import { ScreenedProfilesComponent } from './screened-profiles.component';
import { APIService } from '../../services/api-service/api.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ScreenedProfileService } from '../../services/screened_profile-service/screened-profile.service';
import { PagerService } from '../../services/Pagination-service/pager.service';
import {Observable, of} from 'rxjs';
const mockResponse = {
  data: { success: true }
};
const alldata =
  [{
    'Labels': [{
      'IndustryLabel': 'Industry'
    }],
    'InputValues': [{
      'name': 'David James',
      'img': 'assets/icons/myProfileIcon.png',
      'competativeLabel': 'COMPETITIVE COMPANY',
      'pic': 'assets/icons/Fill 1.png',
      'Candidateid': '212345',
      'Qualification1': 'B.Sc Psychology, Italy',
      'Qualification2': 'Masters in Fashion Mgmt, London',
      'Experience': '2yrs',
      'Skill1': 'FashionDesign',
      'Skill2': 'User research',
      'Skill3': 'Marketing',
      'Profilematchscore': '98%',
      'EducationDetails': [{
        'EduName': 'Sep 2005 - Jul 2010',
        'EduDetail': 'Bacholer in Pharmacy, University of the Pharmacy, Central Saint Martins, London'
      }
      ],
      'WorkExperience': [{
        'image1': 'PRIMAX',
        'WorkName': 'Apr 2014 - Sep 2014',
        'WorkDetail': 'Junior Pharmacist at Primax Healthcare, USA'
      }
      ]
    }
    ]
  }];
  class MockAPIService {
    public get(): Observable<{}> {
      return of(mockResponse);
    }
  }
  class  ScreenedprofileMockService  {
    public  getDetails(): Observable<{}> {
      return of(alldata);
    }
  }
describe('ScreenedProfilesComponent', () => {
  let component: ScreenedProfilesComponent;
  let fixture: ComponentFixture<ScreenedProfilesComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ScreenedProfilesComponent],
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        PagerService,
        { provide: APIService, useClass: MockAPIService },
        { provide:  ScreenedProfileService,  useClass:  ScreenedprofileMockService }]
    })
      .compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(ScreenedProfilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create component and get data from service',  inject([ScreenedProfileService], (service: ScreenedProfileService) => {
      spyOn(service, 'getDetails').and.callThrough();
      service.getDetails();
     component.labels = alldata;
    expect(component).toBeTruthy();
     expect(component.pagedItems[0].name).toEqual('David James');
  })
  );
});


