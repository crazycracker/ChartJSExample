import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppRouteConstants } from './app.constants.component';
import { ChatbotComponent } from './pages/chatbot/chatbot.component';
import { FindBestResumeComponent } from './pages/find-best-resume/find-best-resume.component';
import { LoginComponent } from './pages/login/login.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { SuitableJobsComponent } from './pages/suitable-jobs/suitable-jobs.component';
import { FaqsComponent } from './pages/faqs/faqs.component';
import { NeedHelpComponent } from './pages/need-help/need-help.component';
import { WhyUsComponent } from './pages/why-us/why-us.component';
import { AuthGuard } from './services/authentication-service/authentication.guard';
import { HomeLayoutComponent } from './layouts/home-layout/home-layout.component';
import { LoginLayoutComponent } from './layouts/login-layout/login-layout.component';
import { ScreenedProfilesComponent } from './pages/screened-profiles/screened-profiles.component';
import { SearchHistoryComponent } from './pages/search-history/search-history.component';
import { MailsComponent } from './pages/mails/mails.component';

const Routes: Routes = [
  {
    path: '',
    component: HomeLayoutComponent,
    canActivate: [AuthGuard],
    children: [
      { path: '', component: ProfileComponent },
      { path: AppRouteConstants.CHATBOT, component: ChatbotComponent },
      { path: AppRouteConstants.FIND_BEST_RESUME, component: FindBestResumeComponent },
      { path: AppRouteConstants.VIEW_PROFILE, component: ProfileComponent },
      { path: AppRouteConstants.FAQs, component: FaqsComponent },
      { path: AppRouteConstants.NEED_HELP, component: NeedHelpComponent },
      { path: AppRouteConstants.SUITABLE_JOBS, component: SuitableJobsComponent },
      { path: AppRouteConstants.SCREENED_PROFILE, component: ScreenedProfilesComponent },
      { path: AppRouteConstants.WHY_US, component: WhyUsComponent },
      { path: AppRouteConstants.SEARCH_HISTORY, component: SearchHistoryComponent},
      { path: AppRouteConstants.E_MAILS, component: MailsComponent}
    ]
  },
  {
    path: '',
    component: LoginLayoutComponent,
    children: [
      { path: 'login', component: LoginComponent },
    ]
  },
  { path: '**', redirectTo: '' }
];
@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forRoot(Routes)],
  providers: [],
})
export class AppRoutingModule { }
