import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { FindResumeComponent } from './find-resume.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    FindResumeComponent,
  ],
  exports: [
    FindResumeComponent,
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
})
export class FindResumeModule { }
