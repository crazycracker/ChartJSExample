import { Component, OnInit, ViewChild } from '@angular/core';
import {ModalComponent} from '../../components/modal/modal.component';
import { ACTIONS_SUBJECT_PROVIDERS } from '@ngrx/store/src/actions_subject';

@Component({
  selector: 'app-irene-schedule',
  templateUrl: './schedule.component.html',
  styleUrls: ['./schedule.component.scss']
})
export class ScheduleComponent implements OnInit {
@ViewChild('calendarSchedule') calendarSchedule: ModalComponent;

public isNext = false;
public data: any = [];
public labels;
public days;
public dates;
public calendarData: any = [];
public currentDate;
public eventData = false;
public phoneInterview = 'Phone Interview';
public phoneInterviewOct = 'Phone Interview';
public interviewResult = 'Phone Interview Results';

  constructor() { }

  ngOnInit() {}

  public scheduled(): void {
    if (this.calendarData.length === 0) {
      this.calendarSchedule.openModal();
    }
  }

  public closeModal(): void {
    this.calendarSchedule.closeModal();
  }

public nextMonth(): void {
this.isNext = true;
  }

previousMonth(): void {
    this.isNext = false;
  }

saveData(duration, des): void {
  this.calendarData = [];
  this.eventData = true;
  this.currentDate = document.getElementById('currentDate').innerText;
  console.log(this.currentDate);
  this.calendarData.push({
      date: this.currentDate,
      eventName: des,
     duration: duration,
  });
  this.calendarSchedule.closeModal();
}
public removeSchedule(value): void {
   const date = value.innerText;
    if (date === '06') {
      this.phoneInterview = '';
    } else if (date === '08') {
     this.interviewResult = '';
    } else if (date === '12') {
      this. phoneInterviewOct = '';
     } else if (date === '02' || date === '08') {
      setTimeout(() => {
        this.calendarData = '';
        this.eventData = false;
   }, 500);
     }
    }
}
