import { Injectable } from '@angular/core';
import { Observable, ObservableLike } from 'rxjs';
import { Store } from '@ngrx/store';
import { map } from 'rxjs/operators';
import { Headers } from '@angular/http';
import { HttpResponse } from '@angular/common/http';
import { APIService } from '../api-service/api.service';
import { Scheme } from '../../models/http2/http2';
import { IAPIServiceOpts } from '../../models/http2/request';
import { environment } from '../../../environments/environment';
import { Http2Service } from '../../services/http2/http2.service';
import { IRequestOpts } from '../../models/http2/request';
import { IAppState } from '../../app.state';
import { IUserState } from '../../state/user.state';

@Injectable()
export class ChatService {
  private url = '/assets/data/chatMessages.json';
  contextId: string;
  userData: Object = [];

  constructor(
    private apiService: APIService,
    private httpService: Http2Service,
    private store: Store<IAppState>
  ) {
    this.store.select('user').subscribe((userState: IUserState) => {
      if (userState.user && userState.user[0].contextID) {
        this.contextId = userState.user[0].contextID;
        this.userData = userState.user[0].loginData;
      }
    });
  }
  /**
   * @method getChatDetails()
   * @description : Used to Fetch the data from ChatMessages.json
   * @return {Observable} : Observable of data
   */
  public getChatDetails(): Observable<{}> {
    const request: IAPIServiceOpts<{}> = {
      path: this.url
    };

    return this.apiService
      .get(request)
      .pipe(map((res: HttpResponse<{}>) => res.body));
  }

  /**
   * @method updateUserDetails
   * @description This method used to update user password
   * @param {Object} data - loyalty member Id, user name or email address
   * @returns {Observable}
   */
  public updateUserDetails(data: {}): Observable<{}> {
    const opts: IAPIServiceOpts<{}> = {
      body: {
        login: data['userId'],
        user_password: data['password']
      },
      path: ''
    };
    return this.apiService
      .post(opts)
      .pipe(map((res: HttpResponse<{}>) => res.body));
  }

  /**
   * @description sets request header
   * @param headers: Header
   * @return none
   */
  private setContentTypeRequestHeader(headers: Headers): void {
    headers.set('Content-Type', 'application/json');
  }

  /**
   * @method postChatDetails object
   * @return {Observable<IResponse<T>>} The observable response
   */
  public postChatDetails(userChat): Observable<{}> {
    const apiPayload = {
      // TODO will be implemented further once we get required details
      useCaseName: 'workday',
      user: this.userData['user_name'],
      question: userChat,
      candidateID: this.userData['candidate_id'],
      contextId: this.contextId
    };
    return this.apiService.postMethod(apiPayload, environment.api.chat_service);
  }

  /**
   * @description: method to initiate the api request and pass in the data payload
   * @param apiPayload: formdata coming form component file
   * @return Observable of type response
   */
  public uploadResume(apiPayload): Observable<{}> {
    const apiRequestConfig: IRequestOpts<{}> = {
      body: apiPayload,
      host: environment.url,
      path: environment.api.file_upload,
      scheme: environment.scheme as Scheme,
    };
    return this.httpService.post(apiRequestConfig);
  }

  /**
   * @method upload
   * @description: To upload the attached file(sending the data to chatService)
   */
  public upload(fileDetails): Observable<{}> {
    const formData: FormData = new FormData();
    Array.from(fileDetails).forEach(fBlob => formData.append('file', fBlob as Blob));
    formData.append('userName', this.userData['user_name']);
    formData.append('candidateID', this.userData['candidate_id']);
    const sessionParam = JSON.stringify({
      contextId: this.contextId,
      SenderId: this.userData['candidate_id'],
      SenderName: this.userData['user_name']
    });
    formData.append('sessionParam', sessionParam);
    return this.uploadResume(formData);
  }
  public updateCandidateData(requestCandidate): Observable<{}> {
    const apiRequestConfig: IRequestOpts<{}> = {
      body: requestCandidate,
      host: environment.url,
      path: environment.api.candidateData_service,
      scheme: environment.scheme as Scheme,
    };
    return this.httpService.post(apiRequestConfig);
  }
  public candidateData(): Observable<{}> {
    const requestCandidate = {
      'sessionParam': {
        'contextId': '43e8d6a69a2197d55d405ba86348bc9e4842e9e7bf5bb430cf9d84cce3c11680',
        'SenderId': 'venkat',
        'SenderName': 'venkat'
      },
      'userName': 'venkat',
      'candidateID': 'CAND-1191'
    };
    return this.apiService.postMethod(requestCandidate, environment.api.candidateData_service);
  }
}
