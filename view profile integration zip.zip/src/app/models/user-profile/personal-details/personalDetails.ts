/**
 * Data model for a account summary profile details
 */

import { Address } from './address';
import { Contact } from './contact';
import { Email } from './email';
import { JobPreference } from './jobPreference';

export interface IPersonalDetails {
  addresses?: Array<Address>;
  contactArray?: Array<Contact>;
  eConsent?: boolean;
  emailAddresses?: Array<Email>;
  rentalPreferences?: JobPreference;
  firstName?: string;
  lastName?: string;
  memberDob?: string;
  memberId?: string;
  middleName?: string;
  preffixName?: string;
  suffixName?: string;
  systemId?: string;
  userType?: string;
  username?: string;
}

export class PersonalDetails implements IPersonalDetails {
  constructor(
    public addresses?: Array<Address>,
    public contactArray?: Array<Contact>,
    public eConsent?: boolean,
    public emailAddresses?: Array<Email>,
    public rentalPreferences?: JobPreference,
    public firstName?: string,
    public lastName?: string,
    public memberDob?: string,
    public memberId?: string,
    public middleName?: string,
    public preffixName?: string,
    public suffixName?: string,
    public systemId?: string,
    public userType?: string,
    public username?: string,
  ) { }
}
