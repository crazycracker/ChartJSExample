import { Component } from '@angular/core';
import { Skill } from './skill.component';
@Component({
  selector: 'app-irene-add-skills',
  templateUrl: './add-skills.component.html',
  styleUrls: ['./add-skills.component.scss']
})
export class AddSkillsComponent {
  skills: Array<Skill>;
  constructor() {
    this.skills = [];
  }
  addSkill(skill) {
    if (skill !== '') {
      const newSkill = new Skill(skill);
      newSkill.update(skill);
      this.skills.push(newSkill);
    }
  }
  removeSkill(skill) {
    const index = this.skills.indexOf(skill);
    this.skills.splice(index, 1);
  }
}
