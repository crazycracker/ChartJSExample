import { async, ComponentFixture, inject, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { FindResumeComponent } from './find-resume.component';
import { APIService } from '../../../services/api-service/api.service';
import { Http2Service } from '../../../services/http2/http2.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('FindResumeComponent', () => {
  let component: FindResumeComponent;
  let fixture: ComponentFixture<FindResumeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FindResumeComponent],
      imports: [
        FormsModule,
        HttpClientTestingModule,
        HttpModule,
      ],
      providers: [
        APIService,
        Http2Service,
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FindResumeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
