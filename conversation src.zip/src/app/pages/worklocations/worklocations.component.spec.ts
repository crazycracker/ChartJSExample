import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorklocationsComponent } from './worklocations.component';
import { FormsModule } from '@angular/forms';
import { AgmCoreModule, GoogleMapsAPIWrapper } from '@agm/core';
import { APIService } from '../../services/api-service/api.service';
import { Http2Service } from '../../services/http2/http2.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpModule } from '@angular/http';
import { of, Observable } from 'rxjs';
import { WorklocationsService } from '../../services/worklocations/worklocations.service';
import { inject } from '@angular/core/testing';

class MockService {
  getLabelDetails(): Observable <{}> {
   return of (data);
  }
}

const data = {
  Labels: {
    workLocationsLabel: 'Work Locations',
    viewallLabel: 'View all'
  },
  InputValues: {
    PrimaryOffice: [{
        key: '1',
        value: 'Woodlands',
        lat: 1.295250,
        lang: 103.784504
      }
    ],
    ResearchOffice: [{
        key: '0',
        value: 'Select Location',
        lat: '',
        lang: ''
      },
    ],
    SalesOffice: [{
        key: '0',
        value: 'Select Location',
        lat: '',
        lang: ''
      }
    ],
    Category: ['Select Category', 'Primary Office', 'Research Centre', 'Sales Office']
  },
  Worklocations: [{
      imageURL: 'assets/images/location-1-@3x.jpg',
      ratingImageURL: 'assets/icons/screened-profiles-icon.png',
      placeName: 'Woodlands',
      noOfEmployees: '30 EMPLOYEES',
      address: '31, Riverside Road,Woodlands, Singapore 739087',
      location: 'MARINA, SINGAPORE'
    }
  ],
  Locations: [
    {
    location: 'MARINA, SINGAPORE'
  }
],
  Places: [{
    latitude: '1.4202',
    longitude: '103.85'
  }]
};

fdescribe('WorklocationsComponent', () => {
  let component: WorklocationsComponent;
  let fixture: ComponentFixture<WorklocationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorklocationsComponent ],
      providers: [
        APIService,
        GoogleMapsAPIWrapper,
        Http2Service,
        WorklocationsService,
        { provide: WorklocationsService, useClass: MockService }
      ],
      imports: [
        FormsModule,
        AgmCoreModule.forRoot(),
        HttpClientTestingModule,
        HttpModule,
       ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorklocationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should select the selected location', () => {
    const category = 'Primary Office';
    const selectItems = {
      PrimaryOffice: 'Hong Kong'
    };
    const formData = {
      location: ''
    };
    component.formData = formData;
    component.selectItems = selectItems;
    component.addLocations('Primary Office');
    expect(component.selectedLocation).toBe('Hong Kong');
    expect(component.formData.location).toBe('Select Location');
  });
  it('should get the labels from JSON', inject(
    [WorklocationsService],
    (service: WorklocationsService) => {
      spyOn(service, 'getLabelDetails').and.callThrough();
      service.getLabelDetails();
      expect(component.labels).toEqual(data.Labels);
    }
  ));
  it('should filter the selected location', () => {
    component.selectedLocation = data.InputValues.PrimaryOffice;
    const formData = {
      location: 'Woodlands'
    };
    component.formData = formData;
    component.setMapLocation();
    expect(component.latitude).toBe(data.InputValues.PrimaryOffice[0].lat);
  });
});

