/**
 * Components Module
 */

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { ChatBotModule } from './chatbot/chatbot.module';
import { SidebarModule } from './sidebar/sidebar.module';
import { HeaderModule } from './header/header.module';
import { FindResumeModule } from './find-best-resume/find-resume/find-resume.module';
import { ViewProfileModule } from './view-profile/view-profile/view-profile.module';
import { SuitableJobsModule } from './suitable-jobs/suitable-jobs.module';
import { ProfileTileModule } from './screened-profiles/screened-profiles.module';
import { CarouselComponent } from './carousel/carousel.component';
import { SearchHistoryComponentComponent } from './search-history-component/search-history-component.component';
import { ModalModule } from './modal/modal.module';
import { DocumentsModule } from './documents/document.module';

import { EMailsModule } from './e-mails/e-mails.module';
import { ScheduleModule } from './schedule/schedule.module';



@NgModule({
  declarations: [
    CarouselComponent,
    SearchHistoryComponentComponent,

  ],
  exports: [
    ChatBotModule,
    SidebarModule,
    HeaderModule,
    FindResumeModule,
    ViewProfileModule,
    SuitableJobsModule,
    CarouselComponent,
    SearchHistoryComponentComponent,
    ModalModule,
    ProfileTileModule,
    DocumentsModule,
    EMailsModule,
    ScheduleModule,
  ],
  imports: [
    CommonModule,
    ChatBotModule,
    SidebarModule,
    HeaderModule,
    FindResumeModule,
    ViewProfileModule,
    SuitableJobsModule,
    ProfileTileModule,
    ModalModule,
    DocumentsModule,
    EMailsModule,
    ScheduleModule,

  ],
})
export class ComponentsModule { }
