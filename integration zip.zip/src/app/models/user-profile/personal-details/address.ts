/**
 * Data model for a account summary page content
 */

export interface IAddress {
  address1?: string;
  address2?: string;
  addressType?: string;
  businessName?: string;
  city?: string;
  countryCode?: string;
  countryName?: string;
  postalCode?: string;
  stateProvinceName?: string;
}
export class Address implements IAddress {
  constructor(
    public address1?: string,
    public address2?: string,
    public addressType?: string,
    public businessName?: string,
    public city?: string,
    public countryCode?: string,
    public countryName?: string,
    public postalCode?: string,
    public stateProvinceName?: string,
  ) { }
}
