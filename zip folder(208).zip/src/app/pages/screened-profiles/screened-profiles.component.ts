import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-irene-profiles',
  templateUrl: './screened-profiles.component.html',
  styleUrls: ['./screened-profiles.component.scss']
})
export class ScreenedProfilesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
