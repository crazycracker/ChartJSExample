import { Component } from '@angular/core';
import { Skill } from './skill.component';
@Component({
  selector: 'app-irene-add-another-feature',
  templateUrl: './add-another-feature.component.html',
  styleUrls: ['./add-another-feature.component.scss']
})
export class AddAnotherFeatureComponent {
  skills: Array<Skill>;
  constructor() {
    this.skills = [];
  }
  addSkill(skill) {
    if (skill !== '') {
      const newSkill = new Skill(skill);
      newSkill.update(skill);
      this.skills.push(newSkill);
    }
  }
  removeSkill(skill) {
    const index = this.skills.indexOf(skill);
    this.skills.splice(index, 1);
  }
}


