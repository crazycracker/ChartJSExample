import { FindBestResumeService } from '../../../../services/find-best-resume-service/find-best-resume.service';
import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-languagedropdown',
  templateUrl: './languagedropdown.component.html',
  styleUrls: ['./languagedropdown.component.scss']
})
export class LanguageDropDownComponent implements OnInit {
  /**
   * @constructor injects the dependant services
   * @description The constructor initialises the class variables with the dependencies injected into the class
   * @param  {FindBestResumeService} service
   */
  constructor(private service: FindBestResumeService) { }
  public selectItems;
  public data: any = [];
  /**
   * @method ngOnInit
   * @description : subscribing the method from FindBestResumeService
   */
  ngOnInit() {
      this.service.getLabelDetails().subscribe(response => {
          if (response) {
              this.data = response;
              this.selectItems = this.data.InputValues;
          }
      });
  }
}

