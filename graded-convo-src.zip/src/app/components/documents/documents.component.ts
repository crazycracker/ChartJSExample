import { Component, OnInit } from '@angular/core';
import { DocumentService } from '../../services/document-service/document.service';
@Component({
  selector: 'app-irene-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss']
})
export class DocumentsComponent implements OnInit {
  constructor(private service: DocumentService) { }
  public data: any = [];
  public labels;
  public docName;
  public docDate;
  public iteration;
   /**
   * @method ngOnInit
   * @description : Getting the data from Document service
   */
  ngOnInit() {
    this.service.getDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.labels = this.data[0].Labels[0];
        this.iteration = this.data[0];
      }
    });
    const docdetails = localStorage.getItem('docDetails');
    this.docName = JSON.parse(docdetails).name;
    this.docDate = JSON.parse(docdetails).date;
  }
}
