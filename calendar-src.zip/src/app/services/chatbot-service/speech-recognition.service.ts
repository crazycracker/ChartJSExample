import { Injectable, NgZone  } from '@angular/core';
import { Observable } from 'rxjs';


// Creating windows interface with properties to handle speech
// recognition. APIs referred as per google's webkit standards

interface IWindow extends Window {
  webkitSpeechRecognition: any;
  SpeechRecognition: any;
}

@Injectable({
  providedIn: 'root'
})
export class SpeechRecognitionService {
  public speechRecog: any;
  constructor(private zone: NgZone) {

  }
  /**
   * @description: Method to record voide
   * @return: Observable of the recorded voice
  */
 public recordVoice(): Observable<string> {
  return Observable.create(observer => {
    const { webkitSpeechRecognition }: IWindow = <IWindow>window;
    this.speechRecog = new webkitSpeechRecognition();
    // continuous recording
    this.speechRecog.continuous = true;
    // set the language
    this.speechRecog.lang = 'en-us';
    this.speechRecog.maxAlternatives = 1;

    // catching the speech
    this.speechRecog.onresult = speech => {
      let finishedWord = '';
      const speechHasResults: boolean = speech.results;
      if (speechHasResults) {
        const resultRecorded = speech.results[speech.resultIndex];
        const transcript = resultRecorded[0].transcript;
        const isRecordingDone: boolean = resultRecorded.isFinal;
        if (isRecordingDone) {
          finishedWord = resultRecorded[0].confidence > 0.2 ?
            transcript.trim() : '';
        }
      }
      this.zone.run(() => {
        observer.next(finishedWord);
      });
    };

    // Error scenario
    this.speechRecog.onerror = error => {
      observer.error(error);
    };

    // On end
    this.speechRecog.onend = () => {
      observer.complete();
    };
    this.speechRecog.start();
  });
}

/**
 * @description: Method to destroy the speech object
*/
public destroySpeechObject(): void {
  if (this.speechRecog) {
    this.speechRecog.stop();
  }
}
}
