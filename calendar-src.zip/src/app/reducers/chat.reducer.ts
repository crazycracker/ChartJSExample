import { Action } from '@ngrx/store';
import { Chat } from '../models/chat-messages/chat';
import * as ChatActions from '../actions/chat.actions';

/**
 * Ngrx reducer for chat conversation
 * @param {ChatActions} action - ADD CHAT action
 * @return {Chat} - The new user state
 */
export function chatReducer(state: Chat[] = [], action: ChatActions.Actions) {

    switch (action.type) {
        case ChatActions.ADD_CHAT :
            return [...state, action.payload];
        default:
            return state;
    }
}
