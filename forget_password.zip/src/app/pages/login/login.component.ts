import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../services/authentication-service/authentication.service';
import { Store } from '@ngrx/store';
import { IAppState } from '../../app.state';
import { UserLogin } from '../../actions/user.actions';

export interface IUserlogin {
  userName: string;
  password: string;
}

@Component({
  selector: 'app-irene-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})

export class LoginComponent implements OnInit {
  public loginLabels: any;
  public loginHeader: any;
  public loginContent: any;

  public showLoginCard: Boolean = true;

  public isCandidateProfile;
  public toggleEvent;
  public isLoginPage: Boolean = false;
  public userData: any = [];
  public incorrectCredentials = false;
  public userRole: any;
  public loginData: any;

  public formData: IUserlogin = {
    userName: '',
    password: '',
  };

  constructor(
    private store: Store<IAppState>,
    private router: Router,
    private authService: AuthenticationService,
  ) { }

  ngOnInit() {
    this.authService.getLoginDetails().subscribe(res => {
      this.loginLabels = res;
      this.loginHeader = this.loginLabels.WebsiteName;
      this.loginContent = this.loginLabels.LoginLabels;
    });
  }

  toggleLoginCard() {
    this.showLoginCard = !this.showLoginCard;
  }

  checkEmail() {
    this.authService.postForgetPasswordDetails(document.getElementById('usernameInput').textContent).subscribe(response => {
      console.log(response['body'].status);
    });
  }
  /**
    * @method onSubmit
    * @description: to validate username and password from service
    */

  onSubmit() {
    if (this.formData.userName !== '' && this.formData.password !== '') {
      this.authService.login(this.formData.userName, this.formData.password).subscribe(response => {
        if (response['body'].contextId !== '') {
          this.loginData = response['body'].loginData;
          const obj = JSON.parse(this.loginData);
          this.userRole = obj[0].user_role;
          this.defineUserRole(this.userRole);
          this.userData.push({
            'contextID': response['body'].contextId,
            'loginData': obj[0],
            'userRole': this.userRole
          });
          this.store.dispatch(UserLogin(this.userData));
          if (this.router.url === '/login' || this.router.url === '/forgotPassword') {
            this.isLoginPage = !this.isLoginPage;
          }
        } else {
          this.incorrectCredentials = true;
        }
      });
    }
  }

  /**
     * @method defineUserRol
     * @description: To determine user role and navigate the page accordingly
     * @param: userRole data from service
  */
  defineUserRole(userRole) {
    if (this.userRole === 'HR') {
      this.router.navigate(['/findbestresume']);
    } else if ((this.userRole === 'user')) {
      this.router.navigate(['/chatbot']);
    }
  }
}
