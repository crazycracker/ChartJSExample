/**
 * Module for chatbot Child components
 */

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { HttpClientModule } from '@angular/common/http';

import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [

  ],
  exports: [

  ],
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,

  ],
})
export class ChatBotModule { }
