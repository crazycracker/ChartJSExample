export const WhyUsConstants = [
    {
        imageUrl: '../../../assets/images/golf-text@2x.png',
    },
    {
        imageUrl: '../../../assets/images/swimText.png',
    },
    {
        imageUrl: '../../../assets/images/vrtext.png',
    },
    {
        imageUrl: '../../../assets/images/golf-text@2x.png',
    },
    {
        imageUrl: '../../../assets/images/swimText.png',
    },
    {
        imageUrl: '../../../assets/images/vrtext.png',
    },
    {
        imageUrl: '../../../assets/images/swimText.png',
    },
    {
        imageUrl: '../../../assets/images/golf-text@2x.png',
    },
    {
        imageUrl: '../../../assets/images/vrtext.png',
    }
];
