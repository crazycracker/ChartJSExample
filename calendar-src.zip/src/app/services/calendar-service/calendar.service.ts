import { APIService } from '../../services/api-service/api.service';
import { IAPIServiceOpts } from '../../models/http2/request';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpResponse } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class CalendarService {
  private url = '/assets/data/calendar.json';
  /**
    * @constructor injects the dependent services
    * @description : The constructor initialises the class variables with the dependencies injected into the class
    * @param {apiService} APIService
   */
  constructor(private apiService: APIService) { }
  /**
    * @method getLabelDetails
    * @description:The method fetches labels from the json to display them on user interface
    * @return {Observable} : Observable of data
    */
  public getLabelDetails(): Observable<{}> {
    const request: IAPIServiceOpts<{}> = {
      path: this.url,
    };

    return this.apiService.get(request).pipe(map((res: HttpResponse<{}>) => res.body));
  }
}
