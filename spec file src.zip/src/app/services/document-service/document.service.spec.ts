import { TestBed, inject } from '@angular/core/testing';
import { APIService } from '../../services/api-service/api.service';
import { Http2Service } from '../../services/http2/http2.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DocumentService } from './document.service';

describe('DocumentService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        DocumentService,
        APIService,
        Http2Service,
      ],
    });
  });

  it('should be created', inject([DocumentService], (service: DocumentService) => {
    expect(service).toBeTruthy();
  }));
  it('retrieves all data from json', inject( [DocumentService], ( service: DocumentService ) => {
    service.getDetails().subscribe( result => {
        expect(result).toBeGreaterThan(0);
    });
  }));
});

