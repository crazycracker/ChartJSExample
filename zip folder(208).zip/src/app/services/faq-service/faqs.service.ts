import { Injectable } from '@angular/core';
import { APIService } from '../api-service/api.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { IAPIServiceOpts } from '../../models/http2/request';
import { HttpResponse } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class FaqsService {
  private url = '/assets/Data/faqs.json';
  constructor(
    private apiService: APIService
  ) {}
  /**
   * @method getFaqDetails()
   * @description : Used to Fetch the data from faqs.json
   * @return {Observable} : Observable of data
   */
  public getFaqDetails(): Observable<{}> {
    const request: IAPIServiceOpts<{}> = {
      path: this.url,
    };

    return this.apiService.get(request).pipe(map((res: HttpResponse<{}>) => res.body));
  }
}
