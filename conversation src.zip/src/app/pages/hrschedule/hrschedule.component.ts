import { Component, OnInit } from '@angular/core';
import { HrscheduleService } from '../../services/HrSchedule/hrschedule.service';
@Component({
  selector: 'app-irene-hrschedule',
  templateUrl: './hrschedule.component.html',
  styleUrls: ['./hrschedule.component.scss']
})
export class HrscheduleComponent implements OnInit {
  public data: any = [];
  public labels;
  public selectItems;
  public formData: any = [];
  constructor(private service: HrscheduleService) { }
  /**
     * @method ngOnInit
     * @description : Method used to initalize the component
     */

  ngOnInit() {
    this.service.getLabelDetails().subscribe(response => {
      if (response) {
        this.data = response;
        this.labels = this.data.Labels;
        this.selectItems = this.data.InputValues;
      }
    });
  }
}
