import { TestBed, inject } from '@angular/core/testing';

import { HrscheduleService } from './hrschedule.service';

describe('HrscheduleService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HrscheduleService]
    });
  });

  it('should be created', inject([HrscheduleService], (service: HrscheduleService) => {
    expect(service).toBeTruthy();
  }));
});
